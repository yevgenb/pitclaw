#!/usr/bin/env python3
"""Check logical pin/net agreement; does NOT approve an unrouted PCB for manufacture."""
from collections import Counter
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import pcbnew as pcb
from hw398_geometry import CFG, carrier, holes, rectangles, keepout_polygon, scad_constants, MECH

root=Path(__file__).resolve().parents[1]
expected=json.loads((root/"verification/expected-pin-nets.json").read_text())
xml=ET.parse(sys.argv[1]).getroot()
schematic={}
for net in xml.findall("./nets/net"):
    for node in net.findall("node"):
        key=(node.attrib["ref"],node.attrib["pin"])
        assert key not in schematic, ("Pin appears in multiple nets",key)
        schematic[key]=net.attrib["name"].lstrip("/")
board=pcb.LoadBoard(str(root/"pitclaw-carrier.kicad_pcb"))
footprints={f.GetReference():f for f in board.GetFootprints()}
assert not set(expected)-set(footprints)
checks=0
for ref,pins in expected.items():
    for num,net in pins.items():
        got=schematic.get((ref,num),"")
        if net is None:
            assert not got or got.startswith("unconnected-"), ("Unexpected schematic connection",ref,num,got)
        else:
            assert got==net, ("Schematic net mismatch",ref,num,net,got)
        checks+=1
        pads=[p for p in footprints[ref].Pads() if p.GetNumber()==num]
        assert len(pads)==1, ("Missing/duplicate pad",ref,num)
        got=pads[0].GetNetname()
        assert got==(net or ""), ("PCB net mismatch",ref,num,net,got)
assert len(board.GetTracks())==0, "Update this draft check when intentional routing begins"
# Drawing-only body envelope: user measurement, not a completed support or keepout.
m=CFG["measured_module_mm"]
pd_corners=[tuple(round(v+d,4) for v,d in zip(carrier(p),(100,50))) for p in
            [(-m["width"]/2,m["length"]),(m["width"]/2,m["length"]),(m["width"]/2,0),(-m["width"]/2,0)]]
pd_edges={frozenset((pd_corners[i],pd_corners[(i+1)%4])) for i in range(4)}
drawn_edges=set()
for item in board.GetDrawings():
    if isinstance(item,pcb.PCB_SHAPE) and item.GetLayer()==pcb.Dwgs_User and item.GetShape()==pcb.SHAPE_T_SEGMENT:
        endpoints=tuple((round(pcb.ToMM(p.x),4),round(pcb.ToMM(p.y),4)) for p in (item.GetStart(),item.GetEnd()))
        drawn_edges.add(frozenset(endpoints))
assert pd_edges <= drawn_edges, "Missing/moved 12 x 23 mm HW-398 body reservation"
assert (MECH/"interface.scad").read_text()==scad_constants(), "SCAD parameters are stale"
for ref,(x,y) in zip(("H5","H6"),holes()):
    f=footprints[ref];p=list(f.Pads())[0]
    assert abs(pcb.ToMM(f.GetPosition().x)-100-x)<1e-5
    assert abs(pcb.ToMM(f.GetPosition().y)-50-y)<1e-5
    assert p.GetAttribute()==pcb.PAD_ATTRIB_NPTH
    assert abs(pcb.ToMM(p.GetDrillSize().x)-CFG["carrier_hole_diameter_mm"])<1e-5
    assert p.GetNetname()==""
zones=[z for z in board.Zones() if z.GetZoneName()=="HW398_CRADLE_C2_NO_COPPER"]
assert len(zones)==1, "Missing or duplicate cradle keepout"
z=zones[0]
assert z.GetIsRuleArea() and z.GetDoNotAllowTracks() and z.GetDoNotAllowVias() and z.GetDoNotAllowCopperPour()
assert z.GetLayerSet().Contains(pcb.F_Cu) and z.GetLayerSet().Contains(pcb.B_Cu)
outline=z.Outline().COutline(0)
actual_polygon=[(round(pcb.ToMM(outline.CPoint(i).x)-100,4),round(pcb.ToMM(outline.CPoint(i).y)-50,4)) for i in range(outline.PointCount())]
assert actual_polygon==[tuple(round(v,4) for v in pt) for pt in keepout_polygon()], "Cradle keepout outline is stale"
collisions=[]
for ref in list(expected)+["H1","H2","H3","H4"]:
    f=footprints[ref];f.BuildCourtyardCaches();bb=f.GetCourtyard(pcb.F_Cu).BBox()
    bounds=tuple(pcb.ToMM(v) for v in (bb.GetX()-pcb.FromMM(100),bb.GetY()-pcb.FromMM(50),bb.GetRight()-pcb.FromMM(100),bb.GetBottom()-pcb.FromMM(50)))
    for r in rectangles(CFG["keepout_margin_mm"]):
        if max(bounds[0],r[0]) < min(bounds[2],r[2]) and max(bounds[1],r[1]) < min(bounds[3],r[3]):
            collisions.append(ref)
assert not collisions,("Component courtyard intersects reserved cradle region",collisions)
for h,(x,y) in zip(["H1","H2","H3","H4"],[(4.305,6.52),(55.695,6.52),(4.305,81.66),(55.695,81.66)]):
    f=footprints[h]
    assert abs(pcb.ToMM(f.GetPosition().x)-100-x)<1e-5
    assert abs(pcb.ToMM(f.GetPosition().y)-50-y)<1e-5
    p=list(footprints[h].Pads())[0]
    assert abs(pcb.ToMM(p.GetDrillSize().x)-3)<1e-6
    assert p.GetAttribute()==pcb.PAD_ATTRIB_NPTH
erc=json.loads((root/"verification/erc.json").read_text())
ev=[v for sheet in erc["sheets"] for v in sheet["violations"]]
drc=json.loads((root/"verification/drc.json").read_text())
dc=Counter(v["type"] for v in drc["violations"])
report={"status":"ENGINEERING DRAFT - NOT FOR FABRICATION","logical_pin_checks":checks,
    "electrical_footprints":len(expected),"unassigned_footprints":[],
    "adc_socket_status":"10-pin module from user link; pitch, body offsets and fit still need physical verification",
    "pd_body_mm":[12,23],"pd_pcb_thickness_mm":1.5,"pd_total_height_mm":5,
    "pd_body_status":"User-measured; cradle geometry/interface checked; physical fit and load testing remain",
    "cradle_revision":CFG["revision"],"cradle_holes_mm":holes(),"cradle_drill_mm":CFG["carrier_hole_diameter_mm"],
    "cradle_courtyard_collisions":collisions,"cradle_copper_keepout_layers":["F.Cu","B.Cu"],
    "routed_tracks":len(board.GetTracks()),"erc_violations":len(ev),
    "drc_violations_by_type":dict(dc),"unconnected_items":len(drc["unconnected_items"]),
    "mount_pattern_mm":[51.39,75.14],"carrier_clearance_holes_mm":3.0,
    "interpretation":"Logical net agreement is not routing, fit validation, circuit simulation, or fabrication approval."}
(root/"verification/summary.json").write_text(json.dumps(report,indent=2)+"\n")
md="# Actual draft verification\n\n**NOT FOR FABRICATION.**\n\n"
md+=f"- Logical schematic checks: {checks} pin/net pairs agree with the design description.\n"
md+=f"- PCB: {len(expected)} electrical footprints agree with those logical net assignments.\n"
md+="- J8: 10-pin socket for the user-linked blue module; physical fit not yet verified.\n"
md+="- HW-398: user-measured 12 x 23 mm, 1.5 mm PCB, 5 mm total height; physical fit remains unverified.\n"
md+=f"- Cradle: 2.4 mm NPTH holes at {holes()}; SCAD/PCB interface agrees.\n"
md+="- Cradle: F.Cu/B.Cu track/via/pour keepout present; no electrical-component or WT32-hole courtyard intersects the reserved region.\n"
md+=f"- Native KiCad ERC: {len(ev)} violations. This does not verify module hardware or performance.\n"
md+=f"- Native KiCad DRC: {len(drc['violations'])} reported violations plus {len(drc['unconnected_items'])} unconnected items.\n"
md+="- Copper routing: zero tracks. No routing pass or Gerber release is claimed.\n"
md+="- Four 3.0 mm NPTH carrier clearance holes; WT32 pattern confirmed by user.\n\n"
if dc:
    md+="| DRC category | Count |\n|---|---:|\n"+"".join(f"| {t} | {n} |\n" for t,n in sorted(dc.items()))
md+="\nReports are retained without exclusions. Resolve actual violations and all README\nrelease gates before ordering. No electrical load, temperature, antenna, or physical\nfit test has been performed.\n"
(root/"verification/README.md").write_text(md)
print(json.dumps(report,indent=2))
