# Rev B draft assembly parts

Not a released purchasing BOM. DNP means do not populate. Values marked VERIFY
need measured load and exact-package selection. See README for release gates.

| Ref | Value / part | Footprint | Assembly |
|---|---|---|---|
| J1 | PD module output / 12V ONLY | Connector_Molex:Molex_KK-254_AE-6410-02A_1x02_P2.54mm_Vertical | THT |
| F1 | 2A HOLD - VERIFY | PitClaw:PTC_P5.08_DRAFT | THT |
| C1 | 470u / 35V | Capacitor_THT:CP_Radial_D10.0mm_P5.00mm | THT |
| C2 | 100n / 50V | Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P5.00mm | THT |
| D1 | P6KE18A | Diode_THT:D_DO-15_P12.70mm_Horizontal | THT |
| U2 | R-78B5.0-2.0 / 2A | Converter_DCDC:Converter_DCDC_RECOM_R-78B-2.0_THT | THT |
| C3 | 220u / 16V | Capacitor_THT:CP_Radial_D8.0mm_P3.50mm | THT |
| C4 | 100n / 50V | Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P5.00mm | THT |
| F2 | 0.75A HOLD - VERIFY | PitClaw:PTC_P5.08_DRAFT | THT |
| JP1 | REMOVE FOR WT32 USB | Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical | THT |
| F3 | 0.5A HOLD - VERIFY | PitClaw:PTC_P5.08_DRAFT | THT |
| C5 | 100u / 16V | Capacitor_THT:CP_Radial_D6.3mm_P2.50mm | THT |
| Q1 | FQP27P06 | Package_TO_SOT_THT:TO-220-3_Vertical | THT |
| R1 | 1k / 0.25W | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| Q2 | 2N3904 | Package_TO_SOT_THT:TO-92_Inline_Wide | THT |
| R2 | 2.2k | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R3 | 100k | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| F4 | 0.5A HOLD - VERIFY | PitClaw:PTC_P5.08_DRAFT | THT |
| D2 | 1N5819 | Diode_THT:D_DO-41_SOD81_P10.16mm_Horizontal | THT |
| R4 | 220R | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R5 | 10k | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| J2 | RJHSE-5080 / CHECK FOOTPRINT | PitClaw:RJHSE-5080_DRAFT | THT |
| J3 | WT32 EXT harness | Connector_Molex:Molex_KK-254_AE-6410-08A_1x08_P2.54mm_Vertical | THT |
| J7 | WT32 DEBUG 2 / 7 ONLY | Connector_Molex:Molex_KK-254_AE-6410-02A_1x02_P2.54mm_Vertical | THT |
| C7 | 4.7u / 10V | Capacitor_THT:CP_Radial_D5.0mm_P2.00mm | THT |
| C13 | 100n / 50V | Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P5.00mm | THT |
| R17 | 4.7k DNP | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | DNP |
| R18 | 4.7k DNP | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | DNP |
| BZ1 | PASSIVE PIEZO / VERIFY PART | Buzzer_Beeper:Buzzer_12x9.5RM7.6 | THT |
| Q3 | 2N3904 | Package_TO_SOT_THT:TO-92_Inline_Wide | THT |
| R6 | 2.2k | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R7 | 100k | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| D3 | 1N5819 DNP | Diode_THT:D_DO-41_SOD81_P10.16mm_Horizontal | DNP |
| J4 | MJ1-2503A / PIT | PitClaw:MJ1-2503A | THT |
| R10 | 10k / 0.1% | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R13 | 1k | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| C10 | 100n / 50V | Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P5.00mm | THT |
| J5 | MJ1-2503A / MEAT 1 | PitClaw:MJ1-2503A | THT |
| R11 | 10k / 0.1% | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R14 | 1k | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| C11 | 100n / 50V | Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P5.00mm | THT |
| J6 | MJ1-2503A / MEAT 2 | PitClaw:MJ1-2503A | THT |
| R12 | 10k / 0.1% | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R15 | 1k | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| C12 | 100n / 50V | Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P5.00mm | THT |
| J8 | ADS1115 BLUE / 1x10 SOCKET | PitClaw:ADS1115_Blue_1x10_DRAFT | THT |
| R16 | 1k | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |

Also required: user's preassembled blue 10-pin ADS1115 module; preassembled PD
trigger; one 1x10 / 2.54 mm female socket for J8 (fit-check module pitch first);
HW398-C2 reinforced printed base/retainer (fit-test first); 2x M2x16 screws, 4x M2 washers
(OD <=5mm), 2x ordinary M2 nuts; WT32 EXT/DEBUG harnesses; JP1 shunt;
unthreaded insulating spacers; 2.3-2.5 mm self-tapping screws of verified
engagement/length (TBD). Support the ADC module's free edge with insulation;
its mounting-hole coordinates have not been assumed or drilled into the carrier.
