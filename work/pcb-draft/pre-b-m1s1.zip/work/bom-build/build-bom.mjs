import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { Workbook, SpreadsheetFile, FileBlob } from '@oai/artifact-tool';

const root = '/Users/eugene.borokhov/Documents/Code/pitclaw';
const out = `${root}/hardware/carrier-revb/bom`;
const scratch = `${root}/work/bom-build`;
if(process.argv.includes('--inspect-existing')){
  const current=await SpreadsheetFile.importXlsx(await FileBlob.load(`${out}/pitclaw-carrier-digikey-bom.xlsx`));
  console.log((await current.inspect({kind:'table',range:'Order!A6:J6',include:'values,formulas',tableMaxRows:1,tableMaxCols:10,maxChars:2200})).ndjson);
  console.log((await current.inspect({kind:'table',range:'Order!A38:H42',include:'values,formulas',tableMaxRows:5,tableMaxCols:8,maxChars:2200})).ndjson);
  for(const [sheetName,range,label] of [['Order','A1:H12','order'],['Parts','A1:F8','parts'],['Other items','A1:D10','other']]){
    const img=await current.render({sheetName,range,scale:1,format:'png'});
    await fs.writeFile(`${scratch}/before-mini100-${label}.png`,new Uint8Array(await img.arrayBuffer()));
  }
  process.exit(0);
}
if(process.argv.includes('--verify-preservation')){
  const before=await SpreadsheetFile.importXlsx(await FileBlob.load(`${scratch}/before-m1/pitclaw-carrier-digikey-bom.xlsx`));
  const after=await SpreadsheetFile.importXlsx(await FileBlob.load(`${out}/pitclaw-carrier-digikey-bom.xlsx`));
  const checks=[['Order','A7:J36'],['Parts','A7:S36'],['Other items','A6:D8'],['Other items','A10:D18'],['Other items','A20:D23'],['Other items','A25:D25']];
  for(const [name,address] of checks){
    const a=before.worksheets.getItem(name).getRange(address),b=after.worksheets.getItem(name).getRange(address);
    assert.deepEqual(b.values,a.values,`${name}!${address} values changed unexpectedly`);
    assert.deepEqual(b.formulas,a.formulas,`${name}!${address} formulas changed unexpectedly`);
  }
  const report={revision:'B-M1',comparedTo:'B-DK1',unchangedValueAndFormulaRanges:checks,visualBaselineReviewed:true,changedSheetsReviewed:['Order','Parts','Other items']};
  await fs.writeFile(`${root}/hardware/carrier-revb/verification/bom-preservation.json`,JSON.stringify(report,null,2)+'\n');
  console.log('Unrelated BOM ranges and formulas preserved; U2/header, related summaries and external-module requirements changed as intended.');
  process.exit(0);
}
const data = JSON.parse(await fs.readFile(`${out}/selection.json`, 'utf8'));
const assembly = await fs.readFile(`${root}/hardware/carrier-revb/parts.md`, 'utf8');
const footprints = Object.fromEntries(assembly.split('\n').filter(l => /^\| [A-Z]+\d+ \|/.test(l)).map(l => {
  const cells = l.split('|').map(v => v.trim()); return [cells[1], cells[4]];
}));
const rows = [...data.parts.map(p => ({...p, category:p.dnp?'DNP':'Carrier', needed:p.dnp?0:p.refs.length})),
  ...data.accessories.map(p => ({...p, category:'Harness', needed:p.qty}))];
assert.equal(Object.keys(footprints).length,47);
assert.equal(data.parts.filter(p=>!p.dnp).reduce((s,p)=>s+p.refs.length,0),45);
const priceAt = (p,q) => q===0?0:p.prices.filter(t=>t[0]<=q).at(-1)[1];
const bestQty = p => p.needed===0?0:[p.needed,...p.prices.map(t=>t[0]).filter(q=>q>=p.needed)]
  .sort((a,b)=>a*priceAt(p,a)-b*priceAt(p,b)||a-b)[0];
rows.forEach(p => p.order=bestQty(p));
const wb = Workbook.create();
const order=wb.worksheets.add('Order');
const parts=wb.worksheets.add('Parts');
const other=wb.worksheets.add('Other items');
const font='Helvetica Neue'; // Verified /System/Library/Fonts/HelveticaNeue.ttc on the target Mac.
function base(sh,range,widths,title,subtitle){
  sh.showGridLines=false;
  sh.getRange(range).format.font={name:font,size:11,color:'#202A34'};
  sh.getRange(range).format.rowHeight=31;
  sh.getRange(range).format.verticalAlignment='center';
  sh.getRange(range).format.wrapText=true;
  widths.forEach((w,i)=>sh.getRangeByIndexes(0,i,1,1).format.columnWidthPx=w);
  sh.getRange('A1').values=[[title]];
  sh.getRange('A1').format.font={name:font,size:16,bold:true};
  sh.getRange('A1').format.wrapText=false;
  sh.getRange('A2').values=[[subtitle]];
  sh.getRange('A2').format.wrapText=false;
  sh.getRange('A2:H2').format.borders={bottom:{style:'thin',color:'#AFBAC4'}};
}
function header(sh,address,values){
  sh.getRange(address).values=[values];
  sh.getRange(address).format={fill:'#34485A',font:{name:font,size:11,bold:true,color:'#FFFFFF'},
    horizontalAlignment:'center',verticalAlignment:'center',wrapText:true,rowHeight:35,
    borders:{insideVertical:{style:'thin',color:'#FFFFFF'}}};
}
function stripe(sh,first,last,end){
  for(let r=first;r<=last;r++) if(r%2===0)sh.getRange(`A${r}:${end}${r}`).format.fill='#F2F5F7';
}
const first=6,last=first+rows.length-1,total=last+2;
base(order,`A1:J${total+8}`,[172,215,68,68,85,85,68,216,360,430],
  'Pit Claw carrier BOM', 'Rev B-M1. One carrier. DigiKey US price snapshot, 2026-09-04. USD.');
order.getRange('A3').values=[['Unrouted PCB: not for fabrication. Parts subtotal excludes existing modules, PCB and mounting hardware.']];
order.getRange('A3').format.wrapText=false;
order.getRange('A4').values=[['Order quantities are editable (amber). Pricing follows the sampled breaks on Parts; refresh before checkout or larger builds.']];
order.getRange('A4').format.wrapText=false;
header(order,'A5:J5',['References','Manufacturer part number','Needed','Order qty','Unit USD','Line USD','Spare qty','DigiKey part number','Source URL','Order note']);
order.getRange(`A${first}:J${last}`).values=rows.map(p=>[p.refs.join(', '),p.mpn,p.needed,p.order,null,null,null,p.sku,p.url,
  p.dnp?'DNP. Order only if module lacks suitable I2C pull-ups.':p.order>p.needed?'Price break makes this quantity cheaper than the exact need.':p.category==='Harness'?p.notes:'Fitted carrier part. See Parts for specifications and assembly cautions.']);
stripe(order,first,last,'J');
order.getRange(`D${first}:D${last}`).format.fill='#FFF2CC';
order.getRange(`C${first}:G${last}`).format.horizontalAlignment='right';
order.getRange(`C${first}:D${last}`).setNumberFormat('#,##0');
order.getRange(`G${first}:G${last}`).setNumberFormat('#,##0');
order.getRange(`E${first}:E${last}`).setNumberFormat('"$"0.00000');
order.getRange(`F${first}:F${last}`).setNumberFormat('"$"0.00');
order.getRange(`A${first}:J${last}`).format.rowHeight=66;
order.dataValidations.add({range:`D${first}:D${last}`,rule:{type:'whole',operator:'greaterThanOrEqual',formula1:0}});
order.getRange(`G${first}:G${last}`).conditionalFormats.add('cellIs',{operator:'lessThan',formula:0,format:{fill:'#FCE4D6',font:{color:'#9C0006'}}});
order.freezePanes.freezeRows(5);

base(parts,`A1:S${last}`,[172,140,215,350,430,290,360,82,70,85,70,85,70,85,70,85,70,85,70],
  'Part specifications and price breaks','Rev B-M1. U2 and J8 are sockets for owned modules. Sources checked 2026-09-04.');
parts.getRange('A3').values=[['Package drawings guide selection. Physical sample fit and loaded/thermal testing remain required.']];
parts.getRange('A3').format.wrapText=false;
parts.getRange('A4').values=[['Price-break pairs start at I. Unit prices are a public snapshot, not a quote. Blank stock means not recorded.']];
parts.getRange('A4').format.wrapText=false;
header(parts,'A5:S5',['References','Manufacturer','Part number','KiCad footprint','Assembly notes','Specification','Source URL','Stock','Qty 1','Price 1 USD','Qty 2','Price 2 USD','Qty 3','Price 3 USD','Qty 4','Price 4 USD','Qty 5','Price 5 USD','State']);
parts.getRange(`A${first}:S${last}`).values=rows.map(p=>{
  const pp=Array.from({length:5},(_,i)=>p.prices[i]||[null,null]).flat();
  return [p.refs.join(', '),p.manufacturer,p.mpn,p.category==='Harness'?'Off-board accessory':footprints[p.refs[0]],p.notes,p.description,p.url,p.stock??null,...pp,p.category];
});
stripe(parts,first,last,'S');
parts.getRange(`A${first}:S${last}`).format.rowHeight=88;
parts.getRange(`H${first}:R${last}`).format.horizontalAlignment='right';
for(const col of ['J','L','N','P','R'])parts.getRange(`${col}${first}:${col}${last}`).setNumberFormat('"$"0.00000');
for(const col of ['H','I','K','M','O','Q'])parts.getRange(`${col}${first}:${col}${last}`).setNumberFormat('#,##0');
parts.freezePanes.freezeRows(5);
for(let i=0;i<rows.length;i++){
  const p=rows[i],r=first+i;
  let expr=`'Parts'!J${r}`;
  for(let t=1;t<p.prices.length;t++){
    const qtyCol=String.fromCharCode(73+t*2),priceCol=String.fromCharCode(74+t*2);
    expr=`IF(D${r}>='Parts'!${qtyCol}${r},'Parts'!${priceCol}${r},${expr})`;
  }
  order.getRange(`E${r}:G${r}`).formulas=[[`=IF(D${r}=0,0,${expr})`,`=ROUND(D${r}*E${r},2)`,`=D${r}-C${r}`]];
}
order.getRange(`A${total}`).values=[['DigiKey parts subtotal']];
order.getRange(`F${total}`).formulas=[[`=SUM(F${first}:F${last})`]];
order.getRange(`A${total}:H${total}`).format.borders={top:{style:'thin',color:'#596C7B'}};
order.getRange(`A${total}:H${total}`).format.font={name:font,size:11,bold:true};
order.getRange(`F${total}:F${total+2}`).setNumberFormat('"$"0.00');
order.getRange(`A${total+1}`).values=[['Carrier parts only']];
order.getRange(`F${total+1}`).formulas=[[`=SUM(F${first}:F${first+data.parts.length-1})`]];
order.getRange(`A${total+2}`).values=[['Mates, shunt, header']];
order.getRange(`F${total+2}`).formulas=[[`=SUM(F${first+data.parts.length}:F${last})`]];
order.getRange(`A${total+4}`).values=[['Shipping, tax, tariffs, bare PCB, print material, wire, crimp tools and unpriced items on Other items are excluded.']];
order.getRange(`A${total+4}`).format.wrapText=false;
order.getRange(`A${total+5}`).values=[['The CSV contains the initial 31 purchase lines. It does not update automatically when this workbook is edited.']];
order.getRange(`A${total+5}`).format.wrapText=false;

const excluded=[
 ['WT32-SC01 Plus',1,'Existing display/controller','51.39 × 75.14 mm mounting pattern confirmed. Absolute orientation, stack and antenna clearance still need checking.'],
 ['ADS1115 blue 10-pin module',1,'Already owned','VDD, GND, SCL, SDA, ADDR, ALRT, A0–A3. Confirm 2.54 mm pitch, module edge offsets and total socketed height.'],
 ['HW398 USB-C PD trigger',1,'Already owned','12 × 23 mm PCB, 1.5 mm thick, total 5 mm. Confirm 12 V output before connection. No new trigger module ordered.'],
 ['Mini100 buck module',1,'Already owned; Traco removed','Weewooday B08JZ5FVLC. Set/verify 5 V. User: 2.54 mm pitch, 1.5 mm row-to-edge. Socket/header included in order; support and load tests remain. https://www.amazon.com/dp/B08JZ5FVLC/'],
 ['Carrier bare PCB',1,'Not yet orderable','60 × 92 mm draft. Zero routed tracks. Resolve footprint, antenna, mechanical and load checks before routing and Gerber release.'],
 ['HW398-C2 printed base',1,'Print existing STL','Beefier C2 dimensions unchanged. Fit-test with actual module before PCB fabrication.'],
 ['HW398-C2 printed retainer',1,'Print existing STL','Verify USB plug clearance and clamp seating; do not load components or unsupported solder joints.'],
 ['HW398-C2 plastic test plate',1,'Optional print','Use for cradle fit testing before ordering the PCB.'],
 ['M2 × 16 mm screws',2,'Source locally / unpriced','Cradle screws. Verify fit-test engagement and clearance with actual print.'],
 ['M2 washers, OD ≤5 mm',4,'Source locally / unpriced','Two at screw heads and two below carrier, according to the cradle assembly instructions.'],
 ['M2 ordinary nuts',2,'Source locally / unpriced','UNDER carrier PCB, not under base floor. Provide at least 3 mm clearance to the WT32 behind the PCB.'],
 ['Unthreaded insulating WT32 spacers',4,'Length not determined','Choose from actual rear components, trimmed leads and screw engagement. Do not assume a 10 mm length.'],
 ['WT32 self-tapping screws, 2.3–2.5 mm',4,'Length not determined','Engage existing WT32 mounts. Not M2/M3 machine screws; do not tap or enlarge the WT32 holes.'],
 ['ADC and Mini100 insulating supports',2,'Geometry not determined','Support both free edges and retain modules for transport. Mini100 nominal underside height 11.05 mm; verify actual socket/header seating and underside protrusions. No guessed module mounting holes.'],
 ['WT32-end EXT / DEBUG mates',2,'Not included in DigiKey order','Confirm exact WT32 connector and mating cable. JST-XH BOM parts are only the carrier ends of these harnesses.'],
 ['Hookup wire / insulation',null,'As required; unpriced','Prefer 22 AWG for power where practical. Label and secure 12 V J1 separately from 3.3 V J7; their 2-pin housings interchange physically.'],
 ['Crimp tool and assembly supplies',null,'Existing or source separately','Correct crimps, solder, insulation and strain relief required. Bare contact price excludes crimping labor/tool.'],
 ['USB-C PD source and cable',1,'Existing or source separately','Source must support suitable 12 V output and load current. Confirm trigger selection with meter.'],
 ['HeaterMeter blower / MG90S / cable',1,'Existing assembly','Measure startup/loaded motion and combined RJ45 return current. F1–F4 unchanged pending testing. Do not connect carrier RJ45 to Ethernet equipment.'],
 ['2.5 mm NTC probes',3,'Existing / up to three','PIT, MEAT 1, MEAT 2. Verify calibration and firmware excitation-reference equation before thermal testing.']
];
base(other,`A1:H${excluded.length+8}`,[260,72,250,690,40,40,40,40],
  'Other assembly requirements','Not included in the DigiKey subtotal. Unknown quantities and prices are left blank, not assumed free.');
other.getRange('A3').values=[['Cradle mounting hardware and WT32 stack lengths must be checked on the real assembly.']];
other.getRange('A3').format.wrapText=false;
header(other,'A5:D5',['Item','Qty','Procurement','Assembly requirement']);
other.getRange(`A6:D${5+excluded.length}`).values=excluded;
stripe(other,6,5+excluded.length,'D');
other.getRange(`A6:D${5+excluded.length}`).format.rowHeight=62;
other.getRange(`B6:B${5+excluded.length}`).setNumberFormat('#,##0');
other.freezePanes.freezeRows(5);

// Reconcile each price/quantity against independently calculated source tiers.
const calculated=order.getRange(`C${first}:G${last}`).values;
let independentlyTotal=0;
for(let i=0;i<rows.length;i++){
  const p=rows[i],expectedUnit=priceAt(p,p.order),expectedLine=Math.round(p.order*expectedUnit*100)/100;
  assert.equal(calculated[i][0],p.needed);
  assert.equal(calculated[i][1],p.order);
  assert.ok(Math.abs(calculated[i][2]-expectedUnit)<1e-8);
  assert.ok(Math.abs(calculated[i][3]-expectedLine)<1e-8);
  assert.equal(calculated[i][4],p.order-p.needed);
  independentlyTotal+=expectedLine;
}
assert.ok(Math.abs(order.getRange(`F${total}`).values[0][0]-independentlyTotal)<1e-8);
assert.ok(Math.abs(independentlyTotal-21.93)<1e-8);
// Exercise the important tier boundary, then restore the final order.
const capRow=first+rows.findIndex(p=>p.refs.includes('C2'));
order.getRange(`D${capRow}`).values=[[6]];
assert.ok(Math.abs(order.getRange(`F${capRow}`).values[0][0]-1.74)<1e-8);
order.getRange(`D${capRow}`).values=[[10]];
assert.ok(Math.abs(order.getRange(`F${total}`).values[0][0]-21.93)<1e-8);
console.log((await wb.inspect({kind:'table',range:`Order!A${total}:H${total+2}`,include:'values,formulas',tableMaxRows:3,tableMaxCols:8,maxChars:2500})).ndjson);
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:300},maxChars:3000});
console.log(errors.ndjson);
for(const [sheetName,range,name] of [['Order','A1:H21','order-top'],['Order',`A22:H${total+2}`,'order-bottom'],
  ['Parts','A1:F13','parts'],['Parts','H5:S13','price-breaks'],['Other items',`A1:D${5+excluded.length}`,'other-items']]){
  const img=await wb.render({sheetName,range,scale:1,format:'png'});
  await fs.writeFile(`${scratch}/${name}.png`,new Uint8Array(await img.arrayBuffer()));
}
const csvCell=v=>'"'+String(v??'').replaceAll('"','""')+'"';
const csvRows=[['Manufacturer Part Number','Digi-Key Part Number','Quantity','Customer Reference'],
  ...rows.filter(p=>p.order>0).map(p=>[p.mpn,p.sku,p.order,p.refs.join(', ')])];
assert.equal(csvRows.length-1,31);
await fs.writeFile(`${out}/pitclaw-carrier-digikey-import.csv`,csvRows.map(r=>r.map(csvCell).join(',')).join('\r\n')+'\r\n');
await fs.writeFile(`${scratch}/bom-verification.json`,JSON.stringify({revision:data.revision,totalUSD:21.93,populatedPCBReferences:45,dnpPCBReferences:2,purchaseLines:31,priceTierBoundaryTest:true,formulaErrors:errors.ndjson},null,2));
const xlsx=await SpreadsheetFile.exportXlsx(wb);
await xlsx.save(`${out}/pitclaw-carrier-digikey-bom.xlsx`);
console.log('Exported workbook and DigiKey import CSV. Subtotal USD 21.93.');
