# Carrier simplification review

2026-09-04. B-M1 Mini100 / MG90S prototype.

The buzzer driver is the strongest simplification candidate. F2 may be removable
after checking converter fault behavior and branch wiring. The servo PTC needs
load-based selection, not automatic deletion or uprating. The blower level
shifter and probe filters have distinct functions and should stay.

**Review only:** no buzzer-driver or fuse removal is implemented. B-M1 changes
the converter interface and associated placement/BOM. No hardware tests were run.

## Buzzer: candidate to simplify

CPT-1255C-090 is a passive piezo, not an unknown magnetic or active buzzer.
The manufacturer specifies 70 dB minimum at 10 cm with a 3 V peak-to-peak,
4 kHz square wave, and 8.4–15.6 nF capacitance. That supports trying direct
3.3 V logic drive, but does not establish useful outdoor/enclosed audibility.
[Same Sky datasheet](https://www.sameskydevices.com/product/resource/cpt-1255c-090.pdf)

Proposed, **not applied**: `GPIO14 → 330 ohm → piezo → GND`.

Remove Q3, R7 and R19; repurpose R6 as the series resistor. That means three
fewer populated parts and no extra GPIO. Do not leave the piezo connected to
5 V when bypassing Q3. Drive both levels actively at about 4 kHz, holding low
when off. The resistor bounds an ideal 3.3 V capacitive-step current to 10 mA;
the maximum specified capacitance gives a 5.1 us RC time constant versus a
125 us half-cycle. These are first-order checks, not a resonance/acoustic
simulation. Verify the actual waveform and pin excursions. Espressif's DC-current
figures depend on drive strength and output voltage; they are not universal
absolute-current limits. [ESP32-S3 datasheet](https://www.espressif.com/sites/default/files/documentation/esp32-s3_datasheet_en.pdf)

If insufficiently audible, retain the present 5 V driver. **R19 is useful in
that circuit**: it discharges the piezo while Q3 is off. It becomes unnecessary
when both levels are actively driven. Firmware currently sets ALARM_BUZZER_FREQ
to **2000** in firmware/src/config.h. Test 4000 Hz in a separately approved
firmware update; no firmware was modified here.

## Fuses: distinct intended fault coverage

| Part | Assessment and recommendation |
|---|---|
| F1, input 2 A hold | Keep main input protection. Verify source fault current, trip coordination and downstream ratings. |
| F2, WT32 0.75 A hold | Best removal candidate after verifying the buck, traces and harness remain adequately protected. Keep JP1 regardless. |
| F3, servo 0.5 A hold | External cable protection has a purpose, but this provisional value may sag or trip during loaded MG90S movement. Select from measured load, ambient and cable limits. |
| F4, blower 0.5 A hold | The external branch may have a lower safe current than the whole input. Keep provision; check actual blower current and drop. |

MF-R050 initial resistance can reach 0.77 ohm at 23 C. An **illustrative**
0.5 A load then loses 0.385 V before cable/contact loss or self-heating. This
is not a measured MG90S current. Hold current falls to 0.32 A at 60 C.
MF-R075 initial resistance can reach 0.40 ohm. PTCs are not fast or precise
current limits and do not guarantee semiconductor or servo-stall protection.
[Bourns MF-R datasheet](https://bourns.com/docs/product-datasheets/mf-r.pdf)

One upstream fuse does not reliably cover every branch: a buck can deliver
more current at 5 V than it draws at 12 V, and limiting may prevent F1 from
tripping. Conversely, a branch PTC may not isolate a fault before WT32 resets.
Mini100's advertised short-circuit feature does not establish safe coordination.
A lower-resistance conventional fuse is another option if measured PTC drop is
excessive, but needs a new time/current selection and holder. Neither fuse type
is output overvoltage protection for a buck that fails input-to-output short.

## Other components

| Elements | Finding |
|---|---|
| Q2/Q1 blower stage | Keep. Q2 translates 3.3 V logic to the 12 V P-channel gate. A low-side switch would disturb the shared fan/servo ground. Q1 is oversized in current rating, but a cheaper replacement also needs gate-charge, loss and THT-package checks. |
| R1 1 k gate pull-up | About 0.144 W at continuous fan-on. Increasing it slows turn-off. Firmware requests 25 kHz PWM: scope gate/drain and check Q1 temperature before accepting switching loss or changing R1. |
| R17/R18 pull-ups | Already DNP when the ADC has suitable pull-ups. Optional pads add no purchased parts. |
| Probe RC filters / AIN3 rail measurement | Keep for long probe leads and nearby switching loads. [ADS1115](https://www.ti.com/product/ADS1115) has an internal conversion reference, separate from probe excitation. |
| 0.1% probe-bias resistors | Ordinary 1% parts could be used with measured per-channel calibration and firmware support. Firmware currently has one shared reference-resistance constant; do not substitute silently. |
| C1/C3/C5 bulk capacitors | Module capacitors do not automatically replace local storage. Values remain subject to transient/startup tests, not removal merely because capacitors also exist on the modules. |
| D1 TVS / D2 fan clamp | Keep pending measured transients. These do not protect against a deliberately wrong sustained PD voltage. |
| JP1 power isolation | Keep to avoid unverified paralleling of WT32 programming USB and carrier 5 V. |
| Separate 3.3 V LDO | Already omitted; no further saving here. DEBUG-powered ADC still needs its loaded-rail test. |

Recommended sequence: bench-test direct-drive piezo audibility, then measure
WT32/MG90S rail drop and assess F2/F3. The $21.93 B-M1 order includes no savings
from these proposed removals. It is $6.02 below the old $27.95 BOM solely because
the owned Mini100 replaces Traco, adding a $0.43 socket and $0.44 header.
Shipping, tax, PCB, printing, wire and mounting hardware remain excluded.
