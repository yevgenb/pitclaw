# Pending power-module and protection decisions

The user confirmed an MG90S damper servo plus a blower fan, and chose to retain
the existing Mini100 step-down module instead of purchasing Traco U2.

## Mini100 interface implemented in B-M1; physical validation pending

Use HW398 set to 12 V for the blower path. Use Mini100 to supply regulated 5 V
to WT32 and MG90S. Continue powering ADS1115 from the WT32 DEBUG 3.3 V rail,
subject to the previously documented low-current rail test. Keep the reinforced
HW398-C2 cradle and the WT32 mounting pattern.

The user has now supplied the exact Weewooday listing, Amazon ASIN B08JZ5FVLC.
The [module review](mini100-module-review.md) records the seller's dimensions,
four-pad connection layout, voltage selection and limitations. The user confirmed
2.54 mm pitch and 1.5 mm row-to-short-edge spacing. A direct socket/header footprint
is now in CAD. Row centering, module hole/header fit, physical support/retention
and stacked height still need checking. Load/thermal and fault behavior also
remain application tests. Do not assume the Traco's 2 A rating,
common-ground SIP-3 pinout or 820 uF capacitive-load limit applies.

The current XLSX/CSV/selection.json and native CAD now agree on B-M1. Traco is
removed from the order and replaced by the module socket and male header. Earlier
B-DK1 archives remain historical only. The advertised short-circuit feature does
not establish safe fault coordination and is not approval to remove F2. See the
[simplification review](simplification-review.md) for the buzzer and fuse decisions.

## Why the draft has four PTCs

| Ref | Location | Intended fault coverage |
|---|---|---|
| F1 | 12 V input after HW398 | Input wiring and downstream carrier faults, subject to available fault current and trip coordination. |
| F2 | 5 V WT32 branch | Display-board/harness overcurrent. First candidate for simplification if Mini100 protection also adequately protects this path. |
| F3 | 5 V servo output | External servo/cable faults. Does not guarantee protection against servo mechanical stall. |
| F4 | Switched 12 V blower output | External fan/cable faults. Shares a return conductor with the servo. |

These are intended coverage areas, not verified protection claims. The 12 V
input device does not automatically cover the 5 V branches: buck conversion and
current limiting can keep input current below the input PTC's trip threshold
during an output overload. Conversely, a branch PTC is not a fast or precise
current limiter and is not guaranteed to protect semiconductors or isolate a
fault before WT32 resets. Its resistance adds voltage drop and its hold rating
decreases with ambient temperature.

No fuse removal or uprating was requested or performed. Consider deleting F2
only after verifying converter fault behavior and WT32 wiring/trace ratings.
Retain JP1 programming-power isolation even if F2 is later removed. Re-evaluate
the provisional F3 0.5 A PTC for MG90S startup, loaded motion and enclosure
temperature; select neither its final rating nor the blower PTC by model name
alone. Verify the combined servo-plus-fan return against the RJ45 contact and
cable ratings. Never assume the 12 V source's own protection is sufficient.

TowerPro's MG90S product page does not publish a stall-current specification, so
an assumed universal MG90S stall current is not used to approve the supply.

Sources: [TowerPro MG90S](https://towerpro.com.tw/product/mg90s-3/),
[Bourns PTC selection worksheet](https://www.bourns.com/docs/technical-documents/technical-library/multifuse-pptc-resettable-fuses/publications/bourns_multifuse_product_selection_worksheet.pdf).
