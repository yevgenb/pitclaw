# Rev B-M1 assembly parts

DigiKey selection dated 2026-09-04; see bom/ for priced purchasing lists.
Engineering draft, not fabrication approval. DNP means do not populate.
U2 and J8 purchasing part numbers are SOCKETS, not the already-owned modules.

| Ref | Value | Manufacturer part number | Footprint | Assembly |
|---|---|---|---|---|
| J1 | PD module output / 12V ONLY | B2B-XH-A | Connector_JST:JST_XH_B2B-XH-A_1x02_P2.50mm_Vertical | THT |
| F1 | 2A HOLD / MF-RHT200/32 | MF-RHT200/32-2 | PitClaw:PTC_Bourns_MF-RHT200-32_P5.1 | THT |
| C1 | 470u / 35V | 35PX470MEFC10X12.5 | Capacitor_THT:CP_Radial_D10.0mm_P5.00mm | THT |
| C2 | 100n / 50V | K104K15X7RF5TH5 | PitClaw:C_Vishay_K104K15X7RF5TH5_P5 | THT |
| D1 | P6KE18A | P6KE18A-TP | Diode_THT:D_DO-15_P12.70mm_Horizontal | THT |
| U2 | Mini100 / SET 5V / SOCKET | PPPC041LFBN-RC | PitClaw:Mini100_1x04_P2.54mm | THT |
| C3 | 220u / 16V | 16ZLH220MEFCT16.3X11 | Capacitor_THT:CP_Radial_D6.3mm_P2.50mm | THT |
| C4 | 100n / 50V | K104K15X7RF5TH5 | PitClaw:C_Vishay_K104K15X7RF5TH5_P5 | THT |
| F2 | 0.75A HOLD / MF-R075 | MF-R075 | PitClaw:PTC_Bourns_MF-R075_P5.1 | THT |
| JP1 | REMOVE FOR WT32 USB | 68000-102HLF | Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical | THT |
| F3 | 0.5A HOLD / MF-R050 | MF-R050 | PitClaw:PTC_Bourns_MF-R050_P5.1 | THT |
| C5 | 100u / 16V | 16ZLH100MEFC5X11 | Capacitor_THT:CP_Radial_D5.0mm_P2.00mm | THT |
| Q1 | FQP27P06 | FQP27P06 | Package_TO_SOT_THT:TO-220-3_Vertical | THT |
| R1 | 1k / 0.25W | MFR-25FBF52-1K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| Q2 | 2N3904 | 2N3904BU | Package_TO_SOT_THT:TO-92_Inline_Wide | THT |
| R2 | 2.2k | MFR-25FBF52-2K2 | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R3 | 100k | MFR-25FBF52-100K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| F4 | 0.5A HOLD / MF-R050 | MF-R050 | PitClaw:PTC_Bourns_MF-R050_P5.1 | THT |
| D2 | 1N5819 | 1N5819-TP | Diode_THT:D_DO-41_SOD81_P10.16mm_Horizontal | THT |
| R4 | 220R | MFR-25FBF52-220R | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R5 | 10k | MFR-25FBF52-10K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| J2 | RJHSE-5080 / CHECK FOOTPRINT | RJHSE5080 | PitClaw:RJHSE-5080_DRAFT | THT |
| J3 | WT32 EXT harness | B8B-XH-A | Connector_JST:JST_XH_B8B-XH-A_1x08_P2.50mm_Vertical | THT |
| J7 | WT32 DEBUG 2 / 7 ONLY | B2B-XH-A | Connector_JST:JST_XH_B2B-XH-A_1x02_P2.50mm_Vertical | THT |
| C7 | 4.7u / 100V | 100YXJ4R7M5X11 | Capacitor_THT:CP_Radial_D5.0mm_P2.00mm | THT |
| C13 | 100n / 50V | K104K15X7RF5TH5 | PitClaw:C_Vishay_K104K15X7RF5TH5_P5 | THT |
| R17 | 4.7k DNP | MFR-25FBF52-4K7 | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | DNP |
| R18 | 4.7k DNP | MFR-25FBF52-4K7 | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | DNP |
| BZ1 | CPT-1255C-090 / PIEZO | CPT-1255C-090 | PitClaw:Piezo_CPT-1255C-090_D12_P5 | THT |
| Q3 | 2N3904 | 2N3904BU | Package_TO_SOT_THT:TO-92_Inline_Wide | THT |
| R6 | 2.2k | MFR-25FBF52-2K2 | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R7 | 100k | MFR-25FBF52-100K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R19 | 1k / PIEZO DISCHARGE | MFR-25FBF52-1K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| J4 | MJ1-2503A / PIT | MJ1-2503A | PitClaw:MJ1-2503A | THT |
| R10 | 10k / 0.1% | MFP-25BRD52-10K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R13 | 1k | MFR-25FBF52-1K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| C10 | 100n / 50V | K104K15X7RF5TH5 | PitClaw:C_Vishay_K104K15X7RF5TH5_P5 | THT |
| J5 | MJ1-2503A / MEAT 1 | MJ1-2503A | PitClaw:MJ1-2503A | THT |
| R11 | 10k / 0.1% | MFP-25BRD52-10K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R14 | 1k | MFR-25FBF52-1K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| C11 | 100n / 50V | K104K15X7RF5TH5 | PitClaw:C_Vishay_K104K15X7RF5TH5_P5 | THT |
| J6 | MJ1-2503A / MEAT 2 | MJ1-2503A | PitClaw:MJ1-2503A | THT |
| R12 | 10k / 0.1% | MFP-25BRD52-10K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| R15 | 1k | MFR-25FBF52-1K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |
| C12 | 100n / 50V | K104K15X7RF5TH5 | PitClaw:C_Vishay_K104K15X7RF5TH5_P5 | THT |
| J8 | ADS1115 BLUE / 1x10 SOCKET | PPPC101LFBN-RC | PitClaw:ADS1115_Blue_1x10_DRAFT | THT |
| R16 | 1k | MFR-25FBF52-1K | Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal | THT |

Also required: existing WT32, blue 10-pin ADS1115, Mini100 and HW398 modules;
Mini100 male header, free-edge insulating support and retention; HW398-C2
printed base/retainer (fit-test first); 2x M2x16 screws, 4x M2 washers (OD <=5mm),
2x ordinary M2 nuts UNDER the carrier; harness mates, contacts, wire, JP1 shunt;
4 unthreaded insulating WT32 spacers and 4 self-tapping screws (2.3-2.5mm, length
TBD). Support both socketed modules' free edges. No undocumented module mounting
holes are drilled into the carrier. See bom/README.md for assembly cautions.
