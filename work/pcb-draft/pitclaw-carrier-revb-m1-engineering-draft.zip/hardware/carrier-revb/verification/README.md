# Actual draft verification

**NOT FOR FABRICATION.**

- Logical schematic checks: 122 pin/net pairs agree with the design description.
- PCB: 47 electrical footprints agree with those logical net assignments.
- J8: 10-pin socket for the user-linked blue module; physical fit not yet verified.
- U2: Mini100 4-pin socket replaces Traco. User-confirmed 2.54 mm pitch and 1.5 mm row/edge offset; polarity and coordinates checked independently. EN is not connected.
- U2: switching-body F.Cu/B.Cu no-track/via/pour area; header breakout strip remains available. Row centering, height, support/retention and load tests remain.
- HW-398: user-measured 12 x 23 mm, 1.5 mm PCB, 5 mm total height; physical fit remains unverified.
- Cradle: 2.4 mm NPTH holes at [(33.2, 74.2), (50.8, 88.6)]; SCAD/PCB interface agrees.
- Cradle: F.Cu/B.Cu track/via/pour keepout present; no electrical-component or WT32-hole courtyard intersects the reserved region.
- Native KiCad ERC: 0 violations. This does not verify module hardware or performance.
- Native PCB/schematic parity: 0 issues. BOM manufacturer and DigiKey identifiers agree for 47 references.
- Native KiCad DRC: 0 reported violations plus 88 unconnected items.
- Copper routing: zero tracks. No routing pass or Gerber release is claimed.
- Four 3.0 mm NPTH carrier clearance holes; WT32 pattern confirmed by user.


Reports are retained without exclusions. Resolve actual violations and all README
release gates before ordering. No electrical load, temperature, antenna, or physical
fit test has been performed.
