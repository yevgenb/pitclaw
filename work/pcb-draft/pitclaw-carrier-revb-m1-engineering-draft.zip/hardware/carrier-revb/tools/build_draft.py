#!/usr/bin/env python3
"""Generate the explicitly UNROUTED Rev B KiCad engineering starting point.

Requires KiCad 9's Python with pcbnew. Re-running replaces generated CAD files;
never run over subsequent manual edits without preserving them first.
"""
import copy
import json
import math
import os
from pathlib import Path
import re
import subprocess
import uuid
import xml.etree.ElementTree as ET
import pcbnew as pcb

ROOT = Path(__file__).resolve().parents[1]
SHARE = Path(os.environ.get("PITCLAW_KICAD_SHARE",
    "/Applications/KiCad/KiCad.app/Contents/SharedSupport"))
NAME = "pitclaw-carrier"
NS = uuid.UUID("27b13da5-06d9-4979-8d12-8761a109cf3b")
def uid(key): return str(uuid.uuid5(NS, key))
def q(s): return json.dumps(str(s), ensure_ascii=False)
def vec(x, y): return pcb.VECTOR2I(pcb.FromMM(x), pcb.FromMM(y))

# Small S-expression reader preserves quoted strings while resolving library
# inheritance. Native graphical symbols are copied from installed KiCad libs.
class Quoted(str): pass
def parse(text):
    stack = [[]]
    for t in re.findall(r'"(?:\\.|[^"\\])*"|\(|\)|[^\s()]+', text):
        if t == "(":
            n = []; stack[-1].append(n); stack.append(n)
        elif t == ")": stack.pop()
        else: stack[-1].append(Quoted(json.loads(t)) if t.startswith('"') else t)
    assert len(stack) == 1
    return stack[0][0]
def dump(n):
    if isinstance(n, list): return "(" + " ".join(dump(x) for x in n) + ")"
    return q(n) if isinstance(n, Quoted) else str(n)
def children(n, key): return [a for a in n if isinstance(a, list) and a[0] == key]
def child(n, key): return next(a for a in n if isinstance(a, list) and a[0] == key)
libs = {}
def libsymbol(lib, name):
    if lib not in libs:
        tree = parse((SHARE / "symbols" / (lib + ".kicad_sym")).read_text())
        libs[lib] = {str(s[1]): s for s in children(tree, "symbol")}
    s = copy.deepcopy(libs[lib][name])
    ext = children(s, "extends")
    if ext:
        base = libsymbol(lib, str(ext[0][1])); old = str(base[1]); base[1] = Quoted(name)
        for sub in children(base, "symbol"):
            sub[1] = Quoted(str(sub[1]).replace(old + "_", name + "_", 1))
        overrides = {str(p[1]) for p in children(s, "property")}
        base = [v for v in base if not (isinstance(v, list) and v[0] == "property" and str(v[1]) in overrides)]
        base += children(s, "property")
        return base
    return s

def box_symbol(name, pins):
    """pins: number, label, electrical type, side (L/R)."""
    rows = max(sum(p[3] == side for p in pins) for side in ("L", "R"))
    halfh = max(5.08, (rows + 1) * 1.27)
    items = [f'(symbol {q(name)} (pin_names (offset 0.635)) (in_bom yes) (on_board yes)',
        '(property "Reference" "J" (at 0 0 0) (effects (font (size 1.27 1.27))))',
        f'(property "Value" {q(name)} (at 0 0 0) (effects (font (size 1.27 1.27))))',
        f'(symbol {q(name+"_0_1")} (rectangle (start -12.7 {halfh}) (end 12.7 {-halfh}) (stroke (width 0.254) (type default)) (fill (type background))))',
        f'(symbol {q(name+"_1_1")}']
    counts = {"L": 0, "R": 0}
    for num, label, typ, side in pins:
        y = (rows - 1) * 1.27 - counts[side] * 2.54; counts[side] += 1
        x, angle = (-17.78, 0) if side == "L" else (17.78, 180)
        items.append(f'(pin {typ} line (at {x} {y} {angle}) (length 5.08) (name {q(label)} (effects (font (size 1.0 1.0)))) (number {q(num)} (effects (font (size 1 1)))))')
    return parse("\n".join(items) + "))")

SYMS = {}
for lib, names in {"Device": ["R", "C", "C_Polarized", "D_Schottky", "D_Zener", "Fuse", "Speaker"],
    "Transistor_BJT": ["2N3904"], "Transistor_FET": ["FQP27P06"]}.items():
    for n in names: SYMS[n] = libsymbol(lib, n)
SYMS["PowerIn"] = box_symbol("PowerIn", [(1,"PD_OUT+","power_out","L"),(2,"GND","power_out","L")])
SYMS["Buck5V"] = box_symbol("Buck5V", [(3,"VIN+","power_in","L"),(2,"GND","power_in","L"),(4,"EN_NC","input","L"),(1,"VOUT_5V","power_out","R")])
SYMS["EXT"] = box_symbol("EXT", [(n,l,t,"L") for n,l,t in [
    (1,"WT32_5V","power_in"),(2,"GND","passive"),(3,"GPIO10_SDA","bidirectional"),
    (4,"GPIO11_SCL","output"),(5,"GPIO12_FAN","output"),(6,"GPIO13_SERVO","output"),
    (7,"GPIO14_BUZZ","output"),(8,"GPIO21_SPARE","passive")]])
SYMS["Debug3V3"] = box_symbol("Debug3V3", [(1,"DEBUG_2_3V3","power_out","L"),(2,"DEBUG_7_GND","passive","L")])
SYMS["RJ45"] = box_symbol("RJ45", [(n,l,"passive","L") for n,l in enumerate(["NC","NC","SERVO_5V","COMMON_GND","FAN_12V_SW","SERVO_PWM","NC","NC"],1)])
SYMS["Probe"] = box_symbol("Probe", [(1,"SLEEVE","passive","L"),(2,"TIP_A","passive","L"),(3,"TIP_B","passive","L")])
SYMS["Jumper"] = box_symbol("Jumper", [(1,"5V_FUSED","passive","L"),(2,"WT32_5V","passive","R")])
SYMS["ADC_1x10"] = box_symbol("ADC_1x10", [(n,l,t,side) for n,l,t,side in [
    (1,"VDD","power_in","L"),(2,"GND","power_in","L"),(3,"SCL","input","L"),(4,"SDA","bidirectional","L"),
    (5,"ADDR","input","L"),(6,"ALRT","open_collector","R"),(7,"A0","input","R"),(8,"A1","input","R"),
    (9,"A2","input","R"),(10,"A3","input","R")]])
SYMS["PWR_FLAG"] = libsymbol("power", "PWR_FLAG")

RFP = "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P7.62mm_Horizontal"
CFP = "Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P5.00mm"
KK2 = "Connector_Molex:Molex_KK-254_AE-6410-02A_1x02_P2.54mm_Vertical"
PARTS = []
def add(ref, value, sym, fp, nets, sch, pos, angle=0, dnp=False):
    PARTS.append(dict(ref=ref,value=value,sym=sym,fp=fp,nets={str(k):v for k,v in nets.items()},
        sch=sch,pos=pos,angle=angle,dnp=dnp,uuid=uid(ref)))
def two(ref,value,sym,fp,n1,n2,sch,pos,angle=0,dnp=False):
    add(ref,value,sym,fp,{1:n1,2:n2},sch,pos,angle,dnp)
def r(ref,val,n1,n2,sch,pos,dnp=False): two(ref,val,"R",RFP,n1,n2,sch,pos,0,dnp)
def c(ref,val,net,sch,pos,diam=None):
    fp = CFP if diam is None else f"Capacitor_THT:CP_Radial_D{diam[0]}mm_P{diam[1]}mm"
    two(ref,val,"C" if diam is None else "C_Polarized",fp,net,"GND",sch,pos)
def fuse(ref,value,n1,n2,sch,pos): two(ref,value,"Fuse","PitClaw:PTC_P5.08_DRAFT",n1,n2,sch,pos)

add("J1","PD module output / 12V ONLY","PowerIn",KK2,{1:"PD12_RAW",2:"GND"},(35,50),(36,64))
fuse("F1","2A HOLD - VERIFY","PD12_RAW","+12V",(85,50),(24,70))
c("C1","470u / 35V","+12V",(130,50),(29,82),("10.0","5.00"))
c("C2","100n / 50V","+12V",(175,50),(29,74.5))
two("D1","P6KE18A","D_Zener","Diode_THT:D_DO-15_P12.70mm_Horizontal","+12V","GND",(220,50),(30,58))
add("U2","Mini100 / SET 5V / SOCKET","Buck5V","PitClaw:Mini100_1x04_P2.54mm",{1:"+5V",2:"GND",3:"+12V",4:None},(275,50),(11.31,74.5))
c("C3","220u / 16V","+5V",(35,100),(8,69),("8.0","3.50"))
c("C4","100n / 50V","+5V",(85,100),(20,60))
fuse("F2","0.75A HOLD - VERIFY","+5V","+5V_WT_FUSED",(130,100),(5,41))
add("JP1","REMOVE FOR WT32 USB","Jumper","Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical",{1:"+5V_WT_FUSED",2:"+5V_WT32"},(185,100),(5,28))
fuse("F3","0.5A HOLD - VERIFY","+5V","+5V_SERVO",(230,100),(22,64))
c("C5","100u / 16V","+5V_SERVO",(280,100),(21,74),("6.3","2.50"))
add("Q1","FQP27P06","FQP27P06","Package_TO_SOT_THT:TO-220-3_Vertical",{1:"FAN_GATE",2:"FAN_SW",3:"+12V"},(345,55),(6,48))
r("R1","1k / 0.25W","+12V","FAN_GATE",(390,55),(18,46))
add("Q2","2N3904","2N3904","Package_TO_SOT_THT:TO-92_Inline",{1:"GND",2:"FAN_BASE",3:"FAN_GATE"},(440,55),(18,50))
r("R2","2.2k","GPIO12_FAN","FAN_BASE",(490,55),(5,36))
r("R3","100k","FAN_BASE","GND",(540,55),(18,36))
fuse("F4","0.5A HOLD - VERIFY","FAN_SW","FAN_OUT",(340,105),(8,75))
two("D2","1N5819","D_Schottky","Diode_THT:D_DO-41_SOD81_P10.16mm_Horizontal","FAN_OUT","GND",(385,105),(6,54))
r("R4","220R","GPIO13_SERVO","SERVO_SIG",(430,105),(21,54))
r("R5","10k","SERVO_SIG","GND",(475,105),(20,57))
add("J2","RJHSE-5080 / CHECK FOOTPRINT","RJ45","PitClaw:RJHSE-5080_DRAFT",{1:None,2:None,3:"+5V_SERVO",4:"GND",5:"FAN_OUT",6:"SERVO_SIG",7:None,8:None},(552,105),(18.435,84),180)
add("J3","WT32 EXT harness","EXT","Connector_Molex:Molex_KK-254_AE-6410-08A_1x08_P2.54mm_Vertical",{1:"+5V_WT32",2:"GND",3:"SDA",4:"SCL",5:"GPIO12_FAN",6:"GPIO13_SERVO",7:"GPIO14_BUZZ",8:None},(45,175),(12,6))
add("J7","WT32 DEBUG 2 / 7 ONLY","Debug3V3",KK2,{1:"+3V3_A",2:"GND"},(125,170),(40,6))
c("C7","4.7u / 10V","+3V3_A",(185,170),(18,20),("5.0","2.00"))
c("C13","100n / 50V","+3V3_A",(225,170),(19,32))
r("R17","4.7k DNP","+3V3_A","SDA",(270,170),(16,11),True)
r("R18","4.7k DNP","+3V3_A","SCL",(315,170),(16,14.5),True)
two("BZ1","PASSIVE PIEZO / VERIFY PART","Speaker","Buzzer_Beeper:Buzzer_12x9.5RM7.6","+5V","BUZZ_LOW",(365,170),(5,18))
add("Q3","2N3904","2N3904","Package_TO_SOT_THT:TO-92_Inline",{1:"GND",2:"BUZZ_BASE",3:"BUZZ_LOW"},(410,170),(18,24))
r("R6","2.2k","GPIO14_BUZZ","BUZZ_BASE",(455,170),(5,25))
r("R7","100k","BUZZ_BASE","GND",(505,170),(15,28))
r("R19","1k / PIEZO DISCHARGE","+5V","BUZZ_LOW",(550,170),(5,32))
for i, label in enumerate(["PIT","MEAT 1","MEAT 2"]):
    yy=245+50*i
    add(f"J{4+i}",f"MJ1-2503A / {label}","Probe","PitClaw:MJ1-2503A",{1:"GND",2:f"PROBE{i}",3:f"PROBE{i}"},(45,yy),(60,19+17*i))
    r(f"R{10+i}","10k / 0.1%","+3V3_A",f"PROBE{i}",(110,yy),(30,37+7*i))
    r(f"R{13+i}","1k",f"PROBE{i}",f"AIN{i}",(170,yy),(42,37+7*i))
    c(f"C{10+i}","100n / 50V",f"AIN{i}",(225,yy),(42,32.5+7*i))
add("J8","ADS1115 BLUE / 1x10 SOCKET","ADC_1x10","PitClaw:ADS1115_Blue_1x10_DRAFT",{1:"+3V3_A",2:"GND",3:"SCL",4:"SDA",5:"GND",6:None,10:"AIN3",9:"AIN2",8:"AIN1",7:"AIN0"},(325,270),(25.24,26))
r("R16","1k","+3V3_A","AIN3",(385,250),(30,33.5))

# Placement refinement from courtyard and clearance checks. TO-92 wide pitch
# gives hand-solderable spacing without reducing the chosen 0.30 mm clearance.
placements = {"BZ1":(4.3,16.5),"R6":(5,25.5),"JP1":(5,29.5),"R19":(5,33.5),
    "R2":(5,38),"Q3":(19,31.5),"R7":(6,41.5),"C7":(18.25,22.5),"C13":(30,31.5),"R3":(18,37),
    "R17":(16.5,11),"R18":(20.5,11),"R16":(39,30.5),
    "F2":(19,42),"R1":(18,46),"Q2":(20,51.5),"R4":(20,56.5),"R5":(19,60),
    "U2":(10.21,74.5),"C3":(6,71),"C4":(21,64),"F3":(24,68),"F1":(27,73),
    "C5":(16,72),"D1":(33,58),"C2":(31,63),"J1":(39,65.5),"F4":(51,63),
    "J2":(19.435,84),"C1":(29,83)}
for i in range(3):
    placements[f"R{10+i}"]=(30,37+8.5*i)
    placements[f"R{13+i}"]=(42,36.5+8.5*i)
    placements[f"C{10+i}"]=(42,32.5+8.5*i)
placements["R10"]=(29.5,41)
for p in PARTS:
    if p["ref"] in placements: p["pos"]=placements[p["ref"]]
    if p["ref"]=="JP1": p["angle"]=90
    if p["ref"] in ("R16","R17","R18"): p["angle"]=270
    if p["ref"] in ("Q2","Q3"): p["fp"]="Package_TO_SOT_THT:TO-92_Inline_Wide"
    if p["ref"] == "U2": p["angle"] = 90

# Purchasing selection is the common source for the CAD and priced BOM.
selection = json.loads((ROOT/"bom/selection.json").read_text())
by_ref = {ref: row for row in selection["parts"] for ref in row["refs"]}
assert set(by_ref) == {p["ref"] for p in PARTS}, "BOM / circuit reference mismatch"
for p in PARTS:
    row = by_ref[p["ref"]]
    for key in ("value", "fp"):
        if key in row: p[key] = row[key]
    assert p["dnp"] == row.get("dnp", False), ("DNP mismatch", p["ref"])

# Schematic symbols and net labels.
ROOT.mkdir(parents=True, exist_ok=True)
for sub in ["PitClaw.pretty","previews","verification"]: (ROOT/sub).mkdir(exist_ok=True)
lib_nodes = [dump(s) for s in SYMS.values()]
(ROOT/"PitClaw.kicad_sym").write_text('(kicad_symbol_lib (version 20241209) (generator "kicad_symbol_editor")\n'+'\n'.join(lib_nodes)+')\n')
embedded=[]
for name,s in SYMS.items():
    sc=copy.deepcopy(s); sc[1]=Quoted("PitClaw:"+name); embedded.append(dump(sc))
root_uuid=uid("schematic")
sch=[f'(kicad_sch (version 20250114) (generator "eeschema") (uuid {root_uuid}) (paper "A2")',
    '(title_block (title "Pit Claw Rev B-M1 - UNROUTED ENGINEERING DRAFT") (date "2026-09-04") (rev "B-M1") (comment 1 "NOT FOR FABRICATION - MODULES, MOUNTING AND LOADS REQUIRE CONFIRMATION"))',
    '(lib_symbols '+'\n'.join(embedded)+')']
def text_at(s,x,y,size=1.6):
    sch.append(f'(text {q(s)} (at {x} {y} 0) (effects (font (size {size} {size})) (justify left top)) (uuid {uid("text"+s)}))')
def symbol_pins(s):
    return [p for sub in children(s,"symbol") for p in children(sub,"pin")]
for p in PARTS:
    x,y=[round(v/1.27)*1.27 for v in p["sch"]]; s=SYMS[p["sym"]]
    angle=0
    pins=symbol_pins(s)
    height=max(abs(float(child(pin,"at")[2])) for pin in pins)
    isbox = p["sym"] in ("PowerIn","Buck5V","EXT","Debug3V3","RJ45","Probe","Jumper","ADC_1x10","D_Schottky","D_Zener","Speaker")
    prop_y=y-height-7 if isbox else y-1.5
    prop_x=x if isbox else x+8
    prop_justify="" if isbox else "(justify left)"
    props = f'(property "Reference" {q(p["ref"])} (at {prop_x} {prop_y} 0) (effects (font (size 1.4 1.4)) {prop_justify}))'
    props += f'(property "Value" {q(p["value"])} (at {prop_x} {prop_y+2.3} 0) (effects (font (size 1.05 1.05)) {prop_justify}))'
    props += f'(property "Footprint" {q(p["fp"])} (at {x} {y} 0) (effects (font (size 1 1)) (hide yes)))'
    row = by_ref[p["ref"]]
    for field, key in (("Manufacturer", "manufacturer"), ("MPN", "mpn"), ("DigiKey", "sku"), ("Source", "url")):
        props += f'(property {q(field)} {q(row[key])} (at {x} {y} 0) (effects (font (size 1 1)) (hide yes)))'
    sch.append(f'(symbol (lib_id {q("PitClaw:"+p["sym"])}) (at {x} {y} {angle}) (unit 1) (in_bom yes) (on_board yes) (dnp {"yes" if p["dnp"] else "no"}) (uuid {p["uuid"]}) {props}')
    for pin in pins:
        num=str(child(pin,"number")[1]); sch.append(f'(pin {q(num)} (uuid {uid(p["ref"]+"/"+num)}))')
    sch.append(f'(instances (project {q(NAME)} (path {q("/"+root_uuid)} (reference {q(p["ref"])}) (unit 1)))))')
    for pin in pins:
        num=str(child(pin,"number")[1]); net=p["nets"][num]
        a=child(pin,"at"); u,v,pa=map(float,a[1:4]); rot=math.radians(angle)
        px=round(x+u*math.cos(rot)+v*math.sin(rot),4)
        py=round(y-u*math.sin(rot)-v*math.cos(rot),4)
        if net is None:
            sch.append(f'(no_connect (at {px} {py}) (uuid {uid(p["ref"]+num+"nc")}))'); continue
        # Pin angle points INTO the symbol. Extend outwards for the wire/label.
        theta=math.radians(pa-angle)
        ex=round(px-5.08*math.cos(theta),4); ey=round(py+5.08*math.sin(theta),4)
        sch.append(f'(wire (pts (xy {px} {py}) (xy {ex} {ey})) (stroke (width 0) (type default)) (uuid {uid(p["ref"]+num+"wire")}))')
        la=90 if abs(ex-px)<.001 else 0
        justify="right bottom" if ex<px else "left bottom"
        sch.append(f'(label {q(net)} (at {ex} {ey} {la}) (effects (font (size 1.0 1.0)) (justify {justify})) (uuid {uid(p["ref"]+num+"label")}))')
text_at("01  POWER - 12 V PD INPUT / FIXED 5 V BUCK",20,20,2)
text_at("02  HIGH-SIDE BLOWER / SHARED-GROUND RJ45",325,20,2)
text_at("03  WT32 HARNESSES / ANALOG POWER / OPTIONAL PIEZO",20,140,2)
text_at("04  THREE NTC PROBES / FILTERS / SOCKETED ADC",20,215,2)
flag_id=uid("WT32_5V_FLAG")
sch.append(f'(symbol (lib_id "PitClaw:PWR_FLAG") (at 200.66 120.65 0) (unit 1) (in_bom no) (on_board no) (dnp no) (uuid {flag_id}) (property "Reference" "#FLG01" (at 200.66 120.65 0) (effects (font (size 1 1)) (hide yes))) (property "Value" "PWR_FLAG" (at 200.66 115.57 0) (effects (font (size 1 1)))) (pin "1" (uuid {uid("FLAG_PIN")})) (instances (project {q(NAME)} (path {q("/"+root_uuid)} (reference "#FLG01") (unit 1)))))')
sch.append(f'(label "+5V_WT32" (at 200.66 120.65 0) (effects (font (size 1 1)) (justify left bottom)) (uuid {uid("FLAG_LABEL")}))')
sch.append(f'(symbol (lib_id "PitClaw:PWR_FLAG") (at 100.33 69.85 0) (unit 1) (in_bom no) (on_board no) (dnp no) (uuid {uid("12V_FLAG")}) (property "Reference" "#FLG02" (at 100.33 69.85 0) (effects (font (size 1 1)) (hide yes))) (property "Value" "PWR_FLAG" (at 100.33 64.77 0) (effects (font (size 1 1)))) (pin "1" (uuid {uid("12V_FLAG_PIN")})) (instances (project {q(NAME)} (path {q("/"+root_uuid)} (reference "#FLG02") (unit 1)))))')
sch.append(f'(label "+12V" (at 100.33 69.85 0) (effects (font (size 1 1)) (justify left bottom)) (uuid {uid("12V_FLAG_LABEL")}))')
notes=["ENGINEERING DRAFT - DO NOT ORDER", "PCB has no copper routing yet.","Matching net labels are electrically connected.",
    "J8: blue 10-pin ADS1115 module, 28 x 17 mm.","Pin 1 = VDD; pin 10 = A3. Check orientation.","2.54 mm pitch / body offsets need fit check.",
    "USB-C trigger: 12 V setting only.","J1 is its removable internal output harness.","U2: Mini100, set/verify 5V; EN unconnected.",
    "Q1 pinout: 1 gate, 2 drain, 3 source.","GPIO12 high = blower ON; reset = OFF.","RJ45 p4 carries fan + servo return.",
    "Remove JP1 for WT32 USB programming.","DEBUG: use WT32 pins 2 and 7 only.","R17/R18 DNP with module pull-ups.",
    "R19: passive piezo discharge; use 4 kHz PWM.","PTC ratings require loaded/thermal testing.","Read README release gates before assembly."]
for i,n in enumerate(notes): text_at(n,425,230+6*i,1.3 if i else 1.8)
text_at("NTC: R = 10000 * raw / (raw_supply - raw). AIN3 measures excitation. Fix firmware before testing.",20,385,1.6)
sch.append('(embedded_fonts no))')
(ROOT/(NAME+".kicad_sch")).write_text("\n".join(sch)+"\n")
(ROOT/"sym-lib-table").write_text('(sym_lib_table (version 7) (lib (name "PitClaw") (type "KiCad") (uri "${KIPRJMOD}/PitClaw.kicad_sym") (options "") (descr "Rev B local symbols")))\n')
(ROOT/"fp-lib-table").write_text('(fp_lib_table (version 7) (lib (name "PitClaw") (type "KiCad") (uri "${KIPRJMOD}/PitClaw.pretty") (options "") (descr "Rev B draft custom footprints")))\n')

# Use KiCad's canonical local-label and no-connect net names verbatim, so native
# schematic parity agrees as well as the independent logical pin/net check.
cli = os.environ.get("PITCLAW_KICAD_CLI", "/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli")
netlist_path = ROOT/"verification/schematic-netlist.xml"
subprocess.run([cli,"sch","export","netlist","--format","kicadxml","--output",str(netlist_path),str(ROOT/(NAME+".kicad_sch"))],check=True)
netlist = ET.parse(netlist_path).getroot()
canonical_nets = {(node.attrib["ref"],node.attrib["pin"]):net.attrib["name"]
                  for net in netlist.findall("./nets/net") for node in net.findall("node")}

# Native footprints. Module and connector geometry is deliberately independent
# of copper routing; draft assumptions are described in README, not hidden.
def makefp(name,descr):
    f=pcb.FOOTPRINT(None); f.SetFPID(pcb.LIB_ID("PitClaw",name)); f.SetLibDescription(descr)
    f.SetAttributes(pcb.FP_THROUGH_HOLE); f.SetReference("REF**"); f.SetValue(name)
    f.Reference().SetPosition(vec(0,-3)); f.Reference().SetTextSize(vec(.8,.8))
    f.Value().SetVisible(False)
    return f
def fp_line(f,a,b,layer=pcb.F_SilkS,width=.12):
    s=pcb.PCB_SHAPE(f); s.SetShape(pcb.SHAPE_T_SEGMENT); s.SetStart(vec(*a)); s.SetEnd(vec(*b)); s.SetWidth(pcb.FromMM(width)); s.SetLayer(layer); f.Add(s)
def rect(f,x1,y1,x2,y2,layer=pcb.F_Fab):
    for a,b in [((x1,y1),(x2,y1)),((x2,y1),(x2,y2)),((x2,y2),(x1,y2)),((x1,y2),(x1,y1))]: fp_line(f,a,b,layer)
def pad(f,n,x,y,size=(1.8,1.8),drill=(1,1),npth=False):
    p=pcb.PAD(f); p.SetNumber(str(n)); p.SetPosition(vec(x,y)); p.SetSize(vec(*size)); p.SetDrillSize(vec(*drill))
    p.SetAttribute(pcb.PAD_ATTRIB_NPTH if npth else pcb.PAD_ATTRIB_PTH)
    layers=pcb.LSET.AllCuMask(); layers.AddLayer(pcb.F_Mask); layers.AddLayer(pcb.B_Mask)
    p.SetLayerSet(layers)
    p.SetShape(pcb.PAD_SHAPE_CIRCLE if size[0]==size[1] else pcb.PAD_SHAPE_OVAL)
    if drill[0]!=drill[1]: p.SetDrillShape(pcb.PAD_DRILL_SHAPE_OBLONG)
    if str(n)=="1" and not npth: p.SetShape(pcb.PAD_SHAPE_RECT)
    f.Add(p)
    return p
custom={}
f=makefp("MJ1-2503A","Same Sky 2024-09-12 top-view drawing; verify actual lead/slot tolerances")
rect(f,-8,-2.55,0,2.55); rect(f,0,-2,3,2); rect(f,-8.7,-3,3.5,3,pcb.F_CrtYd)
pad(f,1,-8.1,0,(1.1,2.1),(.5,1.5)); pad(f,2,-6,-1.8,(2.1,1.1),(1.5,.5)); pad(f,3,-6,1.8,(2.1,1.1),(1.5,.5)); pad(f,"",-3.5,0,(1.2,1.2),(1.2,1.2),True)
fp_line(f,(-8,-2.55),(-.5,-2.55));fp_line(f,(-8,2.55),(-.5,2.55));custom["MJ1-2503A"]=f
f=makefp("RJHSE-5080_DRAFT","UNVERIFIED: related RJHSE-5380 pad array, unshielded housing; reconcile exact 5080 drawing before routing")
rect(f,-4.315,-8,11.435,6.99);rect(f,-4.815,-8.5,11.935,7.49,pcb.F_CrtYd)
fp_line(f,(-4.315,-7.5),(11.435,-7.5));fp_line(f,(-4.315,6.99),(11.435,6.99))
for side in [-4.315,11.435]:
    fp_line(f,(side,-7.5),(side,-4.5));fp_line(f,(side,-.5),(side,6.99))
for i in range(8): pad(f,i+1,1.016*i,1.78 if i%2 else 0,(1.5,1.5),(.89,.89))
for x in [-2.79,9.91]: pad(f,"",x,-2.54,(3.25,3.25),(3.25,3.25),True)
custom["RJHSE-5080_DRAFT"]=f
f=makefp("ADS1115_Blue_1x10_DRAFT","User-linked Components101 blue module: 28x17mm, VDD GND SCL SDA ADDR ALRT A0 A1 A2 A3; 2.54mm pitch and edge offsets need physical fit check")
rect(f,-2.54,-15.5,25.46,1.5)
rect(f,-3.04,-16,25.96,2,pcb.F_CrtYd)
rect(f,-1.27,-1.27,24.13,1.27,pcb.F_SilkS)
for i in range(10): pad(f,i+1,2.54*i,0)
custom["ADS1115_Blue_1x10_DRAFT"]=f
f=makefp("Mini100_1x04_P2.54mm","Weewooday B08JZ5FVLC module socket: user confirmed 2.54mm row pitch and 1.5mm row-to-short-edge; seller 20x11 body. Row centering across width assumed. 1 OUT, 2 GND, 3 IN, 4 EN. Support free end and check actual insertion height.")
# Component-side module view: body extends right; bottom-to-top pads are OUT,
# GND, IN, EN. Rotated 90deg on carrier: body x0.9..11.9/y56..76, row at y74.5.
rect(f,-1.5,-9.31,18.5,1.69)
rect(f,-2,-9.81,19,2.19,pcb.F_CrtYd)
rect(f,-1.27,-9.14,1.27,1.52,pcb.F_SilkS)
for i in range(4): pad(f,i+1,0,-2.54*i,(1.8,1.8),(1.02,1.02))
custom["Mini100_1x04_P2.54mm"]=f
for name, width, depth, height in [("PTC_Bourns_MF-RHT200-32_P5.1",9.4,3,14),
                                 ("PTC_Bourns_MF-R075_P5.1",10.4,3.1,16),
                                 ("PTC_Bourns_MF-R050_P5.1",7.9,3.1,13.7)]:
    f=makefp(name,f"Bourns manufacturer maximum envelope {width}x{depth}mm, seated height {height}mm; 5.1mm nominal pitch, 0.51mm leads. Form/sample-check leads before release.")
    x1=2.55-width/2; x2=2.55+width/2
    rect(f,x1,-depth/2,x2,depth/2)
    rect(f,x1-.5,-depth/2-.5,x2+.5,depth/2+.5,pcb.F_CrtYd)
    rect(f,x1,-depth/2,x2,depth/2,pcb.F_SilkS)
    pad(f,1,0,0,(2,2),(1,1));pad(f,2,5.1,0,(2,2),(1,1));custom[name]=f
f=makefp("C_Vishay_K104K15X7RF5TH5_P5","Vishay K104 K15 radial MLCC, 4x2.6mm body, 6.6mm maximum seated height; 5mm pitch. Lead-form/sample fit check required.")
rect(f,.5,-1.3,4.5,1.3);rect(f,-1.3,-1.8,6.3,1.8,pcb.F_CrtYd)
fp_line(f,(.5,-1.6),(4.5,-1.6));fp_line(f,(.5,1.6),(4.5,1.6))
pad(f,1,0,0,(1.8,1.8),(.9,.9));pad(f,2,5,0,(1.8,1.8),(.9,.9))
custom["C_Vishay_K104K15X7RF5TH5_P5"]=f
f=makefp("Piezo_CPT-1255C-090_D12_P5","Same Sky CPT-1255C-090 manufacturer drawing: D12, 5mm pitch, 0.6+/-0.1mm leads, 6mm maximum height. Passive externally driven piezo.")
for layer, radius in [(pcb.F_Fab,6),(pcb.F_SilkS,6.1),(pcb.F_CrtYd,6.5)]:
    s=pcb.PCB_SHAPE(f);s.SetShape(pcb.SHAPE_T_CIRCLE);s.SetCenter(vec(2.5,0));s.SetEnd(vec(2.5+radius,0));s.SetLayer(layer);s.SetWidth(pcb.FromMM(.05 if layer==pcb.F_CrtYd else .12));f.Add(s)
pad(f,1,0,0,(1.8,1.8),(1,1));pad(f,2,5,0,(1.8,1.8),(1,1))
custom["Piezo_CPT-1255C-090_D12_P5"]=f
io=pcb.PCB_IO_MGR.PluginFind(pcb.PCB_IO_MGR.KICAD_SEXP)
for name,f in custom.items(): io.FootprintSave(str(ROOT/"PitClaw.pretty"),f)

b=pcb.BOARD(); b.SetCopperLayerCount(2)
settings=b.GetDesignSettings(); settings.SetBoardThickness(pcb.FromMM(1.6)); settings.m_MinClearance=pcb.FromMM(.3)
settings.m_TrackMinWidth=pcb.FromMM(.3); settings.m_ViasMinSize=pcb.FromMM(.8); settings.m_MinThroughDrill=pcb.FromMM(.4)
nets={}
for n in sorted(set(canonical_nets.values())):
    net=pcb.NETINFO_ITEM(b,n); b.Add(net);nets[n]=net
for p in PARTS:
    if not p["fp"]: continue
    lib,fn=p["fp"].split(":")
    path=ROOT/"PitClaw.pretty" if lib=="PitClaw" else SHARE/"footprints"/(lib+".pretty")
    f=pcb.FootprintLoad(str(path),fn)
    if f is None: raise RuntimeError("Missing footprint: "+p["fp"])
    f.SetFPID(pcb.LIB_ID(lib,fn)); f.SetReference(p["ref"]);f.SetValue(p["value"])
    kp=pcb.KIID_PATH();kp.push_back(pcb.KIID(root_uuid));kp.push_back(pcb.KIID(p["uuid"]));f.SetPath(kp)
    if p["dnp"]: f.SetAttributes(f.GetAttributes() | pcb.FP_DNP)
    f.SetOrientationDegrees(p["angle"]);f.SetPosition(vec(100+p["pos"][0],50+p["pos"][1]))
    f.Reference().SetTextSize(vec(.8,.8));f.Reference().SetTextThickness(pcb.FromMM(.12));f.Value().SetVisible(False)
    f.Reference().SetLayer(pcb.F_Fab)  # Assembly references; silkscreen placement is a later release step.
    for graphic in f.GraphicalItems():
        if hasattr(graphic,"GetText"): graphic.SetLayer(pcb.F_Fab)
    for pp in f.Pads():
        number=pp.GetNumber()
        if not number: continue
        net=canonical_nets.get((p["ref"],number))
        if net is not None: pp.SetNet(nets[net])
    b.Add(f)
def board_line(a,bp,layer=pcb.Edge_Cuts,width=.05):
    s=pcb.PCB_SHAPE(b);s.SetShape(pcb.SHAPE_T_SEGMENT);s.SetStart(vec(100+a[0],50+a[1]));s.SetEnd(vec(100+bp[0],50+bp[1]));s.SetWidth(pcb.FromMM(width));s.SetLayer(layer);b.Add(s)
for a,bb in [((0,0),(60,0)),((60,0),(60,92)),((60,92),(0,92)),((0,92),(0,0))]: board_line(a,bb)
for i,(x,y) in enumerate([(4.305,6.52),(55.695,6.52),(4.305,81.66),(55.695,81.66)],1):
    f=makefp("Mount_D3.0_CLEARANCE","User-confirmed WT32 pattern; carrier clearance for 2.3-2.5mm self-tapping screws")
    f.SetReference("H"+str(i));pad(f,"",0,0,(3,3),(3,3),True)
    s=pcb.PCB_SHAPE(f);s.SetShape(pcb.SHAPE_T_CIRCLE);s.SetCenter(vec(0,0));s.SetEnd(vec(3,0));s.SetLayer(pcb.F_CrtYd);s.SetWidth(pcb.FromMM(.05));f.Add(s)
    f.SetAttributes(pcb.FP_EXCLUDE_FROM_BOM | pcb.FP_EXCLUDE_FROM_POS_FILES | pcb.FP_BOARD_ONLY)
    io.FootprintSave(str(ROOT/"PitClaw.pretty"),f)
    f.SetPosition(vec(100+x,50+y));b.Add(f)
# User-measured HW-398 body: 12 x 23 mm. Keep the right edge fixed to preserve
# clearance to H4. Support/height remain provisional; no invented pads or holes.
for a,bb in [((39.5,69),(51.5,69)),((51.5,69),(51.5,92)),((51.5,92),(39.5,92)),((39.5,92),(39.5,69))]: board_line(a,bb,pcb.Dwgs_User,.15)
def boardtext(t,x,y,size=1,layer=pcb.Dwgs_User):
    tx=pcb.PCB_TEXT(b);tx.SetText(t);tx.SetPosition(vec(100+x,50+y));tx.SetTextSize(vec(size,size));tx.SetTextThickness(pcb.FromMM(.15));tx.SetLayer(layer);b.Add(tx)
boardtext("HW-398\n12 x 23 mm\nCLAMP TBD",45.5,78,.9)
boardtext("ADS1115 28x17\n1x10 / 2.54mm\nFIT CHECK REQUIRED",36.7,17,.85)
boardtext("UNROUTED - NOT FOR FABRICATION",30,-5,1.3)
boardtext("60 x 92 mm / MOUNTING AND ANTENNA CLEARANCE TBD",30,-2.5,.9)
boardtext("12V CONTROL\nNOT ETHERNET",15,96,1)
boardtext("USB-C PD\n12V ONLY",45.5,96,1)
for i,l in enumerate(["PIT","MEAT 1","MEAT 2"]):boardtext(l,66,19+17*i,.9)
boardtext("PIT CLAW B-DRAFT",33,90.2,.8,pcb.F_SilkS)
# The shared cradle interface applies to fresh drafts as well as the additive updater.
from hw398_geometry import update_board, scad_constants, MECH
update_board(b)
# Power-area placement (including Mini100 neighbors) is shared with the cradle updater.
boardtext("B-M1 / MINI100 SOCKET / JST-XH",30,104,1)
boardtext("U2: SET 5V / PIN 4 EN NC / SUPPORT FREE END",30,106,0.8)
boardtext("MINI100\n20x11\nSET 5V",6.4,64,.75)
boardtext("EN  IN  GND OUT",6.4,77.5,.55)
# No copper beneath the switching body; leave the header strip accessible.
zone=pcb.ZONE(b);zone.SetIsRuleArea(True);zone.SetZoneName("MINI100_BODY_NO_COPPER")
layer_set=pcb.LSET();layer_set.AddLayer(pcb.F_Cu);layer_set.AddLayer(pcb.B_Cu);zone.SetLayerSet(layer_set)
zone.SetDoNotAllowTracks(True);zone.SetDoNotAllowVias(True);zone.SetDoNotAllowCopperPour(True)
zone.SetDoNotAllowPads(True);zone.SetDoNotAllowFootprints(False)
outline=zone.Outline();outline.NewOutline()
for x,y in [(.4,55.5),(12.4,55.5),(12.4,72.5),(.4,72.5)]: outline.Append(pcb.FromMM(100+x),pcb.FromMM(50+y))
b.Add(zone)
(MECH/"interface.scad").write_text(scad_constants())
pcb.SaveBoard(str(ROOT/(NAME+".kicad_pcb")),b)
project={"meta":{"filename":NAME+".kicad_pro","version":1},
    "board":{"design_settings":{"rules":{"min_clearance":.3,"min_track_width":.3,"min_via_diameter":.8,"min_through_hole_diameter":.4},"rule_severities":{"unconnected_items":"error"}}},
    "net_settings":{"classes":[{"name":"Default","clearance":.3,"track_width":.3,"via_diameter":.8,"via_drill":.4,"microvia_diameter":.3,"microvia_drill":.1,"diff_pair_width":.3,"diff_pair_gap":.3,"diff_pair_via_gap":.3}],"meta":{"version":4}},
    "schematic":{"drawing":{"default_line_thickness":6},"meta":{"version":1}}}
(ROOT/(NAME+".kicad_pro")).write_text(json.dumps(project,indent=2)+"\n")
(ROOT/"verification"/"expected-pin-nets.json").write_text(json.dumps({p["ref"]:p["nets"] for p in PARTS},indent=2)+"\n")
(ROOT/"parts.md").write_text("# Rev B-M1 assembly parts\n\nDigiKey selection dated 2026-09-04; see bom/ for priced purchasing lists.\nEngineering draft, not fabrication approval. DNP means do not populate.\nU2 and J8 purchasing part numbers are SOCKETS, not the already-owned modules.\n\n| Ref | Value | Manufacturer part number | Footprint | Assembly |\n|---|---|---|---|---|\n"+"".join(f'| {p["ref"]} | {p["value"]} | {by_ref[p["ref"]]["mpn"]} | {p["fp"]} | {"DNP" if p["dnp"] else "THT"} |\n' for p in PARTS)+"\nAlso required: existing WT32, blue 10-pin ADS1115, Mini100 and HW398 modules;\nMini100 male header, free-edge insulating support and retention; HW398-C2\nprinted base/retainer (fit-test first); 2x M2x16 screws, 4x M2 washers (OD <=5mm),\n2x ordinary M2 nuts UNDER the carrier; harness mates, contacts, wire, JP1 shunt;\n4 unthreaded insulating WT32 spacers and 4 self-tapping screws (2.3-2.5mm, length\nTBD). Support both socketed modules' free edges. No undocumented module mounting\nholes are drilled into the carrier. See bom/README.md for assembly cautions.\n")
print(f"Generated {sum(bool(p['fp']) for p in PARTS)} electrical footprints, {sum(n.startswith('/') for n in nets)} named nets, four WT32 clearance holes plus two M2 cradle holes, zero routed tracks. Module/cradle physical fit testing remains required.")
