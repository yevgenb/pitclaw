# Rev B-M1 carrier PCB — engineering draft

**Not ready to order. The PCB is placed and net-assigned, but deliberately
unrouted. No Gerbers or fabrication ZIP are released.** This is a native KiCad 9
starting point, not the earlier perfboard illustration.

**Mini100 integrated:** native CAD, previews, JSON selection, XLSX and CSV now
use the existing converter and a four-position socket instead of Traco U2.
The user confirmed **2.54 mm pitch** and **1.5 mm hole-row-to-short-edge offset**.
See the [module review](mini100-module-review.md) for orientation and remaining
fit/load checks. The converter supplies WT32 and **MG90S**; the blower stays on
12 V. F1–F4 and the buzzer driver have not been removed or altered electrically.
The [simplification review](simplification-review.md) separates recommendations
from implemented changes. Older B-DK1 output archives are superseded.

## Selected approach

- Two-layer carrier, candidate outline 60 × 92 mm, components facing away from
  the WT32-SC01 Plus. The user confirmed the 51.39 × 75.14 mm mounting pattern.
- No bare SMD parts to hand-solder on the carrier. ADS1115 and USB-C PD electronics
  stay on preassembled modules; other parts and sockets are through-hole.
- The user identified the existing **blue 10-pin ADS1115 module** with the
  Components101 link below. Its pictured board is 28 × 17 mm, with pin order
  VDD, GND, SCL, SDA, ADDR, ALRT, A0, A1, A2, A3. J8 is a single-row 10-pin
  female socket. The draft uses conventional **2.54 mm pitch**; the page does
  not dimension that pitch, hole diameter or header-to-edge offsets. These
  remain fit-check assumptions, not verified manufacturing dimensions.
- The user's photo identifies the existing USB-C PD trigger as **HW-398**.
  It is intended to supply 12 V; its actual selected output has not been verified.
  Its USB-C connector is the external power inlet. The planned attachment is an
  insulating clamp to this carrier, with a removable two-wire internal plug;
  there is no assumed undocumented pin-header footprint. The user measured
  **12 × 23 mm**, **1.5 mm PCB thickness** and **5 mm total height**. The
  [HW398-C2 reinforced cradle](mechanical/hw398/README.md) has printable base/retainer
  STLs and an optional test plate. Its two M2 fasteners use carrier holes H5/H6.
  Physical fit, solder relief and cable clearance still need testing. Do not
  drill holes in the trigger module.
- The selected 12 V-to-5 V converter is now the user's **Mini100** module. Its
  supplied listing and pictured connections are recorded in the module review;
  actual-unit fit and sustained output capability remain unverified.
  U2 is now a 1×4 socket with a 20 × 11 mm module envelope, parallel to the
  carrier. The body is at x=0.9–11.9, y=56–76 mm; the header row is at y=74.5.
  An F.Cu/B.Cu keepout reserves the switching body, leaving a header breakout
  strip. Row centering across the 11 mm width remains assumed; free-end support,
  retention and actual stacked height still need a fit test. The old Traco's
  2 A rating and 820 uF capacitor limit do not apply. Validate actual load,
  startup, output voltage and enclosed temperature before accepting this module.
- Three **Same Sky MJ1-2503A** probe jacks face the right edge. An **Amphenol
  RJHSE-5080** unmagnetized RJ45 faces the bottom edge. USB-C faces the bottom
  edge beside it. No external panel-mounted jacks are needed.
- Two short harnesses join the carrier to WT32 EXT and DEBUG. Screws provide
  mechanical attachment only. There is no unverified direct board-to-board mate.
  Carrier connectors J1/J7 are JST B2B-XH-A; J3 is B8B-XH-A, all 2.50 mm pitch.
  These do not mate directly with WT32's connectors. Label J1 **12V INPUT** and
  J7 **DEBUG 3V3 ONLY** at both harness ends: their identical housings must never
  be interchanged. Route/secure them separately.
- ADS1115 power comes from WT32 DEBUG pin 2; no carrier 3.3 V LDO. This remains
  conditional on the low-current loaded-rail test in the hardware review.

## Files and checks

`bom/selection.json` contains exact manufacturer/DigiKey part numbers and the
2026-09-04 US pricing snapshot. `bom/README.md` explains substitutions, purchasing
scope and unresolved fit/load checks. The priced workbook distinguishes fitted,
DNP, harness and unpriced external/mechanical items. This is a prototype parts
list, not approval to order PCBs. No bare SMD soldering is added.

`pitclaw-carrier.kicad_pro`, `.kicad_sch` and `.kicad_pcb` form the editable
project. `PitClaw.kicad_sym`, `PitClaw.pretty/`, and both library tables make the
custom module and connector definitions local to this project. Standard KiCad
libraries are also required. `previews/` contains schematic and placement views.
Component references are currently on the fabrication/assembly layer;
silkscreen reference placement and rail/connector safety labels still need to
be finalized before release. Upstream library provenance is in `LIBRARY-NOTICE.md`.

`tools/build_draft.py` generates the starting CAD from one pin/net description;
it is **not an autorouter**. Do not regenerate over subsequent manual CAD edits
without preserving them. `verification/` records actual ERC/DRC and a separate
schematic-to-PCB pin/net consistency check. Passing connectivity checks would
not establish electrical performance or mechanical fit.

## Electrical changes from perfboard Rev A.2

The fundamental circuit remains in `../../docs/wiring.md`. For **this PCB only**:

1. U2 is the socketed Mini100: **1 VOUT+, 2 GND, 3 VIN+, 4 EN (unconnected)**.
   The module's components face away from the carrier. Viewed from the carrier
   component side, the horizontal pad row reads **EN, VIN, GND, VOUT** left to
   right. Verify its actual markings before insertion. The BOM U2 MPN buys the
   socket, not the converter; its male header is a separate purchase row. This
   is not a SIP-3 footprint and cannot accept Traco, RECOM or a 7805.
2. D1 is an axial P6KE18A unidirectional TVS, not the SMD SMBJ15A. C1 is
   470 uF / **35 V**. A TVS suppresses transients; it is not a 12 V regulator or
   protection against selecting a sustained 15/20 V PDO. Verify 12 V first.
3. C3 is **220 uF**, C5 remains 100 uF. Mini100's allowed external capacitance
   is not documented in the supplied listing. Test startup and stability with
   these capacitors, their tolerances, WT32 and the servo connected. Do not
   increase bulk capacitance as a substitute for adequate converter capacity.
4. J8 is the ADC module socket, numbered 1–10 in the order printed on the linked
   blue board. Pins 1/2 are VDD/GND, 3/4 SCL/SDA, 5 ADDR (grounded for 0x48),
   6 ALRT (unused), 7/8/9/10 A0/A1/A2/A3. A0–A2 read probes; A3 measures the
   excitation rail through R16. Verify that order and module orientation with
   the actual part before insertion. The original ADS1115 silicon pin numbering
   is different; these are **module header numbers**, not IC pin numbers.
5. R17/R18 are optional 4.7 k pull-ups, **DNP** if the actual module has pull-ups.
   BZ1 is now a Same Sky CPT-1255C-090 passive piezo (12 mm diameter, 5 mm pitch).
   **R19 (1 kOhm) replaces unused D3** and discharges the piezo between pulses.
   Drive Q3 at approximately 4 kHz; a constant GPIO level does not produce a tone.
   F1–F4 now have exact Bourns parts/footprints, but their hold ratings, ambient
   derating and protection coordination still require load tests.

The existing GPIO12 high-side P-MOSFET circuit is retained. GPIO12 high turns
the blower on. The fan and servo share RJ45 pin 4 ground. Its 1.5 A contact rating
applies to **combined** return current; branch PTC hold ratings do not establish
protection for that contact. Bench-test startup/stall current before release.

JP1 must be removed when powering WT32 from its USB programming connector.
Carrier ground and DEBUG ground remain common; never feed an external supply
into the WT32 3.3 V rail. Keep the DEBUG/ADC current small and motor return
currents out of the harness. Do not hot-plug the ADC or DEBUG harness.

## Mechanical assumptions that block release

### HW-398 trigger photo review — 2026-09-04

The user supplied `IMG_4701.JPG`, showing the trigger beside a ruler. The photo
confirms the HW-398 board marking, a USB-C socket at one short end and two output
solder areas at the opposite end. With the socket facing left as photographed,
the upper output area is marked `+`. Small holes within the output solder areas
are not treated as mechanical mounting holes. The visible 9 V / 12 V / 15 V /
20 V legends do **not** establish which voltage is selected or negotiated.
Check output polarity and 12 V with a meter before connecting the carrier.

The user subsequently confirmed **12 × 23 mm** and supplied the underside photo
`IMG_4702.JPG`. These body dimensions come from the user's measurement, not
perspective scaling of either photo. The underside appears free of populated
components, but has exposed output pads and USB socket anchor solder joints.
Do not assume it is electrically insulated, perfectly flat or safe to rest
directly on carrier copper. The visible small holes and plated slots are not
used as mounting holes.

After the user confirmed **1.5 mm PCB thickness** and **5 mm total height**, the
HW398-C1 base and open-centre retainer were designed, then reinforced as C2 at
the user's request. The module body is now **x=36–48, y=69–92 mm**. The carrier
retains its 60 × 92 mm outline and original WT32 holes.
**2.4 mm NPTH holes H5 (33.2,74.2) and H6 (50.8,88.6)** secure
the holder with M2 machine screws, washers and nuts. These are separate from the
WT32's self-tapping screws. F.Cu/B.Cu track/via/pour keepouts now reserve the
holder and a 0.5 mm margin; component courtyard exclusion is independently
checked. See [the cradle guide](mechanical/hw398/README.md) for exact geometry.

The complete holder bounds are **24 × 27.2 mm**, with **11.8 mm** of plastic
height above the carrier (**13.7 mm nominal including screw heads**). C2 uses
2.4 mm walls, 6.9 mm-deep side webs, 3.2 mm roof crossbars at both ends, and
full-height 6.4 mm screw bosses with **M2 × 16 mm** screws. The retainer prints
roof-down without an unsupported bridge. Its front shoulders extend **2.6 mm beyond the PCB**;
allow this in the enclosure, and check the actual cable moulding. C1, C2, C3, C4,
C5, D1, F1, F3, F4 and J1 were moved/rotated for the earlier C1 integration.
The C2 reinforcement itself moved no electrical components. B-M1 subsequently
moves C3, C5, F1, R5 and D2 to make room for Mini100; their values/nets are unchanged.
The printed HW398 cradle, its holes and its keepout are unchanged. Existing
enclosure files were not edited or validated.

Retain the planned soldered output leads to J1 (pin 1 positive, pin 2 ground),
with a removable internal plug. The clamp/support must resist USB cable insertion
and removal without loading those leads, clear underside solder joints and prevent
contact with carrier copper. Body length, width, PCB thickness and populated
height are confirmed. The remaining physical checks are the underside seating
lands, 0.8 mm solder relief, local edge-finger clearance, USB opening/projection,
printed tolerances and cable access. Fastener engagement and at least 3 mm rear
hardware clearance must be checked against the actual WT32 stack. Print and test
the holder on the supplied plastic test plate before ordering the carrier PCB.

### ADC module and carrier stack

The ADC body is reserved at x=22.7–50.7, y=10.5–27.5 mm, viewed from the carrier
component side. J8 pin 1 (VDD) is x=25.24, y=26.00; pin 10 (A3) is x=48.10,
y=26.00. The module's components face away from the carrier. The two body-edge
offsets used for that placement are assumptions; validate them on the actual
module. Its own mounting holes are not drilled into the carrier. An insulating
support under the module's free edge is still needed. Nominal geometry fits the
60 × 92 mm outline; this does not certify the stack or plugged-in fit.

The published WT32 V1.3 drawing gives a 60 × 92 mm envelope, a 51.39 × 75.14 mm
mounting pattern and 2.3 mm holes. The user confirmed the pattern and specified
**2.3–2.5 mm self-tapping wood/plastic screws**, not M2/M3 machine screws.
The carrier therefore uses **3.0 mm unplated clearance holes**, with unthreaded
insulating spacers and screws engaging the WT32's existing mounts. Do not tap
or enlarge the WT32 holes. In a top-left-origin coordinate system the
draft uses x=4.305/55.695 and y=6.52/81.66 mm, **assuming horizontal centering**
and using the drawing's 10.34 mm lower-edge offset. Orientation/mirroring,
absolute edge offsets and mating orientation must still be checked against the
real assembly. Pattern spacing is confirmed; the derived absolute carrier
coordinates and overall stack have not had a physical fit test.

The stack needs unthreaded insulating spacers sized from actual WT32 rear components,
trimmed through-hole leads, screw engagement and clearance. Do not assume a
10 mm spacer will fit. Keep metal fasteners and the MOSFET's live drain tab
clear of the display board. Confirm SD-card, USB-programming and harness access.
The WT32 antenna location is not yet confirmed; antenna keepout/board cutback
must be set **before routing**, not guessed from the enclosure source.

The three probe footprints follow the manufacturer's top-view drawing (sleeve
pin 1, tip pins 2 and 3), including the 1.2 mm locating hole. Plated slots in this
draft use the recommended 1.50 × 0.50 mm geometry. Obtain actual parts and check
lead and finished-slot tolerances before ordering. The RJ45 contact arrangement
is a provisional adaptation of KiCad's related RJHSE-5380 footprint with no
shield pads; the exact RJHSE-5080 drawing must be visually reconciled before
release. Neither a shared family name nor matching pad count validates a part.

## Finish and release plan

1. Fit-check both ADS1115 and Mini100 sockets/supports, and print/test the HW398-C2
   cradle. Mini100 pitch/short-edge offset are confirmed, but transverse row
   centering, total stack height and retention still need checks. Measure USB
   projection and WT32 rear-component clearance. The PD body
   is confirmed at 12 × 23 mm, PCB 1.5 mm, total height 5 mm; WT32 pattern and
   screw type are also confirmed. Resolve printed fit and cradle screw clearance.
   The servo is MG90S; measure actual loaded/startup current and identify the
   blower's load requirements. Resolve fuse selection and buzzer audibility.
2. Obtain one of each connector. Print a 1:1 KiCad fabrication-layer drawing,
   verify all leads, locating pegs, mating directions and cable access. Compare
   all mounting holes with the actual WT32, including handedness.
3. Freeze the outline, mounting, antenna clearance, module supports and connector
   cutouts. Update the enclosure as a separate coordinated change; the current
   SCAD mounts are not validated for this PCB.
4. Route two layers: keep a continuous ground reference; place the fan clamp and
   buck capacitors close to their current loops. Keep fan/servo returns near the
   power entry, away from the probe/ADC area. Do not split the plane beneath I2C.
   Start with 0.30 mm signal traces/clearance and 0.8/0.4 mm vias; calculate power
   widths for measured current, copper weight and allowed temperature rise.
5. Run ERC, PCB/schematic consistency, DRC, unconnected-pad and footprint reviews.
   Do not waive unrouted nets or unconfirmed mechanical warnings to obtain a pass.
6. Once cleared, export top/bottom copper, masks, silkscreen, board outline and
   separate PTH/NPTH Excellon drill/slot files; inspect them in a Gerber viewer.
   Target JLCPCB standard two-layer FR-4, 1.6 mm, 1 oz, lead-free HASL (or ENIG).
   Verify the current plated-slot capability/tolerance before placing an order.
   No stencil or assembly service is needed for hand assembly of this carrier.
7. Assemble and bring up with a current-limited bench supply, loads disconnected.
   Check 12 V, 5 V, DEBUG-derived 3.3 V, I2C and fixed-resistor probe readings.
   Then add fan and servo individually and together; scope transients and test
   reset/default-off behavior. Resolve the firmware pin conflicts and probe
   equation/open-probe threshold identified in the hardware review first.

## Sources

- [WT32 V1.3 manual and mechanical drawing](https://github.com/janick/WT32-SqLn/blob/main/docs/WT32-SC01-Plus-V1.3-EN.pdf)
- [User-identified blue ADS1115 module](https://components101.com/modules/ads1115-module-with-programmable-gain-amplifier)
  and its [28 × 17 mm body illustration](https://components101.com/sites/default/files/inline-images/ADS1115-Dimensions.jpg).
  This identifies the pictured module style, not an authoritative fabrication drawing.
- [Mini100 seller listing](https://www.amazon.com/dp/B08JZ5FVLC/)
- [Sullins socket drawing](https://mm.digikey.com/Volume0/opasdata/d220001/medias/docus/937/Female_Headers.100_DS.pdf)
- [DigiKey cost review and exact-parts BOM](bom/README.md)
- [Same Sky MJ1-2503A drawing](https://www.sameskydevices.com/product/resource/mj1-2503a.pdf)
- [Amphenol RJHSE-x080 drawing — pending reconciliation](https://cdn.amphenol-cs.com/media/wysiwyg/files/drawing/rjhsex080.pdf)
- [Amphenol RJHSE electrical specification](https://cdn.amphenol-cs.com/media/wysiwyg/files/documentation/s6032c_rjhse.pdf)
- [FQP27P06 datasheet](https://www.onsemi.com/pdf/datasheet/fqp27p06-d.pdf)
- [ST P6KE TVS family](https://www.st.com/resource/en/datasheet/p6ke150a.pdf)
- [HeaterMeter blower/servo pinout](https://github.com/CapnBry/HeaterMeter/wiki/Blower-and-Servo-Wiring)
- [JLCPCB capabilities](https://jlcpcb.com/capabilities/Capabilities)

No parts have been ordered and no manufacturing files have been submitted.

## Optional smaller ADC module

The user also suggested [AliExpress item 3256806179278252](https://www.aliexpress.us/item/3256806179278252.html),
listed as a ZY ADS1115 module. The listing's photo shows a different edge-pad
arrangement; it is not a drop-in substitute for J8. Detailed inspection was
interrupted by the site's robot check, so dimensions, pin pitch, mounting and
pull-up arrangement have **not** been verified. The platform's AI-generated
size summary is not used as engineering data. Keep the existing blue module
for this revision: its nominal body fits the carrier. If the compact module is
selected later, obtain its real dimension/pinout drawing and revise J8 rather
than adding an unverified second footprint.
