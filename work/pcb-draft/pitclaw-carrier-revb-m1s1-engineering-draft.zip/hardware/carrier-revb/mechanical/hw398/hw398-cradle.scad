// Pit Claw HW398-C2: reinforced fit-test cradle, NOT a validated mechanical release.
// Units: mm. Deep side webs, full-height screw bosses and TWO roof cross-ties.
// Generated measured/interface constants come from interface.json. See README.
include <interface.scad>

part = "assembly"; // [base, cap, test_plate, assembly, exploded, print_set, module, interference]
$fn = 64;
eps = 0.02;

half_pocket = module_w/2 + fit_xy;
half_outer = half_pocket + wall;
front_outer = -fit_xy - front_wall;
rear_outer = module_l + fit_xy + rear_wall;
cap_seat = seat_h + pcb_t + pcb_gap;
roof_bottom = seat_h + module_h + roof_gap;
cap_top = roof_bottom + cap_t;
cap_h = cap_top - cap_seat;

assert(module_w == 12 && module_l == 23, "Body change needs a new PCB interface review");
assert(seat_h > floor_h && pcb_t > 0 && module_h > pcb_t);
assert(usb_open_w < module_w && usb_open_w > 9);
assert(finger_overlap > 0 && finger_overlap < 1.2);
assert(wall >= 2.4 && cap_t >= 3.2 && floor_h >= 2.4);
assert(rear_roof_y > finger_y[1] && rear_roof_y < module_l);
assert(min([for (p=mounts) abs(p[0])-half_pocket-print_hole_d/2]) >= 1.39,
       "Screw boss inner web is too thin");

module outer_plan() {
    union() {
        translate([-half_outer, front_outer])
            square([2*half_outer, rear_outer-front_outer]);
        for (p=mounts) translate(p) circle(r=ear_r);
    }
}
module bores(z, h) {
    for (p=mounts) translate([p[0],p[1],z]) cylinder(d=print_hole_d,h=h);
}
module base() {
    difference() {
        union() {
            // Insulating floor; central lands avoid the USB shell's outer anchor joints.
            linear_extrude(height=floor_h) outer_plan();
            translate([-2,0.8,floor_h]) cube([4,5.7,seat_h-floor_h]);
            translate([-4,8.5,floor_h]) cube([8,9.5,seat_h-floor_h]);
            // Pocket walls and screw shoulders terminate at the hard cap stop.
            difference() {
                linear_extrude(height=cap_seat) outer_plan();
                translate([-half_pocket,-fit_xy,floor_h-eps])
                    cube([2*half_pocket,module_l+2*fit_xy,cap_seat+eps]);
            }
        }
        bores(-eps,cap_seat+2*eps);
        // Through opening at the USB end; no floor lip under the plug nose.
        translate([-usb_open_w/2,front_outer-eps,-eps])
            cube([usb_open_w, -front_outer+0.6,cap_seat+2*eps]);
        // Corner escape channels for output pads/leads; retain the middle end stop.
        for (s=[-1,1]) translate([s < 0 ? -half_pocket : 3.5,module_l-2.5,floor_h])
            cube([half_pocket-3.5,fit_xy+rear_wall+2.5+eps,cap_seat+eps]);
    }
}
module cap() {
    // In assembly coordinates. Print inverted: roof ties and rail tops on the bed.
    difference() {
        union() {
            // Deep continuous side webs and full-height bosses replace thin ears/posts.
            // Clip ALL bosses at the pocket edge: no hidden boss overhang over parts.
            difference() {
                translate([0,0,cap_seat]) linear_extrude(height=cap_h) outer_plan();
                translate([-half_pocket,front_outer-eps,cap_seat-eps])
                    cube([2*half_pocket,rear_outer-front_outer+2*eps,cap_h+2*eps]);
            }
            // Only these local fingers overlap the PCB near its rear; no blanket rim.
            for (s=[-1,1]) translate([s < 0 ? -half_outer : module_w/2-finger_overlap,finger_y[0],cap_seat])
                cube([wall+fit_xy+finger_overlap,finger_y[1]-finger_y[0],cap_h]);
            // A doubled-thickness/depth bridge limits front lift without shell preload.
            translate([-half_outer,roof_y[0],roof_bottom])
                cube([2*half_outer,roof_y[1]-roof_y[0],cap_t]);
            // Rear cross-tie closes the frame; leads escape UNDER it through the base.
            translate([-half_outer,rear_roof_y,roof_bottom])
                cube([2*half_outer,rear_outer-rear_roof_y,cap_t]);
        }
        bores(cap_seat-eps,cap_h+2*eps);
    }
}
module print_cap() { translate([0,0,cap_top]) mirror([0,0,1]) cap(); }
module module_envelope() {
    // Simplified collision fixture, NOT an exact CAD model of the electronic module.
    color([0.08,0.10,0.10]) translate([-module_w/2,0,seat_h]) cube([module_w,module_l,pcb_t]);
    // USB width/depth/projection are fit-test assumptions, deliberately documented.
    color([0.7,0.72,0.74]) translate([-4.5,-0.7,seat_h+pcb_t]) cube([9,8.7,module_h-pcb_t]);
    color([0.16,0.17,0.18]) translate([-2.5,9,seat_h+pcb_t]) cube([5,7,1.5]);
}
module screw_envelopes() {
    // Illustration only: M2x16 shaft, nominal head and lower washer/nut envelope.
    for(p=mounts) {
        color("silver") translate([p[0],p[1],cap_top+0.3-screw_l]) cylinder(d=2,h=screw_l);
        color("silver") translate([p[0],p[1],cap_top]) cylinder(d=5,h=0.3);
        color("silver") translate([p[0],p[1],cap_top+0.3]) cylinder(d=3.8,h=1.6);
        color("silver") translate([p[0],p[1],-1.9]) cylinder(d=5,h=0.3);
        color("silver") translate([p[0],p[1],-3.5]) cylinder(d=4.62,h=1.6,$fn=6);
    }
}
module carrier_patch() {
    color([0.08,0.34,0.22]) difference() {
        translate([-14,0,-1.6]) cube([28,28,1.6]);
        bores(-1.7,1.8);
    }
}
if (part=="base") base();
else if (part=="cap") print_cap();
else if (part=="test_plate") translate([0,0,1.6]) carrier_patch();
else if (part=="print_set") {
    translate([12,2,0]) base();
    translate([39,2,0]) print_cap();
}
else if (part=="module") module_envelope();
else if (part=="interference") intersection() { union(){base(); cap();} module_envelope(); }
else if (part=="assembly" || part=="exploded") {
    carrier_patch();
    color([0.22,0.48,0.70]) base();
    translate([0,0,part=="exploded" ? 5 : 0]) module_envelope();
    color([0.95,0.61,0.17]) translate([0,0,part=="exploded" ? 12 : 0]) cap();
    if (part=="assembly") screw_envelopes();
} else assert(false,"Unknown part");
