# HW398-C2 reinforced cradle — print and fit-test first

This holder is designed for **your measured 12 × 23 mm HW-398**, with a **1.5 mm
PCB and 5 mm total populated height**. It has not been printed or load-tested.
Do not order the carrier PCB until the physical fit checks below are complete.

## Reinforcement versus C1

This replaces C1's thin rails and isolated USB-bridge posts with a deep frame.
It is a geometry revision, **not a measured strength or service-life rating**.

| Structural feature | C1 | C2 |
|---|---:|---:|
| Main side-rail cross-section, width × height | 1.4 × 1.6 mm | **2.4 × 6.9 mm** |
| USB crossbar, front-to-back × thickness | 3 × 1.6 mm | **6 × 3.2 mm** |
| Rear upper cross-tie | None | **3.6 × 3.2 mm**, across the frame |
| Screw bosses, diameter × cap height | 5.4 × 1.6 mm | **6.4 × 6.9 mm** |
| Insulating base floor | 1.8 mm | **2.4 mm** |
| Front stop depth | 1.4 mm | **2.4 mm** |

Full-height bosses merge into the side webs; there are no thin screw tabs.
Their inner sides are clipped at the pocket, so the bosses themselves do not
overhang the electronics. The minimum hole-to-pocket ligament is 1.4 mm;
the outer radial boss wall is 2 mm. The rear base stop remains 1.4 mm deep,
7 mm wide, backed by the base floor; the new upper cross-tie braces the cap.
Only the two explicitly modelled rear fingers overlap the PCB edge.

The cap prints **upside down**, with both crossbars flat on the bed, eliminating
C1's unsupported USB bridge. This does not eliminate printed-layer weakness,
plastic creep, or the need for a real cable-load test.

**Do not mix C1 and C2 parts, test plates or PCB hole patterns.** Both screws
move and must be longer. C2 is 24 × 27.2 mm overall, versus C1's 22 × 26.2 mm.

## What to print

- `stl/hw398-base.stl`: insulating floor, seating lands, side/end stops and screw shoulders.
- `stl/hw398-retainer.stl`: removable deep, cross-tied frame, USB-shell lift restraint
  and two short rear PCB-edge fingers.
- `stl/hw398-test-plate.stl`: optional **28 × 28 × 1.6 mm** plastic plate with the
  same two mounting holes and front edge as the carrier. Use this to test the
  cradle now; it is not an electrical board or a full WT32 mechanical mockup.

Print **one of each, at 100% scale, in millimetres**. The STLs already have their
intended lower faces at Z=0. They may be re-centred on the print bed, but do not
scale them to adjust the fit: that would move the mounting holes.

Suggested first-print settings for a 0.4 mm nozzle:

- PETG; 0.2 mm layers (0.1 mm if needed for finer fit), 4 walls, 100% infill.
- Base: broad bottom face on the bed. No supports should be needed.
- Retainer: **roof/crossbars down, seating face up**, as exported in the STL.
  No supports should be required. Do not flip it to match the assembled preview.
  Check the slicer's first-layer view: both roof crossbars and boss tops should
  touch the bed, and all later sections grow directly from those features.
- Test plate: broad flat face on the bed, no supports.
- A brim is optional. Remove it completely from the fit surfaces and holes.

`previews/print-orientation.png` shows the base on the left and inverted cap
on the right in their intended print orientations; the test plate prints flat.

These are starting settings, not a heat rating. Keep the controller away from
hot cooker surfaces; validate the completed holder at the measured enclosure
temperature. Thin retaining features must not soften, creep or crack in use.

## Fasteners

For the nominal 1.6 mm carrier/test plate:

- 2 × **M2 × 16 mm pan-head machine screws** (C1's 10 mm screws are too short).
- 4 × M2 flat washers, outside diameter **at most 5 mm**.
- 2 × ordinary M2 hex nuts, approximately 1.6 mm high.

These are **not** the WT32's 2.3–2.5 mm self-tapping screws. Do not drive screws
into the HW-398 output holes. No printed threads, heat-set inserts or adhesive
are required.

Each screw passes downward through a washer, retainer, cradle shoulder and
carrier; a washer and nut secure it underneath. The cap bottoms against the
printed shoulders, not against the electronics. Tighten only until snug; do
not bow the carrier or crush the plastic. Typical nominal stack leaves about
0.4 mm of thread beyond the nut, but verify your actual screws/washers/nuts.
Do not substitute taller locknuts without rechecking screw length.

Reserve **at least 3 mm below the carrier** for these fasteners, plus clearance
to the WT32's actual rear components. Install and inspect the cradle hardware
before attaching the carrier to the display assembly. Nothing may touch the
WT32 or its live circuitry.

Nominal top-of-plastic height is **11.8 mm above the carrier**. With a 0.3 mm
upper washer and a 1.6 mm screw head, allow **13.7 mm above the carrier**.
Actual head geometry may be different. The nominal 16 mm screw tip reaches
3.9 mm below the carrier's top, or 2.3 mm below its 1.6 mm bottom face.

## Assembly and fit checks

1. With all power disconnected, put the module into the blue/base part. The USB
   end faces the large front opening; the output pads face the two rear corner
   wire channels. The photo/model colours are illustrative only.
2. Confirm the PCB seats on both central lands without rocking. The lower
   solder-clearance recess is **0.8 mm deep**; the USB anchor solder joints must
   not bottom on the floor. The front land is under the centre of the USB region,
   not its outer anchor joints. Rework the model if the actual underside needs
   different relief; do not grind or drill the electronic module.
3. Check the retainer's two rear fingers. They overlap the outer **0.7 mm** of
   the PCB over a **2 mm band, 17.5–19.5 mm from the USB-end PCB edge**. They must
   lie over clear substrate/pads without protruding solder or components. Their
   location is inferred from the photograph, not a component-placement drawing.
   If any part is contacted, stop and move/relieve those fingers in the source.
4. Place the retainer without screws first. It must seat on the cradle shoulders
   without pushing the module down. Nominal gaps are **0.2 mm above the PCB** at
   the rear fingers and **0.4 mm above the USB shell** at the front bridge.
   Remove first-layer burrs/elephant's foot; do not force the cap shut.
5. Fasten the assembly to the printed test plate. The front shoulders must stop
   PCB withdrawal, and the centre rear stop must resist insertion. The USB front
   opening is **10.4 mm wide**; check it with your real socket and cable. Verify
   full plug engagement and that the cable moulding does not hit the holder.
6. Add short flexible output leads through the rear corner channels to J1:
   positive to J1 pin 1, negative to pin 2. Confirm polarity on the real module.
   Leave a slack loop; neither the wire nor its solder pad is a structural mount.
   Route leads **under the rear cross-tie**, not across its seating surfaces.
   Its underside is 3.9 mm above the nominal PCB top. Check real solder joints
   and insulated wires, which are not included in the simplified collision model.
   Check that leads cannot be pinched by the cap, screws or enclosure.
7. Try repeated normal plug/unplug cycles and gentle cable movement in all
   directions. There must be no PCB slip, rocking, whitening/cracking, loosening,
   damage to the USB joint, or wire strain. This is a prototype check, not a USB
   connector certification or a specified load rating. Repeat after warm operation.
8. Finally verify 12 V negotiation and the actual circuit under current-limited
   bench conditions. The holder does not establish voltage selection, module
   current capability, or electrical protection.

The preview's electronic module is a **simplified clearance fixture**, not a
scanned model. USB shell width/depth/projection and the small-component shapes
are approximate. The exact bare-board thickness, overall width/length and total
height are user measurements; those do not validate the remaining local details.

## PCB interface

Coordinates below use the carrier's top-left origin, component-side view,
X right and Y down. The WT32 mounting pattern and 60 × 92 mm carrier outline
have not changed.

| Feature | Carrier coordinates / size |
|---|---|
| Module body | X 36–48 mm, Y 69–92 mm |
| Module USB/front edge | Y 92 mm, opening toward increasing Y |
| H5 cradle fastener | X 33.2 mm, Y 74.2 mm; Ø2.4 mm NPTH |
| H6 cradle fastener | X 50.8 mm, Y 88.6 mm; Ø2.4 mm NPTH |
| Holder base body excluding bosses | X 33.4–50.6 mm, Y 67.4–94.6 mm |
| Complete holder XY bounding box | X 30–54 mm, Y 67.4–94.6 mm |
| Assembled plastic height above carrier | 11.8 mm; nominal 13.7 mm including screw heads |
| Front overhang beyond carrier | **2.6 mm**; must be accommodated by the enclosure |

The new F.Cu/B.Cu rule area follows a conservative stepped outline around the
base and screw ears with a **0.5 mm margin**, clipped to the PCB front edge.
It prohibits tracks, vias and copper pours. NPTH mounting pads are intentional;
electrical-component/courtyard exclusion is also checked by `check_draft.py`.
Do not place other components, solder tails or exposed copper beneath the holder.

The earlier cradle integration repositioned C1, C2, C3, C4, C5, D1, F1, F3, F4
and J1. **This reinforcement does not move any electrical parts.** The HW-398
body moves 1 mm right; H5/H6, mechanical outlines and copper keepout change.
No electrical nets, component values, probe/RJ45 positions or WT32 mounting
holes changed. The electrical PCB remains **unrouted and not for fabrication**.
The existing enclosure SCAD/STLs were not modified; their cutouts and stack are
not yet validated for this carrier.

## Editing / regeneration

Open `hw398-cradle.scad` in OpenSCAD with `interface.scad` beside it. Choose
`part="base"`, `"cap"`, `"test_plate"`, `"assembly"` or `"exploded"`.
STL files contain the real printable parts, not the coloured dummy module.

For the coordinated project, **`interface.json` is the dimension source of truth**.
`tools/fit_hw398_cradle.py` reads it, writes `interface.scad`, and applies the same
holes/keepout to the existing unrouted KiCad board. It refuses to move parts once
tracks exist and checks that electrical pad nets remain unchanged. Back up any
manual PCB edits before using it. The original complete-draft builder also
imports this interface, but regenerates the whole CAD project.

For a standalone fit experiment you may edit `interface.scad` directly; record
your changes and transfer them back to `interface.json` before updating the PCB.
Changing external dimensions, screw positions or pocket clearance requires a new
PCB clearance check, not just an STL re-export.

For reproducible STL export, select OpenSCAD's **CGAL backend** (CLI option
`--backend CGAL --export-format binstl`). The installed Manifold backend produced
a degenerate triangle on the cap; the supplied CGAL-exported cap passed the
mesh checks without weakening those checks.

## Verification performed

- All three printable STLs: one connected, closed/watertight shell, consistent
  triangle orientation and positive volume; lower face at Z=0.
- The simplified module fixture has no solid-volume intersection with the holder.
  This does not check the real component/solder geometry or insertion path.
- PCB electrical pad/net assignments preserved; two cradle hole coordinates and
  diameters checked against the shared interface; no component/WT32-hole courtyard
  intersects the reserved holder region.
- Compared with the saved C1 board: all electrical footprint positions/rotations
  and four WT32 mounting holes unchanged; schematic file is byte-identical.
- See the project's `verification/` reports for actual DRC and connectivity status.

**Still required:** physical printing, fit, cable clearance, fastener engagement,
warm operation, and a complete PCB/enclosure/routing release review.
