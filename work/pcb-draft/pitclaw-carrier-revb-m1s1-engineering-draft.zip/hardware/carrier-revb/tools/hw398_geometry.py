"""Shared cradle interface and additive KiCad update; never routes or changes nets."""
import json
import math
from pathlib import Path
import uuid
import pcbnew as pcb

ROOT = Path(__file__).resolve().parents[1]
MECH = ROOT / "mechanical/hw398"
CFG = json.loads((MECH / "interface.json").read_text())
NS = uuid.UUID("e066054b-5e87-432d-988b-5d5a36f14a36")
OWNED_DRAWINGS = {}
def vec(x,y): return pcb.VECTOR2I(pcb.FromMM(x),pcb.FromMM(y))
def carrier(p):
    a=CFG["carrier_anchor_mm"]
    return (round(a["center_x"]+p[0],4),round(a["front_y"]-p[1],4))
def holes(): return [carrier(p) for p in CFG["fasteners_local_mm"]]
def rectangles(margin=0):
    """Conservative XY body/ear rectangles in carrier coordinates; front overhang retained."""
    m=CFG["measured_module_mm"]; a=CFG["carrier_anchor_mm"]
    half=m["width"]/2+CFG["pocket_clearance_per_side_mm"]+CFG["wall_mm"]
    front=CFG["pocket_clearance_per_side_mm"]+CFG["front_wall_mm"]
    rear=CFG["pocket_clearance_per_side_mm"]+CFG["rear_wall_mm"]
    result=[(a["center_x"]-half-margin,a["front_y"]-m["length"]-rear-margin,
             a["center_x"]+half+margin,a["front_y"]+front+margin)]
    r=CFG["ear_radius_mm"]+margin
    result += [(x-r,y-r,x+r,y+r) for x,y in holes()]
    return result
def keepout_polygon():
    # Union of three rectangles; the two ears are at staggered Y positions.
    body,left,right=rectangles(CFG["keepout_margin_mm"])
    x1,y1,x2,y2=body; y2=min(y2,92)
    right_bottom=min(right[3],y2)
    points=[(x1,y1),(x2,y1),(x2,right[1]),(right[2],right[1]),
            (right[2],right_bottom),(x2,right_bottom),(x2,y2),(x1,y2),
            (x1,left[3]),(left[0],left[3]),(left[0],left[1]),(x1,left[1])]
    # Clip the front ear's margin without duplicate/backtracking front-edge vertices.
    unique=[]
    for p in points:
        if not unique or p != unique[-1]: unique.append(p)
    return [p for i,p in enumerate(unique) if not
            (unique[i-1][0]==p[0]==unique[(i+1)%len(unique)][0] or
             unique[i-1][1]==p[1]==unique[(i+1)%len(unique)][1])]
def scad_constants():
    m=CFG["measured_module_mm"]
    vals={"module_w":m["width"],"module_l":m["length"],"pcb_t":m["pcb_thickness"],"module_h":m["total_height"],
          "fit_xy":CFG["pocket_clearance_per_side_mm"],"wall":CFG["wall_mm"],"floor_h":CFG["floor_mm"],
          "front_wall":CFG["front_wall_mm"],"rear_wall":CFG["rear_wall_mm"],
          "seat_h":CFG["seat_height_mm"],"pcb_gap":CFG["pcb_vertical_clearance_mm"],
          "roof_gap":CFG["usb_roof_clearance_mm"],"cap_t":CFG["cap_thickness_mm"],
          "rear_roof_y":CFG["rear_roof_start_mm"],"screw_l":CFG["screw_length_mm"],
          "usb_open_w":CFG["usb_front_opening_width_mm"],"roof_y":CFG["roof_y_mm"],
          "finger_y":CFG["rear_finger_y_mm"],"finger_overlap":CFG["finger_overlap_mm"],
          "mounts":CFG["fasteners_local_mm"],"ear_r":CFG["ear_radius_mm"],
          "print_hole_d":CFG["printed_hole_diameter_mm"]}
    return "// Generated from interface.json; run tools/fit_hw398_cradle.py after interface edits.\n"+"".join(f"{k} = {json.dumps(v)};\n" for k,v in vals.items())
def tag(obj,key): OWNED_DRAWINGS[key]=obj.m_Uuid.AsString()
def line(b,a,c,key):
    s=pcb.PCB_SHAPE(b);s.SetShape(pcb.SHAPE_T_SEGMENT);s.SetStart(vec(100+a[0],50+a[1]));s.SetEnd(vec(100+c[0],50+c[1]));s.SetWidth(pcb.FromMM(.15));s.SetLayer(pcb.Dwgs_User);tag(s,key);b.Add(s)
def note(b,t,x,y,key):
    s=pcb.PCB_TEXT(b);s.SetText(t);s.SetPosition(vec(100+x,50+y));s.SetTextSize(vec(.75,.75));s.SetTextThickness(pcb.FromMM(.12));s.SetLayer(pcb.Dwgs_User);tag(s,key);b.Add(s)
def update_board(b):
    assert len(b.GetTracks())==0, "Refusing automatic placement moves after routing has begun"
    refs={f.GetReference():f for f in b.GetFootprints()}
    for ref,(x,y,angle) in CFG["carrier_placement_changes"].items():
        refs[ref].SetOrientationDegrees(angle);refs[ref].SetPosition(vec(100+x,50+y))
    # Remove only earlier known HW398 body drawings/labels, or our tagged drawings.
    manifest=MECH/"pcb-owned-drawings.json"
    ids=set(json.loads(manifest.read_text()).values()) if manifest.exists() else set()
    OWNED_DRAWINGS.clear()
    for item in list(b.GetDrawings()):
        old=False
        if isinstance(item,pcb.PCB_TEXT):
            old=item.GetText() in ("HW-398\n12 x 23 mm\nCLAMP TBD","PD 12V\nCLAMP TBD")
            if item.GetText()=="USB-C PD\n12V ONLY": item.SetPosition(vec(100+CFG["carrier_anchor_mm"]["center_x"],146))
            if item.GetText()=="PIT CLAW B-DRAFT":
                item.SetLayer(pcb.Dwgs_User);item.SetPosition(vec(130,142.5))
        elif isinstance(item,pcb.PCB_SHAPE) and item.GetLayer()==pcb.Dwgs_User and item.GetShape()==pcb.SHAPE_T_SEGMENT:
            points=[(round(pcb.ToMM(p.x),3),round(pcb.ToMM(p.y),3)) for p in (item.GetStart(),item.GetEnd())]
            old=all(p[0] in (139.5,140,151.5) and p[1] in (119,142) for p in points)
        if old or item.m_Uuid.AsString() in ids: b.RemoveNative(item)
    for ref in ("H5","H6"):
        if ref in refs: b.RemoveNative(refs[ref])
    for zone in list(b.Zones()):
        if zone.GetZoneName() in ("HW398_CRADLE_C1_NO_COPPER","HW398_CRADLE_C2_NO_COPPER"): b.RemoveNative(zone)
    for i,(x,y) in enumerate(holes(),5):
        f=pcb.FOOTPRINT(b);f.SetReference("H"+str(i));f.SetValue("M2 CRADLE / 2.4 NPTH")
        f.SetFPID(pcb.LIB_ID("PitClaw","HW398_Cradle_M2"));f.SetAttributes(pcb.FP_EXCLUDE_FROM_BOM|pcb.FP_EXCLUDE_FROM_POS_FILES|pcb.FP_BOARD_ONLY)
        f.Reference().SetLayer(pcb.F_Fab);f.Reference().SetTextSize(vec(.8,.8));f.Reference().SetPosition(vec(0,-CFG["ear_radius_mm"]-.5));f.Value().SetVisible(False)
        pad=pcb.PAD(f);pad.SetNumber("");pad.SetAttribute(pcb.PAD_ATTRIB_NPTH);pad.SetShape(pcb.PAD_SHAPE_CIRCLE)
        pad.SetSize(vec(CFG["carrier_hole_diameter_mm"],CFG["carrier_hole_diameter_mm"]));pad.SetDrillSize(pad.GetSize())
        layers=pcb.LSET.AllCuMask();layers.AddLayer(pcb.F_Mask);layers.AddLayer(pcb.B_Mask);pad.SetLayerSet(layers);f.Add(pad)
        r=CFG["ear_radius_mm"]
        for layer,r in [(pcb.F_CrtYd,r+.25),(pcb.B_CrtYd,r+.25),(pcb.F_Fab,r)]:
            c=pcb.PCB_SHAPE(f);c.SetShape(pcb.SHAPE_T_CIRCLE);c.SetCenter(vec(0,0));c.SetEnd(vec(r,0));c.SetWidth(pcb.FromMM(.05));c.SetLayer(layer);f.Add(c)
        pcb.PCB_IO_MGR.PluginFind(pcb.PCB_IO_MGR.KICAD_SEXP).FootprintSave(str(ROOT/"PitClaw.pretty"),f)
        f.SetPosition(vec(100+x,50+y));b.Add(f)
    a=CFG["carrier_anchor_mm"];m=CFG["measured_module_mm"]
    body=[(a["center_x"]-m["width"]/2,a["front_y"]-m["length"]),(a["center_x"]+m["width"]/2,a["front_y"]-m["length"]),(a["center_x"]+m["width"]/2,a["front_y"]),(a["center_x"]-m["width"]/2,a["front_y"])]
    for i in range(4): line(b,body[i],body[(i+1)%4],f"body-{i}")
    for n,(x1,y1,x2,y2) in enumerate(rectangles()):
        pts=[(x1,y1),(x2,y1),(x2,y2),(x1,y2)]
        for i in range(4): line(b,pts[i],pts[(i+1)%4],f"rect-{n}-{i}")
    note(b,"HW-398 12x23\nCRADLE C2\nFIT TEST",a["center_x"],80,"label")
    overhang=CFG["pocket_clearance_per_side_mm"]+CFG["front_wall_mm"]
    note(b,f"CRADLE OVERHANG {overhang:g} mm",a["center_x"],99.0,"overhang")
    zone=pcb.ZONE(b);zone.SetIsRuleArea(True);zone.SetZoneName("HW398_CRADLE_C2_NO_COPPER")
    layer_set=pcb.LSET();layer_set.AddLayer(pcb.F_Cu);layer_set.AddLayer(pcb.B_Cu);zone.SetLayerSet(layer_set)
    zone.SetDoNotAllowTracks(True);zone.SetDoNotAllowVias(True);zone.SetDoNotAllowCopperPour(True)
    # NPTH hardware is intentionally in this area; electrical component exclusion is independently checked.
    zone.SetDoNotAllowPads(False);zone.SetDoNotAllowFootprints(False)
    outline=zone.Outline();outline.NewOutline()
    for x,y in keepout_polygon(): outline.Append(pcb.FromMM(100+x),pcb.FromMM(50+y))
    b.Add(zone)
    manifest.write_text(json.dumps(OWNED_DRAWINGS,indent=2)+"\n")
