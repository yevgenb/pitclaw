#!/usr/bin/env python3
"""Dependency-free binary STL topology and dimensions check, not mechanical certification."""
from collections import defaultdict, deque
import json
from pathlib import Path
import struct

root=Path(__file__).resolve().parents[1]
cfg=json.loads((root/"mechanical/hw398/interface.json").read_text())
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def dot(a,b): return sum(x*y for x,y in zip(a,b))
reports={}
for name in ["hw398-base","hw398-retainer","hw398-test-plate"]:
    data=(root/"mechanical/hw398/stl"/(name+".stl")).read_bytes()
    n=struct.unpack_from("<I",data,80)[0];assert len(data)==84+50*n
    verts=[];edges=defaultdict(list);volume=0
    for i in range(n):
        vals=struct.unpack_from("<12fH",data,84+50*i)
        tri=[tuple(round(v,5) for v in vals[j:j+3]) for j in (3,6,9)]
        a,b,c=tri;normal=cross(sub(b,a),sub(c,a))
        assert dot(normal,normal)>1e-14,(name,"degenerate triangle",i)
        volume+=dot(a,cross(b,c))/6
        verts+=tri
        for j in range(3):
            u,v=tri[j],tri[(j+1)%3]
            edges[tuple(sorted((u,v)))].append((i,1 if u<v else -1))
    assert all(len(v)==2 for v in edges.values()),(name,"non-manifold or open edge")
    assert all(sum(t[1] for t in v)==0 for v in edges.values()),(name,"inconsistent winding")
    adjacency=defaultdict(set)
    for v in edges.values():
        a,b=v[0][0],v[1][0];adjacency[a].add(b);adjacency[b].add(a)
    visited={0};queue=deque([0])
    while queue:
        for i in adjacency[queue.popleft()]-visited: visited.add(i);queue.append(i)
    assert len(visited)==n,(name,"disconnected shell")
    low=[min(p[j] for p in verts) for j in range(3)];high=[max(p[j] for p in verts) for j in range(3)]
    assert abs(low[2])<1e-5 and volume>0
    reports[name]={"triangles":n,"watertight":True,"consistent_winding":True,"connected_shells":1,
                   "bounds_mm":[low,high],"volume_mm3":round(volume,3)}
seat=cfg["seat_height_mm"]+cfg["measured_module_mm"]["pcb_thickness"]+cfg["pcb_vertical_clearance_mm"]
assert abs(reports["hw398-base"]["bounds_mm"][1][2]-seat)<1e-5
top=cfg["seat_height_mm"]+cfg["measured_module_mm"]["total_height"]+cfg["usb_roof_clearance_mm"]+cfg["cap_thickness_mm"]
assert abs(reports["hw398-retainer"]["bounds_mm"][1][2]-(top-seat))<1e-5
half=cfg["measured_module_mm"]["width"]/2+cfg["pocket_clearance_per_side_mm"]+cfg["wall_mm"]
front=-cfg["pocket_clearance_per_side_mm"]-cfg["front_wall_mm"]
rear=cfg["measured_module_mm"]["length"]+cfg["pocket_clearance_per_side_mm"]+cfg["rear_wall_mm"]
lo=[min(-half,*[p[0]-cfg["ear_radius_mm"] for p in cfg["fasteners_local_mm"]]),
    min(front,*[p[1]-cfg["ear_radius_mm"] for p in cfg["fasteners_local_mm"]])]
hi=[max(half,*[p[0]+cfg["ear_radius_mm"] for p in cfg["fasteners_local_mm"]]),
    max(rear,*[p[1]+cfg["ear_radius_mm"] for p in cfg["fasteners_local_mm"]])]
for name in ("hw398-base","hw398-retainer"):
    for got,want in zip(reports[name]["bounds_mm"],(lo,hi)):
        assert all(abs(got[i]-want[i])<1e-5 for i in range(2)),(name,"XY envelope mismatch")
ligament=min(abs(p[0])-cfg["measured_module_mm"]["width"]/2-
             cfg["pocket_clearance_per_side_mm"]-cfg["printed_hole_diameter_mm"]/2
             for p in cfg["fasteners_local_mm"])
assert ligament>=1.39
# Nominal plain nut, two washers and 1.6 mm carrier; actual hardware must be checked.
projection=cfg["screw_length_mm"]-(top+.3+1.6+.3+1.6)
assert 0.3 <= projection <= 1.0
report={"status":"FIT-TEST GEOMETRY ONLY; no physical print/load/thermal test",
        "revision":cfg["revision"],"meshes":reports,
        "geometry_checks":{"plastic_height_above_carrier_mm":round(top,3),
          "side_rail_cross_section_mm":[cfg["wall_mm"],round(top-seat,3)],
          "minimum_hole_to_pocket_ligament_mm":round(ligament,3),
          "nominal_thread_beyond_plain_nut_mm":round(projection,3),
          "nominal_screw_head_height_above_carrier_mm":round(top+.3+1.6,3)}}
(root/"verification/cradle-meshes.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
