#!/usr/bin/env python3
"""Apply the shared HW398-C2 interface to the existing unrouted board only.

The electrical schematic, net assignments, board outline and WT32 holes are preserved.
Run with KiCad's Python. Source/interface edits use apply_patch; this is a CAD generator.
"""
import pcbnew as pcb
from hw398_geometry import ROOT, MECH, update_board, scad_constants, holes

path=ROOT/"pitclaw-carrier.kicad_pcb"
b=pcb.LoadBoard(str(path))
before={(f.GetReference(),p.GetNumber()):p.GetNetname() for f in b.GetFootprints() for p in f.Pads() if p.GetNumber()}
update_board(b)
after={(f.GetReference(),p.GetNumber()):p.GetNetname() for f in b.GetFootprints() for p in f.Pads() if p.GetNumber()}
assert before==after,"Electrical net assignment changed"
pcb.SaveBoard(str(path),b)
(MECH/"interface.scad").write_text(scad_constants())
print("Added HW398 cradle interface, holes:",holes(),"; electrical nets unchanged")
