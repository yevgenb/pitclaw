# Carrier simplification review

2026-09-05. B-M1S1 Mini100 / MG90S prototype.

The buzzer driver simplification is implemented. F2 may be removable
after checking converter fault behavior and branch wiring. The servo PTC needs
load-based selection, not automatic deletion or uprating. The blower level
shifter and probe filters have distinct functions and should stay.

**Implemented in B-M1S1:** Q3, R7 and R19 are removed. R6 is now 330 ohm and
GPIO14 directly drives BZ1 at 4 kHz. F1–F4 remain unchanged. No hardware tests
were run, so piezo audibility and all protection ratings remain bench checks.

## Buzzer: simplified in B-M1S1

CPT-1255C-090 is a passive piezo, not an unknown magnetic or active buzzer.
The manufacturer specifies 70 dB minimum at 10 cm with a 3 V peak-to-peak,
4 kHz square wave, and 8.4–15.6 nF capacitance. That supports trying direct
3.3 V logic drive, but does not establish useful outdoor/enclosed audibility.
[Same Sky datasheet](https://www.sameskydevices.com/product/resource/cpt-1255c-090.pdf)

Applied: `GPIO14 → 330 ohm → piezo → GND`.

Q3, R7 and R19 are removed; R6 is the series resistor. That means three
fewer populated parts and no extra GPIO. Do not leave the piezo connected to
5 V when bypassing Q3. Drive both levels actively at about 4 kHz, holding low
when off. The resistor bounds an ideal 3.3 V capacitive-step current to 10 mA;
the maximum specified capacitance gives a 5.1 us RC time constant versus a
125 us half-cycle. These are first-order checks, not a resonance/acoustic
simulation. Verify the actual waveform and pin excursions. Espressif's DC-current
figures depend on drive strength and output voltage; they are not universal
absolute-current limits. [ESP32-S3 datasheet](https://www.espressif.com/sites/default/files/documentation/esp32-s3_datasheet_en.pdf)

If insufficiently audible, a later revision can restore the 5 V driver. **R19 is
useful only in that transistor circuit** because it discharges the piezo while
Q3 is off. It is unnecessary when GPIO14 actively drives both levels. Firmware
now sets `ALARM_BUZZER_FREQ` to **4000** in `firmware/src/config.h`.

## Fuses: distinct intended fault coverage

| Part | Assessment and recommendation |
|---|---|
| F1, input 2 A hold | Keep main input protection. Verify source fault current, trip coordination and downstream ratings. |
| F2, WT32 0.75 A hold | Best removal candidate after verifying the buck, traces and harness remain adequately protected. Keep JP1 regardless. |
| F3, servo 0.5 A hold | External cable protection has a purpose, but this provisional value may sag or trip during loaded MG90S movement. Select from measured load, ambient and cable limits. |
| F4, blower 0.5 A hold | The external branch may have a lower safe current than the whole input. Keep provision; check actual blower current and drop. |

MF-R050 initial resistance can reach 0.77 ohm at 23 C. An **illustrative**
0.5 A load then loses 0.385 V before cable/contact loss or self-heating. This
is not a measured MG90S current. Hold current falls to 0.32 A at 60 C.
MF-R075 initial resistance can reach 0.40 ohm. PTCs are not fast or precise
current limits and do not guarantee semiconductor or servo-stall protection.
[Bourns MF-R datasheet](https://bourns.com/docs/product-datasheets/mf-r.pdf)

One upstream fuse does not reliably cover every branch: a buck can deliver
more current at 5 V than it draws at 12 V, and limiting may prevent F1 from
tripping. Conversely, a branch PTC may not isolate a fault before WT32 resets.
Mini100's advertised short-circuit feature does not establish safe coordination.
A lower-resistance conventional fuse is another option if measured PTC drop is
excessive, but needs a new time/current selection and holder. Neither fuse type
is output overvoltage protection for a buck that fails input-to-output short.

## Other components

| Elements | Finding |
|---|---|
| Q2/Q1 blower stage | Keep. Q2 translates 3.3 V logic to the 12 V P-channel gate. A low-side switch would disturb the shared fan/servo ground. Q1 is oversized in current rating, but a cheaper replacement also needs gate-charge, loss and THT-package checks. |
| R1 1 k gate pull-up | About 0.144 W at continuous fan-on. Increasing it slows turn-off. Firmware requests 25 kHz PWM: scope gate/drain and check Q1 temperature before accepting switching loss or changing R1. |
| R17/R18 pull-ups | Already DNP when the ADC has suitable pull-ups. Optional pads add no purchased parts. |
| Probe RC filters / AIN3 rail measurement | Keep for long probe leads and nearby switching loads. [ADS1115](https://www.ti.com/product/ADS1115) has an internal conversion reference, separate from probe excitation. |
| 0.1% probe-bias resistors | Ordinary 1% parts could be used with measured per-channel calibration and firmware support. Firmware currently has one shared reference-resistance constant; do not substitute silently. |
| C1/C3/C5 bulk capacitors | Module capacitors do not automatically replace local storage. Values remain subject to transient/startup tests, not removal merely because capacitors also exist on the modules. |
| D1 TVS / D2 fan clamp | Keep pending measured transients. These do not protect against a deliberately wrong sustained PD voltage. |
| JP1 power isolation | Keep to avoid unverified paralleling of WT32 programming USB and carrier 5 V. |
| Separate 3.3 V LDO | Already omitted; no further saving here. DEBUG-powered ADC still needs its loaded-rail test. |

Recommended sequence: bench-test direct-drive piezo audibility, then measure
WT32/MG90S rail drop and assess F2/F3. The $21.55 B-M1S1 order is $0.38 below
B-M1. The removed R19 footprint does not reduce this one-board purchase because
the ten-piece 1 k price break remains cheaper than buying five singles.
Shipping, tax, PCB, printing, wire and mounting hardware remain excluded.
