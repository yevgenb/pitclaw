# Pit Claw hardware review and prototype plan

For the newer, through-hole **PCB replica** (with plug-in modules), see
[Rev B KiCad engineering draft](../hardware/carrier-revb/README.md).
That design is separate from the perfboard plan below and is not yet fabrication-ready.

Status: Rev A.2 connector-first design for a hand-wired prototype carrier.
50 x 70 mm remains a candidate size, not a verified full-component fit. Connector
bodies are allocated, but adapters, individual passives, mounting holes and
enclosure clearances are not released for fabrication. This is not a production PCB.

The proposed prototype uses the existing WT32-SC01 Plus, ADS1115 breakout,
USB-C PD/QC trigger module, one adjustable step-down module, and a
HeaterMeter-compatible RJ45 blower/damper connector. The design is intentionally
modular so each power rail and load can be tested before the next one is fitted.

See also:

- [Electrical schematic](media/prototype-carrier-schematic.svg)
- [Perfboard placement plan](media/prototype-carrier-layout.svg)
- [Prototype BOM](prototype-bom.csv)
- [Wiring and net list](wiring.md)

## Recommended architecture

```text
USB-C PD charger
    |
    v
12 V PD trigger -- 2 A fuse --+-- high-side fan switch --> RJ45 pin 5
                               |
                               +-- 12 V to 5 V buck --+--> WT32 5 V
                                                      +--> RJ45 pin 3 (servo)

WT32 onboard 3.3 V --> DEBUG pin 2 --> J7 --> ADS1115 + probe dividers

WT32 GPIO12 --> NPN level shift --> P-channel high-side fan MOSFET
WT32 GPIO13 ------------------------------------------> RJ45 pin 6 (servo PWM)
Common ground ----------------------------------------> RJ45 pin 4
```

Use the USB-C trigger in its **12 V** configuration and verify 11.7-12.3 V with
a meter before connecting the carrier. The Amazon listing says an unsupported
request can fall back to a lower voltage. A charger that does not advertise a
12 V PDO can therefore produce 9 V even though the trigger is set to 12 V.

The step-down module is used only for the 5 V system rail. It must accept 12 V
input and provide at least 2 A continuous with 3 A transient capability. Adjust
it to 5.00 V with no carrier load before fitting the output jumper.

If the source cannot negotiate 12 V, do not set the trigger to 15 or 20 V and
feed that directly to the blower. That alternative requires two regulators: a
regulated 12 V rail for the blower and a separate 5 V rail.

## Review findings

### Must fix before powered testing

1. **The documented fan circuit is wired incorrectly.** The existing diagram
   places the 12 V rail at the IRLZ44N drain and describes the fan ground at its
   source. A valid N-channel low-side switch is `12 V -> fan -> drain`, with the
   source at ground.

2. **A low-side fan switch is incompatible with the HeaterMeter RJ45 pinout.**
   RJ45 pin 4 is the shared fan and servo ground. Switching it would also move
   the servo reference. The prototype therefore switches blower power on pin 5
   with a P-channel MOSFET while leaving pin 4 continuously grounded.

3. **Use the separate DEBUG connector for 3.3 V, not EXT.** EXT has only
   5 V, GND, and GPIO10/11/12/13/14/21. DEBUG pin 2 connects to the onboard
   3.3 V rail in the published schematic; pin 7 is GND. Use these through J7
   for the ADS1115, probe dividers, and I2C pull-ups. The carrier LDO U3 and its
   input capacitor C6 are omitted. This is a prototype engineering choice:
   the manual labels pin 2 "For reference, not for power input" and gives no
   external-load current rating. Never inject an external supply into it;
   verify the actual board revision and loaded rail before accepting this feed.

4. **Probe math does not match the documented divider.** The hardware is a
   10 k pull-up with the probe to ground, so resistance is
   `Rprobe = Rref * raw / (raw_supply - raw)`. The current firmware implements
   the inverse relationship.

5. **The open-probe threshold is unreachable.** At ADS1115 `GAIN_ONE`, 3.3 V is
   about 26,400 counts, not 32,767. The prototype connects AIN3 to the 3.3 V
   excitation rail through 1 k so firmware can use a measured, ratiometric
   `raw_supply`. Treat a channel above roughly 98% of that value as open.

6. **The current build flags conflict with output pins.** `platformio.ini`
   assigns placeholder display signals to GPIO13, GPIO14, and GPIO21 while the
   application assigns those pins to servo, buzzer, and spare. Resolve the real
   WT32 parallel-display configuration before hardware tests; otherwise display
   writes can actuate outputs.

### Reliability changes included in the prototype

- A 2 A input fuse/PTC, 15 V TVS, and 12 V bulk/ceramic decoupling.
- Separate resettable protection for the WT32, servo rail, and blower output.
- A P-channel high-side MOSFET driven through a 2N3904, so GPIO12 never sees
  12 V and the MOSFET receives a defined full gate drive.
- A Schottky clamp at the switched blower output.
- 470 uF on the main 5 V rail and 100 uF close to the RJ45 servo feed.
- 220 ohm series resistance and a 10 k pull-down on the servo PWM line.
- 1 k input protection plus 100 nF filtering on every ADC input.
- Direct GPIO14 drive through 330 ohm for the selected CPT-1255C-090 passive
  piezo. Its 3 Vp-p / 4 kHz rating supports this prototype test; verify audibility
  before treating it as an alarm. Q3, R7 and R19 are removed in Rev B-M1S1.
- Optional 4.7 k I2C pull-up positions, left unpopulated when the ADS1115
  breakout already supplies pull-ups.
- A short DEBUG 3.3 V/GND harness and C7 4.7 uF plus C13 100 nF at the ADC
  supply. This rail powers only the analog front end, not the servo or buzzer.
- A removable WT32 power jumper so the board is not back-powered while USB is
  attached for programming.

### Items that must be characterized on the prototype

- **DEBUG 3.3 V loading and noise.** The ADS1115 IC uses 0.15 mA typical,
  0.30 mA maximum in continuous conversion. Three 10 k probe pull-ups draw
  at most 0.99 mA total, and two 4.7 k I2C pull-ups add up to 1.40 mA when
  both lines are low: about 2.7 mA before breakout LEDs/other circuitry.
  Measure the complete module load; use 5-10 mA as a provisional design budget,
  not a manufacturer rating. Check 3.20-3.40 V at the ADC with Wi-Fi active,
  maximum display brightness, and fan/servo operation. Compare fixed-resistor
  probe readings with these loads idle and active. AIN3 tracking compensates
  slow excitation drift, not every transient between sequential conversions.
  Revisit a separate regulator if rail noise or voltage fails these tests.
- **Two-wire blower PWM frequency.** The firmware uses 25 kHz, a convention for
  a separate control wire on four-wire fans. This RJ45 interface PWM-switches
  the blower supply. Start at full power, then test 20-100 Hz and 490 Hz before
  accepting 25 kHz. Record start duty, minimum stable duty, current, noise, and
  MOSFET temperature. Keep the 75%/500 ms kick-start.
- **5 V peak current.** Measure WT32 Wi-Fi/display peaks and servo stall current
  together. The buck module must hold 4.75-5.25 V at the WT32 connector during a
  commanded servo movement.
- **Servo endpoints.** Begin with conservative pulse limits (for example
  900-2100 us), then expand only until the mechanical damper reaches its stops.
  The existing 544-2400 us limits can drive an installed damper into a hard stop.
- **Probe coefficients.** Verify each probe in a stirred ice bath and at the
  local boiling point. A connector match alone does not guarantee the correct
  NTC curve.

## HeaterMeter RJ45 output

The table is for a straight-through T568B cable. Pin numbers are electrical pin
numbers, not left-to-right positions as viewed from an arbitrary side of a jack.
Continuity-check the exact jack footprint before applying power.

| RJ45 pin | T568B conductor | Pit Claw function |
|---:|---|---|
| 1 | white/orange | No connection |
| 2 | orange | No connection |
| 3 | white/green | Fused +5 V servo supply |
| 4 | blue | Common ground |
| 5 | white/blue | PWM-switched +12 V blower supply |
| 6 | green | Servo PWM signal |
| 7 | white/brown | No connection |
| 8 | brown | No connection |

Place a durable `12 V CONTROL - NOT ETHERNET` label next to the jack. Do not
connect the prototype or its blower cable to Ethernet equipment.

The selected RJHSE-5080 is rated at 1.5 A per contact. Pin 4 carries the sum of
blower and servo return currents. Check that combined load, including startup
and stall, against the jack and cable ratings before accepting this part. The
provisional F3/F4 values do not by themselves protect that shared contact; do not
infer safe combined current by adding their hold ratings. If the measured load
exceeds the limit, revise protection/load limits or the connector system without
silently changing the existing HeaterMeter cable pinout.

## Board-mounted connector selection

All external sockets are mechanically attached to the carrier. No panel jacks,
barrel-power connector or loose USB-C extension is used. The only intended
off-carrier internal cables are the WT32 EXT and DEBUG harnesses.

| Ref | Selected part | Placement, viewed from component side |
|---|---|---|
| J2 | Amphenol RJHSE-5080, right-angle 8P8C, no magnetics or LEDs | Bottom-left edge, opening downward |
| U1 | Existing Amazon B0D5QRDLQV PD trigger, using its installed USB-C socket | Bottom-right edge, socket downward; module positively clamped to carrier |
| J4 | Same Sky MJ1-2503A, 2.5 mm mono through-hole jack | Right edge, PIT |
| J5 | Same Sky MJ1-2503A | Right edge, MEAT 1 |
| J6 | Same Sky MJ1-2503A | Right edge, MEAT 2 |

The [MJ1-2503A drawing](https://www.sameskydevices.com/product/resource/mj1-2503a.pdf)
specifies an 8 mm plastic-body depth, 5.1 mm width/height, and 3 mm projecting
barrel. Its pin 1 is sleeve; pins 2 and 3 are tip contacts, both wired to that
channel's probe node. It is a mono jack despite having three solder terminals.
Verify continuity with the actual probe plug before connecting the ADC.

The [RJHSE-5080 drawing](https://cdn.amphenol-cs.com/media/wysiwyg/files/drawing/p-rjhse-5080.pdf)
gives a nominal housing 15.75 mm wide, 14.99 mm deep and 13.21 mm high. Use the
exact part drawing to map numbered contacts, not a generic RJ45 footprint.
The trigger listing claims 23 x 11.5 x 4 mm; measure the actual module including
its socket, solder joints and clamp before freezing its envelope. Its USB-C is
PD power input only, not a connection to the WT32 USB data/programming port.

### Placement coordinates, not drill coordinates

Origin is the carrier's top-left corner, x to the right, y downward, in mm.
These are nominal body placements from the new drawing, not perfboard holes.

| Item | Body x range | Body y range | Mating direction |
|---|---|---|---|
| J2 housing | 3 to 18.75 | 55.01 to 70 | Down |
| U1 module, provisional | 35 to 46.5 | 47 to 70 | Down |
| J4 plastic body | 42 to 50 | 9.45 to 14.55 | Right, axis y=12 |
| J5 plastic body | 42 to 50 | 21.45 to 26.55 | Right, axis y=24 |
| J6 plastic body | 42 to 50 | 33.45 to 38.55 | Right, axis y=36 |

Probe barrels extend to x=53. Allow space for the actual molded plugs and finger
access outside this outline; the 12 mm jack-axis spacing is a starting point.
Verify RJ45 latch access with the real cable boot and check USB plug-body access.
Keep existing connector retention features and add carrier/case support near the
ports so insertion loads do not depend on signal-pin solder joints alone.

### Perfboard compatibility and case changes

These jacks are common PCB parts, but neither footprint is a drop-in 2.54 mm
grid part. Use accurately drilled, locally cleared perfboard areas with insulated
point-to-point wiring, or small secured adapter PCBs that remain attached to the
carrier. Adapters add area/height and require another fit check. Do not bend all
terminals to force the parts into the grid. Use the manufacturer slot/locating-hole
dimensions when preparing mounting templates; do not drill from the SVG dots.

The trigger also needs an insulated support and a positive clamp to the carrier;
two output wires alone are not a mounting method. Do not drill an unverified
module PCB or rely on adhesive alone to withstand plugging/unplugging.

The current enclosure is incompatible with these port positions. Its 64.5 x
96.5 mm nominal cavity, centered 50 x 70 mm carrier and +4 mm carrier y-offset
leave about 7.25 mm at the right side and 17.25 mm at the bottom wall. It needs
repositioned carrier mounts, new RJ45/USB-C openings, and right-side probe
openings. Account for the 2.5 mm wall, connector overhang, plug shoulders,
standoffs and snap rim in 3D before setting those positions. Existing SCAD/STL
files were left unchanged pending that mechanical fit check.

## Perfboard construction plan

The layout drawing keeps power circuitry left, the ADC/probe front end toward
the right, and the internal WT32 headers at the top. Solid connector bodies use
documented nominal dimensions; dashed interior zones are preliminary. In
particular, the protection/bulk-capacitor zone has not been individually packed.
Measure all parts, adapter footprints and heights before confirming 50 x 70 mm.
If they do not fit with safe wiring and mechanical support, enlarge the carrier
and revise the enclosure rather than overlapping parts in the drawing.

Keep the blower/RJ45 and buck/servo high-current returns separate until the
negative terminal of the 470 uF 12 V capacitor. Run the WT32 power return
separately from servo current. Keep ADS1115/probe grounds local, returning
alongside the 3.3 V feed to WT32 DEBUG pin 7 through J7. All grounds are common
through the WT32 EXT power ground, but motor current must not flow through the
DEBUG cable or probe ground wiring. Avoid an additional analog-to-C1 return
that would put the DEBUG ground cable in parallel with a power return.

Do not route the switched fan node beneath the ADS1115 or probe wiring. Keep
jack-to-filter runs short and beside analog ground. Keep the buck inductor and
blower current paths on the power side; verify probe noise after final placement.

Power paths should be 20-22 AWG wire or solder-reinforced copper bus. Logic and
probe wiring may be 26-28 AWG. Socket the ADS1115. Use insulated internal output
links for U1 at J1 and a removable mechanical clamp; connector mounting must not
depend on those electrical links. U2 may use appropriately rated internal headers.

## Assembly and bring-up

1. First dry-fit the selected connectors, actual plugs, modules and supports.
   Confirm the component and enclosure clearances before soldering. With no
   semiconductors or modules electrically fitted, check every rail for shorts to
   ground and verify RJ45 pin numbers by continuity.
2. Configure the trigger for 12 V. Connect a current-limited PD source or add an
   inline 0.5 A fuse for first power. Verify polarity and 11.7-12.3 V after F1.
3. Fit the TVS and capacitors. Confirm the source remains at 12 V.
4. Fit the 5 V buck with its output jumper open. Adjust it to 5.00 V, then load
   it with 10 ohms/5 W for several minutes. It should remain regulated.
5. With J7 and the blower/servo disconnected, power the WT32 through JP1.
   Verify boot, touch, Wi-Fi, and the voltage on every GPIO output. Meter-check
   DEBUG pin 2 against pin 7: 3.20-3.40 V; identify pin 1 by the actual board
   markings, not cable colors or an assumed viewing direction.
6. Switch off before fitting J7, the ADS1115, and local C7/C13 decoupling.
   Power up and measure the complete analog-rail current and voltage. Verify
   I2C discovery and that pull-ups go only to +3V3_A. Repeat with Wi-Fi/display
   activity; verify the same ADC supply when programming via USB with JP1 open.
7. Substitute resistors for probes: 100 k approximates room temperature and
   10 k a hot probe. Validate raw counts and corrected divider math before using
   real probes.
8. Test the buzzer.
9. Connect the RJ45 cable with the servo unplugged at the far end. Verify pin 3
   is 5 V, pin 4 is ground, pin 5 is off at 0%, and pin 6 has servo pulses.
10. Test the blower alone at 100%, then characterize lower settings and PWM
    frequency. Stop if Q1 exceeds about 60 C, the 12 V rail collapses, or the PD
    source repeatedly renegotiates.
11. Connect the servo and test conservative endpoints. Command repeated moves
    while watching 5 V at the WT32 connector for brownouts.
12. Run a four-hour soak with a simulated probe and normal fan/servo cycles
    before installing the controller on a live cooker.

## Acceptance criteria for revision B

- No exposed net exceeds its component rating and no ESP32 pin exceeds 3.3 V.
- The controller survives fan stall, servo stall, blower unplug/replug, and a
  USB-C source reconnect without rebooting or overheating.
- 5 V stays within 4.75-5.25 V and 3.3 V stays within 3.20-3.40 V at worst case.
- Probe readings remain within the chosen accuracy target while fan and servo
  switch continuously.
- Blower duty is monotonic and repeatable, and 0% always turns the fan off.
- The RJ45 cable passes an end-to-end continuity/pinout test.
- Final enclosure measurements include accessible USB-C power and RJ45 openings;
  all three probes use right-side board-mounted jacks. The current shell has not
  been revised for these ports.

## Open measurement

`Mini100` does not identify a unique converter in available documentation. Before
freezing the placement or current rating, record the module's part number, input
range, sustained output rating, exact length/width/height, pad order, and mounting
hole locations. The layout reserves 24 x 19 mm for the buck; revise it if the
actual module is larger (shown rotated to 19 x 24 mm in Rev A.2). Also record the
ADS breakout, capacitor and TO-220 heights, and connector adapter dimensions.

## Reference documents

- [Same Sky MJ1-2503A](https://www.sameskydevices.com/product/interconnect/connectors/audio-connectors/jacks/mj1-2503a)
  for the selected mono PCB probe jack.
- [Amphenol RJHSE-5080](https://www.amphenol-cs.com/product/rjhse5080.html)
  for the selected right-angle RJ45 jack.
- [Amphenol RJHSE electrical specification](https://cdn.amphenol-cs.com/media/wysiwyg/files/documentation/s6032c_rjhse.pdf)
  for the 1.5 A per-contact limit.
- [HeaterMeter blower and servo wiring](https://github.com/CapnBry/HeaterMeter/wiki/Blower-and-Servo-Wiring)
  for the RJ45 pinout and shared ground.
- [RIOT OS WT32-SC01 Plus board definition](https://doxygen.riot-os.org/group__boards__esp32s3__wt32__sc01__plus.html)
  for the EXT connector pins and on-board display/touch assignments.
- [Wireless-Tag WT32-SC01 Plus datasheet](https://www.tme.eu/Document/e40e2e0db8f76604c11099fc1b945dc2/WT32-SC01.pdf)
  for DEBUG pin numbering and the reference/not-power-input restriction.
- [Manufacturer V1.3 datasheet, mirrored on GitHub](https://github.com/janick/WT32-SqLn/blob/main/docs/WT32-SC01-Plus-V1.3-EN.pdf)
  page 8 schematic shows DEBUG pin 2 directly on the onboard +3V3 regulator rail.
- [TI ADS1115 datasheet](https://www.ti.com/lit/ds/symlink/ads1115.pdf) for
  supply, absolute input voltage, gain, and conversion limits.
- [onsemi FQP27P06 datasheet](https://www.onsemi.com/download/data-sheet/pdf/fqp27p06-d.pdf)
  for Q1 voltage, on-resistance, gate charge, and TO-220 pinout.
- [USB-C trigger product listing](https://www.amazon.com/dp/B0D5QRDLQV) for
  selectable voltages, dimensions, and fallback behavior claimed by the seller.
