# Prototype carrier wiring

This page describes the perfboard circuit. The newer
[Rev B PCB draft](../hardware/carrier-revb/README.md) documents its fixed-regulator,
through-hole component and module-footprint differences.

This wiring is for the reviewed USB-C-powered, HeaterMeter-RJ45-compatible
prototype. The design rationale, risks, and bring-up sequence are in
[hardware-review.md](hardware-review.md).

![Prototype carrier schematic](media/prototype-carrier-schematic.svg)

## External connectors mounted on the carrier

- J2: Amphenol RJHSE-5080 at the bottom-left edge, opening downward.
- U1: the existing PD trigger is clamped to the bottom-right edge, using its
  installed USB-C socket. J1 is only its internal output-pad connection.
- J4/J5/J6: Same Sky MJ1-2503A 2.5 mm mono PCB jacks on the right edge,
  respectively PIT, MEAT 1 and MEAT 2 from top to bottom.

There are no external panel-jack wire pairs. These through-hole jacks do not
match an ordinary 2.54 mm grid: use properly drilled/cleared areas or secured
adapters. See the [mechanical plan](hardware-review.md#board-mounted-connector-selection).
The trigger USB-C accepts PD power only; it does not expose the WT32 USB data port.

## WT32-SC01 Plus EXT connector

| EXT pin | Net | Carrier connection |
|---:|---|---|
| 1 | +5V_WT32 | From F2 through removable jumper JP1 |
| 2 | GND | Common ground |
| 3 | GPIO10 | ADS1115 SDA |
| 4 | GPIO11 | ADS1115 SCL |
| 5 | GPIO12 | R2, then Q2 base: blower command |
| 6 | GPIO13 | R4, then RJ45 pin 6: servo signal |
| 7 | GPIO14 | R6 330 ohm, then passive piezo BZ1 |
| 8 | GPIO21 | Labeled spare test point; no connection |

There is no 3.3 V pin on EXT. Use the separate DEBUG connector as described below.

Never fit JP1 while the WT32 USB port and the external 5 V supply are both
connected unless the exact WT32 power-path schematic has been verified to allow
it.

## WT32 DEBUG analog-power connection

| WT32 DEBUG pin | Carrier J7 pin | Connection |
|---:|---:|---|
| 2 | 1 | +3V3_A: ADS1115 supply, probe excitation, I2C pull-ups |
| 7 | 2 | Analog GND; common with WT32 GND |

J7 is a two-pin carrier header, fed by a mating 7-pin MX1.25 DEBUG harness.
Leave DEBUG pins 1 and 3-6 unconnected in this power harness. Verify connector
orientation and continuity rather than trusting wire colors. Never connect an
external 3.3 V supply to J7 while it is connected to the WT32.

The published schematic connects DEBUG pin 2 directly to the onboard 3.3 V
rail, but the manual calls it a reference pin and does not specify an external
current budget. This low-current prototype use requires a loaded-voltage/noise
test; see the [review](hardware-review.md). U3 and C6 are omitted. Keep C7
(now 4.7 uF) and C13 (100 nF) across the ADC supply, with C13 closest to VDD.
Power down before plugging/unplugging J7 or the ADC. With JP1 open during USB
programming, the WT32 still supplies the ADC through DEBUG; no separate analog
supply is needed. Keep motor currents out of this harness and analog ground.

## Power nets

```text
PD trigger OUT+ -> F1 -> +12V
PD trigger OUT- -------> GND

+12V -> C1 470uF/25V -> GND
+12V -> C2 100nF      -> GND
+12V -> D1 SMBJ15A    -> GND  (TVS cathode to +12V)

+12V -> U2 IN+
GND  -> U2 IN-
U2 OUT+ (adjusted to 5.00V) -> +5V
U2 OUT- -------------------> GND

+5V -> F2 -> JP1 -> WT32 EXT pin 1
+5V -> F3 -> +5V_SERVO -> RJ45 pin 3
WT32 DEBUG pin 2 -> J7 pin 1 -> +3V3_A
WT32 DEBUG pin 7 -> J7 pin 2 -> analog GND
+3V3_A -> C7 4.7uF -> analog GND
+3V3_A -> C13 100nF -> analog GND
```

Check the exact U2 pad order from its markings. Names such as
`Mini100` are not sufficient to determine a pinout.

## RJ45 high-side blower driver

```text
                              Q1 FQP27P06 (P-channel)
                +12V ------- S
                  |           D ---- F4 ---- RJ45 pin 5 (blower +)
                  +-- R1 1k --G
                                \
                                 C  Q2 2N3904
WT32 GPIO12 -- R2 2.2k ----------B
                                 E
                                 |
                                GND ---------------- RJ45 pin 4

R3 100k: Q2 base to GND
D2 1N5819: anode GND, cathode at RJ45 pin 5 side of F4
```

With this circuit GPIO12 high turns the blower on. Q2 keeps 12 V away from the
ESP32 and pulls Q1's gate low. R1 turns Q1 off during reset.

Do not substitute an N-channel MOSFET in the Q1 position. Do not use the old
IRLZ44N low-side circuit with the shared-ground RJ45 connection.

## Servo and buzzer

```text
+5V -> F3 -> +5V_SERVO -------------------------> RJ45 pin 3
                          |-- C5 100uF --> GND

GPIO13 -> R4 220R -> SERVO_SIG -----------------> RJ45 pin 6
                         |-- R5 10k --> GND

GPIO14 -> R6 330R -> BZ1 pin 1
BZ1 pin 2 ----------> GND
```

Drive GPIO14 at approximately 4 kHz and hold it low when the tone is off. Q3,
R7, R19 and D3 are not fitted in Rev B-M1S1. This direct circuit is only for the
selected passive piezo; do not substitute a magnetic or active 5 V buzzer.

## Probe channels and ADS1115

Power the ADS1115 breakout from DEBUG-derived +3V3_A for direct 3.3 V I2C.
Using a 5 V ADC supply would require level translation; do not use it here.
Confirm SDA and SCL pull-ups connect only to +3V3_A. Most breakout boards
already contain I2C pull-ups; fit
R17/R18 (4.7 k to +3V3_A) only if the actual board has none.

Each probe channel is identical:

```text
+3V3_A -> R10 10k 0.1% -> PROBE1_NODE -> J4 pins 2 and 3 (tip)
J4 pin 1 (sleeve) -------------------------------> analog GND

PROBE1_NODE -> R13 1k -> ADS AIN0
ADS AIN0 ----------------> C10 100nF -> GND
```

Use J5/R11/R14/C11/AIN1 for Meat 1 and J6/R12/R15/C12/AIN2 for Meat 2.
For the selected MJ1-2503A, pins 2 and 3 are both tip contacts, not a switch or a
separate ring signal. Connect both to the channel's node and pin 1 to analog GND.
Verify the physical pin numbering and contact continuity with an inserted probe.

Connect AIN3 through R16 1 k to +3V3_A. Firmware should read this channel as
`raw_supply` and calculate:

```text
Rprobe = 10000 * raw_probe / (raw_supply - raw_probe)
open    = raw_probe >= 0.98 * raw_supply
short   = raw_probe <= characterized_short_threshold
```

The 100 nF filter capacitors belong beside the ADS1115 pins. Keep the PCB-jack
signal runs short and away from the fan-power and buck switching paths.

## HeaterMeter RJ45 pinout

| Pin | T568B wire | Connection |
|---:|---|---|
| 1 | white/orange | No connection |
| 2 | orange | No connection |
| 3 | white/green | +5V_SERVO |
| 4 | blue | GND |
| 5 | white/blue | switched/fused blower +12 V |
| 6 | green | SERVO_SIG |
| 7 | white/brown | No connection |
| 8 | brown | No connection |

Check pin numbers from the jack datasheet and then confirm them with a meter
through the actual cable. RJ45 physical left/right order changes with plug/jack
orientation and whether contacts or solder pins are facing the viewer.

RJHSE-5080 is rated at 1.5 A per contact. Pin 4 is the shared blower-plus-servo
return, so validate combined current and cable limits, not just each load alone.

## Physical placement

![50 x 70 mm perfboard placement plan](media/prototype-carrier-layout.svg)

The drawing allocates individual connector bodies and their mating directions.
It is not a pin-level drill template or a verified full-component packing plan.
Measure the actual modules, supports, adapters and plugged-in connectors before
drilling or cutting. Existing enclosure mounts and cutouts require revision.
