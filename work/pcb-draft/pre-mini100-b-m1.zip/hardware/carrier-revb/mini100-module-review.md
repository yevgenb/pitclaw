# Existing Mini100 converter — listing review, 2026-09-04

Selected by the user: Weewooday, Amazon ASIN **B08JZ5FVLC**. This identifies the
listing, not a controlled manufacturer part number or a verified batch revision.

## Seller evidence

The [listing and seller photographs](https://www.amazon.com/dp/B08JZ5FVLC/)
describe a **20 × 11 × 5 mm** board with **2.54 mm** solder-hole pitch.
Looking at the component side with the pad row on the left, its top-to-bottom
labels are **EN, IN+, GND, VO+**. The underside view reverses that orientation.
Photographs show adjustable output with a cut-ADJ / solder-5V fixed-output option.

The advertised 3 A maximum requires additional cooling; the seller reports a
12 V input / 1.5 A output test without it. This is not a guaranteed continuous
rating in our enclosure. Input claims conflict: 4.5–12 V versus 4.5–24 V.
The description claims short-circuit protection but warns against sustained
shorts; it lists no output overvoltage protection. EN is described as default-on.

## Design decision

Retain this converter as the **prototype candidate** for the 5 V WT32/MG90S rail.
Do not attribute the superseded Traco's ratings or capacitor limit to it. The
blower remains on the separate 12 V path; it is not a load on this converter.

Proposed carrier connection: a four-position 2.54 mm through-hole header/socket
interface, with the module parallel to the carrier, components outward, and an
insulating support under its free end. This is a mounting proposal, not an
already-created footprint or validated current-rated connector selection.
Provide positive retention for transport; do not rely on a cantilevered socket
or an adhesive pad alone. Keep conductive hardware and carrier copper clear of
the exposed underside pads. Preserve access to the voltage-setting pads before
final assembly and leave ventilation around the switching parts.

EN should remain unconnected for the proposed always-on use after confirming
the actual module's behavior. Do not tie it to 12 V. Check the physical labels
before assigning KiCad pin numbers; the label order above is orientation-specific.

The listing does not dimension pad-center-to-edge offsets, hole diameters, PCB
thickness or underside protrusions. Verify these on the actual unit before
freezing a direct plug-in footprint/support. No mounting holes are assumed or
to be drilled into the module. A short-wire interface remains a fallback if its
holes do not accept the chosen header.

## Bring-up and protection

1. With the carrier and loads disconnected, verify the trigger's actual 12 V
   output. Identify and check converter polarity from its own silkscreen.
2. Set the converter to 5 V while unloaded, power-cycle, and measure again before
   attaching WT32 or MG90S. Any fixed-output modification is done unpowered and
   only after confirming the actual board matches the seller's instructions.
3. Use a current-limited bench supply and dummy load first. Check regulation,
   startup, temperature and recovery at the intended load. Avoid sustained shorts.
4. Test WT32 boot/Wi-Fi/backlight together with representative loaded servo
   movement. Scope the 5 V rail at WT32 and at the servo, including PTC and harness
   voltage drop. Do not accept a no-load multimeter reading as a transient test.
5. Repeat in the intended stack/enclosure at the expected ambient temperature.
   Stop on overheating, voltage excursions or resets; do not solve failures by
   blindly increasing fuse ratings or capacitance.

**Keep F1–F4 unchanged pending testing.** An advertised short-circuit feature is
not enough to justify deleting F2; the available information does not establish
safe fault coordination. F3's provisional 0.5 A hold value still needs evaluation
with the MG90S. Neither a PTC nor the input TVS is output overvoltage protection.

## Artifact status

This review updates the requirements only. Native CAD, previews, selection.json,
XLSX and CSV remain the explicitly superseded Traco B-DK1 snapshot. No footprint,
fuse, routing, printed cradle or purchasing file was changed in this review.
Replace U2 and its interface in CAD and BOM together after the physical interface
is confirmed, then rerun connectivity, ERC, DRC and mechanical checks. Do not
order the current draft or fit this module to the Traco SIP-3 footprint.
