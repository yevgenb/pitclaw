# DigiKey prototype BOM — Rev B-DK1

**Superseded U2 selection:** the user now wants to reuse the existing Mini100.
Do not buy Traco U2. The XLSX, CSV and selection.json remain the historical
B-DK1 snapshot until the Mini100's physical header/support interface is confirmed.
The user has supplied the exact listing; see the [module review](../mini100-module-review.md).
Additional interface parts and any protection changes are not yet costed.
See [pending design decisions](../pending-design-decisions.md). No fuses have
been removed or uprated.

US public pricing checked 2026-09-04, USD. The previous one-carrier order was
**$27.95**, before shipping, tax or tariff. It includes $26.99 of carrier parts
and $0.96 of harness housings/contacts and the JP1 shunt. This is **not the total
cost of a complete controller**. No cart or order has been submitted.

The workbook contains the order, part/footprint details with source URLs and
price breaks, and unpriced external/mechanical items. The CSV is a DigiKey list
import, with manufacturer part number, DigiKey part number, quantity and customer
reference. Verify the imported matches and current prices before checkout.
Quantities are for one prototype, not a five-PCB fabrication pack. R17/R18 are
DNP and excluded from the order. Existing HW398, ADS1115 and WT32 modules are
excluded. Ten 100 nF capacitors and ten 1 kOhm resistors cost $0.22 less than six
of each at the single-piece price; keep the four spares of each.

## Main decisions

| Item | Selected change | Reason / boundary |
|---|---|---|
| U2 | Traco TSR 2-2450N, $6.89 | Retains 5 V / 2 A; $7.31 less than $14.20 RECOM R-78B5.0-2.0 snapshot. New footprint and orientation. |
| J1, J7, J3 | JST-XH, $0.50 for all three carrier headers | Common 2.50 mm THT family. Cable housings and loose contacts are included separately. |
| J4–J6 | Keep Same Sky MJ1-2503A, $0.77 each | No verified DigiKey PJ-210B source found. PJ-210B has a different footprint/contact arrangement and is not interchangeable. |
| C3, C5 | Rubycon 220 uF / D6.3 and 100 uF / D5 | Smaller packages and revised lead pitches, same capacitance and 16 V rating. |
| F1–F4 | Bourns MF-RHT200/32-2, MF-R075, MF-R050 | Exact packages replace generic PTC placeholders. Electrical protection still needs testing. |
| BZ1 | Same Sky CPT-1255C-090, $1.50 | Documented 12 mm body and 5 mm lead pitch. Cheaper CPT-1207-5LTH-T drawing conflicts between 5 and 7.5 mm pitch, so it was rejected. |
| R19 | 1 kOhm across passive piezo | Replaces unused D3 and discharges piezo between Q3 pulses. Approximately 4 kHz PWM required. |
| Q1 | Keep onsemi FQP27P06 | Avoid unqualified lower-cost manufacturer swaps. FQP17P06 saves only $0.57 and raises maximum on-resistance from 70 to 120 milliohm at -10 V. |
| R10–R12 | Keep 10 kOhm 0.1%, 25 ppm/C | Preserve probe-bias accuracy; do not substitute ordinary 1% parts here. |

The regulator comparison is a measured line-item saving, not a claimed full-BOM
percentage: the previous draft did not have exact purchasing parts everywhere.
The unused generic PTC footprint, if present in the library, is obsolete and is
not assigned to any component in this revision.

## Assembly and electrical checks

- U2 pin 1 VIN, 2 GND, 3 OUT. The selected installed KiCad footprint is specific
  to Traco TSR 2-N (14 × 7.6 × 10.2 mm). Do not fit the old RECOM, a 7805 or
  Mini100 in it. Keep routing away from beneath the converter body. The output
  capacitive-load limit is 820 uF; include the WT32 and servo, capacitor tolerance
  and startup behavior. Test rail noise and enclosed temperature.
- JST XH pitch is **2.50 mm**, not 2.54 mm. J1 and J7 use identical 2-pin mates but
  carry 12 V and 3.3 V respectively. Label and secure their harnesses separately;
  never interchange them. They are carrier-side connectors, not direct WT32 mates.
  Eleven loose contacts cover both 2-pin plugs and seven used EXT positions.
  Use properly crimped wire; tools and wire are not included. Select 22 AWG for
  power paths where practical and verify voltage drop in the complete harness.
- F1 hold current is 2 A at 23 C but 1.46 A at 60 C. F3/F4 hold 0.5 A at 23 C
  and 0.32 A at 60 C. PTCs are not hard current limiters. Measure blower startup,
  servo stall, WT32 boot current and RJ45 combined return current before accepting
  the ratings. Do not increase fuses simply to prevent nuisance trips.
- J2's exact RJHSE5080 manufacturer drawing remains a release gate. The currently
  retained pad geometry is provisional. Obtain a connector and verify numbered
  contacts, mounting pegs, edge setback and fit before routing or fabrication.
- MJ1-2503A uses pin 1 sleeve and pins 2/3 tip. Check plated slot fit with actual
  leads. The ADC socket's module-to-header offsets and stacked height also need
  a physical check. The female socket body is 8.51 mm high.
- D1 is transient protection, not protection against a sustained 15/20 V PD
  selection. Measure **12 V** at HW398 before connecting the carrier. Remove
  JP1 before powering WT32 from programming USB. Do not hot-plug ADC/DEBUG.
- The carrier remains all through-hole to assemble; SMD devices stay inside
  preassembled modules/converter. R1 can dissipate approximately 0.144 W and
  needs space for cooling. Q1's drain tab is electrically live.

## Mechanical and excluded items

HW398-C2 base and retainer are unchanged. Nuts remain **under the carrier PCB**.
Use 2 × M2 × 16 mm screws, 4 × M2 washers with OD no greater than 5 mm and
2 × ordinary M2 nuts; provide at least 3 mm rear hardware clearance. Print and
fit-test before ordering the PCB. Carrier mounting needs four unthreaded
insulating spacers and four 2.3–2.5 mm self-tapping screws. Their lengths remain
dependent on the real WT32 stack and must not be guessed. ADC free-edge support,
WT32-end EXT/DEBUG mates, wire, PD charger/cable, probes and blower are outside
this DigiKey order. A charger must offer a suitable 12 V profile.

Only nearby capacitor C2 moves by 0.6 mm in the cradle's shared placement data.
No cradle print dimension, fastener location, mounting hole or keepout changes.

## Evidence and release status

All purchase rows link to DigiKey. Mechanical/electrical selection references:

- [Traco TSR 2-N datasheet](https://www.mouser.com/datasheet/3/1230/1/tsr2n_datasheet.pdf)
- [JST XH manufacturer datasheet](https://cdn-shop.adafruit.com/product-files/4876/JST%20XH%20ds.pdf)
- [Bourns MF-R](https://www.bourns.com/docs/product-datasheets/mfr.pdf) and [MF-RHT](https://www.bourns.com/docs/product-datasheets/mfrht.pdf)
- [Same Sky CPT-1255C-090](https://www.sameskydevices.com/product/resource/cpt-1255c-090.pdf) and [MJ1-2503A](https://www.sameskydevices.com/product/resource/mj1-2503a.pdf)
- [Amphenol RJHSE-x080 exact drawing, still to reconcile visually](https://cdn.amphenol-cs.com/media/wysiwyg/files/drawing/rjhsex080.pdf)

PDF drawing review informed package selection; it did not replace physical fit
testing. The priced spreadsheet distinguishes procurement from complete assembly
requirements and retains source price breaks for auditability.

The native PCB is placed and net-assigned, **unrouted and not for fabrication**.
Do not upload this engineering ZIP to JLCPCB as an order. Complete physical fit,
WT32 antenna/stack checks, load tests, routing, silkscreen and final ERC/DRC before
exporting fabrication files. See the parent README and verification reports.
