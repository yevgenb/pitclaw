#!/usr/bin/env python3
"""Verify the accepted r13 enclosure and its six assembly/calibration coupons.

Run with Python 3 plus trimesh, for example:
  python3 enclosure/fusion-r13/reference/verify_reference.py

The case's production dimensions remain fixed. Only the diagnostic electronics
witnesses vary. This script reads the PCB/project as bytes; it never invokes
KiCad or rewrites manufacturing files. Passing checks establish geometric fit
of the declared envelopes, not physical fit of unmeasured purchased parts.
"""

from __future__ import annotations

import argparse
import concurrent.futures
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parents[3]
SOURCES = (
    "enclosure/fusion-r13/reference/carrier-case.scad",
    "enclosure/fusion-r13/reference/adafruit5807-base.scad",
    "enclosure/fusion-r13/reference/carrier-interface.scad",
    "hardware/carrier-revb/mechanical/enclosure-interface.json",
    "hardware/carrier-revb/pitclaw-carrier.kicad_pcb",
    "hardware/carrier-revb/pitclaw-carrier.kicad_pro",
    "hardware/carrier-revb/verification/drc.json",
)
INPUT_NAMES = (
    "check_pcb_thickness", "check_pd_thickness", "check_pd_spacer_height",
    "check_board_edge_growth", "check_module_shift_x",
)
EMPTY_MESSAGE = "Current top level object is empty."
EXPECTED_SIZE = {
    "shim01":[9,9,.1],"shim02":[9,9,.2],
    "usb_base":[23.32,24.995,4.2],
    "bottom":[86,104,27.6],"top":[86,104,21.9],"retainer":[80,96,2.5],
    "fascia":[72,27.4,9.8],"joint_bottom":[33,30,27.6],
    "joint_top":[33,30,21.9],"joint_fascia":[26,27.4,9.8],
    "coupon":[86,22,27.6],"insert_coupon":[36,16,7.5],"mount_coupon":[16,21,10],
}
MESH_NAMES = {
    "shim01":"display-shim-0.1.stl","shim02":"display-shim-0.2.stl",
    "usb_base":"adafruit5807-base.stl",
    "bottom":"carrier-bottom.stl","top":"carrier-top.stl",
    "retainer":"carrier-retainer.stl","fascia":"probe-fascia.stl",
    "joint_bottom":"joint-coupon-bottom.stl","joint_top":"joint-coupon-top.stl",
    "joint_fascia":"joint-coupon-fascia.stl","coupon":"fit-coupon.stl",
    "insert_coupon":"insert-coupon.stl","mount_coupon":"mount-coupon.stl",
}


@dataclass(frozen=True)
class Check:
    name: str
    part: str
    values: tuple[float, float, float, float, float]

    def as_dict(self):
        return {"name": self.name, "part": self.part,
                "witness_inputs_mm": dict(zip(INPUT_NAMES, self.values))}


def scenarios() -> list[Check]:
    checks = [Check("nominal-" + part, part, (1.6, 1.6, 3, 0, 0)) for part in (
        "insertion-check", "carrier-installation-check", "electronics-closure-check",
        "shell-closure-check", "fascia-fit-check", "fascia-insertion-check", "lid-closing-check", "fascia-lift-check", "mount-screw-check", "mount-tool-check", "shell-closure-with-fascia-check")]
    for part in ("guide-capture-front-check", "guide-capture-early-check",
                 "guide-capture-midfront-check", "guide-capture-middle-check",
                 "guide-capture-rear-check"):
        checks.append(Check(part, part, (1.6,1.6,3,0,0)))
    for part in ("guide-support-front-005-check","guide-support-front-010-check",
                 "guide-support-rear-005-check","guide-support-rear-010-check",
                 "lowered-entry-check"):
        checks.append(Check(part,part,(1.6,1.6,3,0,0)))
    # Use the full edge allowance with each stack/X corner. These are explicit
    # design scenarios, not claims about the tolerances of every purchased part.
    for label, stack in (("low", (1.44, 1.44, 2.9)), ("high", (1.76, 1.76, 3.1))):
        for x in (-0.2, 0.2):
            for part in ("carrier-installation-check", "electronics-closure-check", "fascia-fit-check", "fascia-insertion-check"):
                name = f"{label}-stack-x-{'minus' if x < 0 else 'plus'}-0.2-{part}"
                checks.append(Check(name, part, (*stack, 0.2, x)))
    return checks


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hashes() -> dict[str, str]:
    return {relative: sha256(ROOT / relative) for relative in SOURCES}


def echo_vector(log: str, label: str) -> list[float]:
    match = re.search(r'ECHO:\s*"' + re.escape(label) + r'",\s*(\[[^\]]*\])', log)
    if match is None:
        raise ValueError(f"Required diagnostic echo is missing: {label}")
    return json.loads(match.group(1))


def near_vector(actual, expected, tolerance=0.0001):
    return len(actual) == len(expected) and all(
        abs(float(a) - float(b)) <= tolerance for a, b in zip(actual, expected))


def openscad_command(explicit: str | None) -> list[str]:
    if explicit:
        return [explicit]
    app = Path("/Applications/OpenSCAD.app/Contents/MacOS/OpenSCAD")
    if sys.platform == "darwin" and app.is_file():
        # The installed desktop Qt build requires x86_64 on this host.
        return ["arch", "-x86_64", str(app)]
    executable = shutil.which("openscad")
    if not executable:
        raise RuntimeError("OpenSCAD was not found; provide --openscad PATH")
    return [executable]


def run_check(check: Check, command: list[str], output: Path, timeout: float) -> dict:
    logs = output / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    target = logs / (check.name + "-intersection.stl")
    logfile = logs / (check.name + ".log")
    target.unlink(missing_ok=True)
    args = command + ["-o", str(target), "-D", 'part="' + check.part + '"']
    for variable, value in zip(INPUT_NAMES, check.values):
        args.extend(["-D", f"{variable}={value:g}"])
    args.append(str(Path(__file__).with_name("carrier-case.scad")))
    start = time.monotonic()
    record = check.as_dict()
    record["command"] = args
    try:
        process = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        log = process.stdout + process.stderr
        logfile.write_text(log)
        record.update({"returncode": process.returncode,
                       "log": str(logfile.relative_to(output)),
                       "log_sha256": sha256(logfile)})
        if "WARNING:" in log or "ERROR:" in log:
            raise ValueError("OpenSCAD emitted a warning or error; inspect the complete log")
        # OpenSCAD returns 1 for an intentionally empty top-level object.
        if process.returncode not in (0, 1):
            raise ValueError(f"Unexpected OpenSCAD exit status: {process.returncode}")
        witnessed = echo_vector(log, "FIT_CHECK_INPUTS")
        if not near_vector(witnessed, check.values):
            raise ValueError(f"Witness overrides were not applied: {witnessed}")
        case = echo_vector(log, "DRAFT case W,L,H")
        if not near_vector(case, [86, 104, 44.9]):
            raise ValueError(f"Case dimensions changed with diagnostic witnesses: {case}")
        datums = echo_vector(log, "Seam / retainer underside / glass front")
        if not near_vector(datums, [27.6, 31.9, 43.7]):
            raise ValueError(f"Nominal shell/display datums moved with the witnesses: {datums}")
        contact = echo_vector(log, "Bezel underside / glass gap / outer recess")
        if not near_vector(contact, [43.7, 0, 1.2]):
            raise ValueError(f"Display no longer seats directly beneath the bezel: {contact}")
        if check.part.startswith(("guide-capture-","guide-support-")):
            if not target.is_file() or process.returncode != 0:
                raise ValueError("Guide did not block the required motion")
            import math
            import numpy as np
            import trimesh
            contact=trimesh.load(target,force="mesh",process=True)
            if not (contact.is_watertight and contact.is_winding_consistent):
                raise ValueError("Guide contact witness is not closed and consistently wound")
            support=check.part.startswith("guide-support-")
            if support:
                y=-49.6 if "front" in check.part else -43.5
                depth=.4
                movement=-.05 if "005" in check.part else -.1
                expected=2.7*depth*abs(movement)
            else:
                stations={"guide-capture-front-check":-51.8,
                          "guide-capture-early-check":-50.8,
                          "guide-capture-midfront-check":-49,
                          "guide-capture-middle-check":-47,
                          "guide-capture-rear-check":-44}
                y=stations[check.part];depth=.2;movement=.7
                expected=2.7*depth*(movement-math.sqrt(2)*.4)
            if not (abs(contact.bounds[0][1]-(y-depth/2))<.001 and
                    abs(contact.bounds[1][1]-(y+depth/2))<.001):
                raise ValueError("Guide contact is outside its intended depth station")
            volumes=[]
            for sign in [-1,1]:
                mask=np.all(sign*contact.vertices[contact.faces,0]>0,axis=1)
                side=contact.submesh([mask],append=True,repair=False)
                volume=float(side.volume)
                if not (len(side.faces)>0 and side.is_watertight and volume>0
                        and abs(volume-expected)<.003):
                    raise ValueError("Guide contact does not match the geometry-derived positive volume")
                volumes.append(volume)
            record["contact"]={"station_y_mm":y,"translation_z_mm":movement,
                "slice_depth_mm":depth,"left_right_intersection_mm3":volumes,
                "expected_volume_each_mm3":expected,"volume_tolerance_mm3":.003,
                "witness_sha256":sha256(target),"lid_present":False}
            record["result"]="PASS: both lands support downward motion" if support else "PASS: both guides block upward motion"
        elif EMPTY_MESSAGE in log and not target.exists():
            record["result"] = "PASS: empty intersection"
        elif check.part in ("shell-closure-check","shell-closure-with-fascia-check","insertion-check") and target.is_file() and process.returncode == 0:
            # Some OpenSCAD backends retain the shared meeting-face triangles.
            # Accept only the known shell seam or glass-to-bezel contact plane;
            # zero signed volume alone would not exclude a real collision.
            import numpy as np
            import trimesh

            contact = trimesh.load(target, force="mesh", process=False)
            if not len(contact.vertices) or not len(contact.faces):
                raise ValueError("Unexpected empty shell-contact mesh")
            triangles = contact.triangles
            signed_volume = float(np.einsum("ij,ij->i", triangles[:, 0],
                np.cross(triangles[:, 1], triangles[:, 2])).sum() / 6)
            contact_plane = 43.7 if check.part == "insertion-check" else 27.6
            max_plane_error = float(np.max(np.abs(contact.vertices[:, 2] - contact_plane)))
            thickness = float(contact.bounds[1][2] - contact.bounds[0][2])
            tolerance = 0.00001
            record["intentional_glass_contact" if check.part == "insertion-check" else "intentional_seam_contact"] = {
                "file": str(target.relative_to(output)), "sha256": sha256(target),
                "bounds_mm": contact.bounds.tolist(), "triangles": len(contact.faces),
                "signed_volume_mm3": signed_volume, "z_thickness_mm": thickness,
                "maximum_distance_from_seam_mm": max_plane_error,
                "contact_plane_z_mm": contact_plane, "numeric_tolerance": tolerance,
            }
            if not (np.isfinite(contact.vertices).all() and np.isfinite(signed_volume)
                    and max_plane_error <= tolerance and thickness <= tolerance
                    and abs(signed_volume) <= tolerance):
                raise ValueError("Contact is not confined to the intentional zero-thickness seating plane")
            record["result"] = "PASS: intentional coplanar glass contact" if check.part == "insertion-check" else "PASS: intentional coplanar seam contact"
        else:
            raise ValueError("Collision check did not produce the required empty intersection")
    except subprocess.TimeoutExpired as error:
        stdout = error.stdout or ""
        stderr = error.stderr or ""
        log = (stdout.decode(errors="replace") if isinstance(stdout, bytes) else stdout)
        log += (stderr.decode(errors="replace") if isinstance(stderr, bytes) else stderr)
        log += f"\nVERIFY_CASE_ERROR: exceeded {timeout:g} second timeout\n"
        logfile.write_text(log)
        record.update({"result": "FAIL", "error": "OpenSCAD timeout",
                       "log": str(logfile.relative_to(output)),
                       "log_sha256": sha256(logfile)})
    except (ImportError, OSError, ValueError) as error:
        record.update({"result": "FAIL", "error": str(error)})
    record["elapsed_seconds"] = round(time.monotonic() - start, 2)
    return record


def connected_components(mesh) -> int:
    # Avoid trimesh.split's optional scipy/networkx dependency. Shared vertices
    # join the triangles after trimesh's standard duplicate-vertex merge.
    parents = list(range(len(mesh.vertices)))

    def find(index):
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    used = set()
    for face in mesh.faces:
        a, b, c = (int(i) for i in face)
        used.update((a, b, c))
        parents[find(b)] = find(a)
        parents[find(c)] = find(a)
    return len({find(i) for i in used})


def check_mesh(part: str, path: Path, coupon_components: int) -> dict:
    record = {"file": path.name}
    try:
        import trimesh

        before = sha256(path)
        mesh = trimesh.load(path, force="mesh", process=True)
        components = connected_components(mesh)
        expected_components = coupon_components if part == "coupon" else 1
        record.update({"sha256": before, "connected_components": components,
                       "watertight": bool(mesh.is_watertight),
                       "consistent_winding": bool(mesh.is_winding_consistent),
                       "bounds_mm": mesh.bounds.tolist(),
                       "size_mm": mesh.extents.tolist(),
                       "volume_mm3": round(float(mesh.volume), 3),
                       "triangles": len(mesh.faces)})
        if not (components == expected_components and mesh.is_watertight
                and mesh.is_winding_consistent and mesh.volume > 0):
            raise ValueError("Mesh is not the expected number of closed, consistently oriented solids")
        if abs(float(mesh.bounds[0][2])) > 0.001:
            raise ValueError("Print-oriented mesh does not start at Z=0")
        if part in EXPECTED_SIZE and not near_vector(mesh.extents, EXPECTED_SIZE[part], 0.01):
            raise ValueError(f"Unexpected print dimensions: {mesh.extents.tolist()}")
        if sha256(path) != before:
            raise ValueError("Mesh changed during validation")
        record["result"] = "PASS"
    except (ImportError, OSError, ValueError) as error:
        record.update({"result": "FAIL", "error": str(error)})
    return record


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--openscad", help="Executable path; default uses the installed macOS app via arch -x86_64")
    parser.add_argument("--jobs", type=int, default=3, help="Concurrent OpenSCAD checks (default: 3)")
    parser.add_argument("--timeout", type=float, default=600, help="Seconds allowed for each OpenSCAD process")
    parser.add_argument("--coupon-components", type=int, default=1)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--diagnostics-only", action="store_true")
    mode.add_argument("--meshes-only", action="store_true")
    mode.add_argument("--list-cases", action="store_true", help="Print the scenario matrix without running tools")
    args = parser.parse_args()
    if args.jobs < 1 or args.timeout <= 0 or args.coupon_components < 1:
        parser.error("jobs, timeout, and coupon-components must be positive")
    checks = scenarios()
    if args.list_cases:
        print(json.dumps([check.as_dict() for check in checks], indent=2))
        return 0

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    sources_before = source_hashes()
    report = {
        "status": "RUNNING", "revision": "carrier-enclosure-fusion-r13-reference",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "sources_sha256": sources_before,
        "verifier_sha256": sha256(Path(__file__)),
        "scope": "Accepted enclosure geometry, assembly paths and eleven meshes. Physical qualification beyond observed coupon fit is not inferred.",
        "assumptions": [
            "Carrier PCB and USB module thickness 1.44–1.76 mm; USB spacer 2.9–3.1 mm.",
            "Board edge growth 0.2 mm and USB module lateral placement shift ±0.2 mm.",
            "Purchased USB-module/spacer tolerances are design allowances requiring sample measurement.",
            "Case geometry stays nominal; printer dimensional error is not silently added to witnesses.",
            "Guide capture checks require positive intersections on both sides; shell closure may retain only coplanar Z27.6 contact; other intersections must be empty.",
            "The programmed 0.3 mm installation lift, clipped solder tails, and declared M2 hardware envelopes apply.",
            "No modeled tolerance establishes OEM screw suitability, actual glass seating, cable reach, or thermal/weather qualification.",
        ],
        "geometry_checks": {}, "meshes": {},
    }
    if not args.meshes_only:
        command = openscad_command(args.openscad)
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
            futures = {pool.submit(run_check, check, command, output, args.timeout): check for check in checks}
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                report["geometry_checks"][result["name"]] = result
                print(result["name"], result["result"], result.get("error", ""), flush=True)
    if not args.diagnostics_only:
        for part, filename in MESH_NAMES.items():
            result = check_mesh(part, output / filename, args.coupon_components)
            report["meshes"][part] = result
            print(part, result["result"], result.get("error", ""), flush=True)
    sources_after = source_hashes()
    report["sources_unchanged"] = sources_after == sources_before
    if sources_after != sources_before:
        report["sources_sha256_after"] = sources_after
    results = list(report["geometry_checks"].values()) + list(report["meshes"].values())
    passed = sources_after == sources_before and all(r["result"].startswith("PASS") for r in results)
    report["status"] = "PASS: CAD GEOMETRY" if passed else "FAIL"
    suffix = "-diagnostics" if args.diagnostics_only else "-meshes" if args.meshes_only else ""
    report_path = output / ("fit-verification" + suffix + ".json")
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(str(report_path), report["status"], flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
