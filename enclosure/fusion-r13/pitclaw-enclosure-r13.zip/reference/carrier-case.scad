// PitClaw Rev B carrier enclosure r13: bottom, top, removable fascia and internal retainer.
// Units mm. WT32 uses centered PCB coordinates; the carrier is shifted toward
// the power end by carrier_case_offset_y from the generated interface.
// This is a fit prototype, not a mechanically released / weather-rated case.
// WT32 OEM holes are REAR blind bosses: do not screw through the glass / PCB.
// See ../README.md for assembly, dimensions and physical qualification limits.
// All construction stages and the generated interface are included locally.
include <carrier-interface.scad>
use <adafruit5807-base.scad>

// Views also include fit-coupon and insert-coupon for first-print calibration.
// Single-part views are oriented flat on the build plate.
// Diagnostics insertion-check, carrier-installation-check and
// electronics-closure-check must render EMPTY.
part = "assembled";
show_electronics = true;
show_fasteners = true;
$fn = 48;
eps = 0.02;

// Shell and registration. Closure screws sit beyond the free LONG board sides.
case_width = 86;
case_length = 104;
wall = 2.5;
floor_thickness = 2.5;
front_plate = 3;
corner_radius = 5;
case_closure_xy = [[-38,-28],[38,-28],[-38,28],[38,28]];
locating_lip_height = 2;
locating_lip_wall = 1.2;
locating_lip_clearance = 0.3;

// User M3 insert: measured OD4.0..5.0; L4.0 assumed; accepted pilot4.2.
// Print an insertion coupon in the chosen material before committing the case.
insert_od = 5.0; // user-measured maximum knurl diameter
insert_length = 4;
insert_pilot = 4.2; // accepted pilot for user inserts
insert_bore_depth = 5;
insert_boss_od = 9;
carrier_standoff = 5;
minimum_floor_under_insert = 2.5;
m3_clearance = 3.4;
m3_head_clearance = 6.4;
closure_head_recess = 3.2;
// At the default stack, M3x18 closure screws give 3.9 mm insert engagement
// and 1.1 mm bore-bottom clearance. Verify engagement on the actual print.
// Carrier: M3x6 + 0.5 mm washer. Retainer: M3x6 button heads, without washers.

// Conservative vertical stack. Component and cable envelopes require samples.
carrier_component_height = 16;    // provisional; requires Q1 flat on the carrier
                                  // covers mated JST / socketed ADC envelopes
// K1 is modeled separately from the CAD contract at 16.2 mm seated height.
// Its local reserved gap is 2.8 mm; do not pretend it fits the 16 mm envelope.
board_gap = 3;                    // below the lowest display/retainer screw head
wt32_size = [60,92,10.8];          // footprint and conservative rear-space envelope
// Rear components and mated connectors are not fully represented by this box.
// Fit-check those parts and the harness within the reserved rear stack below.
wt32_mount_xy = [[4.305,6.52],[55.695,6.52],
                 [4.305,81.66],[55.695,81.66]];
wt32_active = [49.56,74.04];       // manufacturer drawing, centered on front
window_size = [50.6,75.1];        // provisional touch/display edge allowance
case_height = 44.9;              // preserve the fitted shell, seam and closure grip
bezel_rim_thickness = 1.2;        // outer face -> underside of the overlapping rim
front_pad_compressed = 0;        // direct seating on inactive glass border; no air gap
module_side_clearance = 0.6;      // body tolerance plus print allowance; no glass pinch

// Bench gap1.5..1.8mm with the original11.1mm stop-to-ledge distance implies
// an effective9.3..9.6mm mounting stack, assuming the mating faces are seated.
// This is a fit-derived range, not a newly measured supplier dimension.
// Four small screws pass through retainer INTO the OEM's rear blind bosses.
wt32_rear_mount_depth = 9.3;      // zero-shim end of the bench-derived fit range
retainer_stop_z = 34.4;           // fixed: original32.6 + maximum1.8mm correction
// For9.4/9.5/9.6mm effective depths use0.1/0.2/0.3mm shims at all four anchors.
retainer_thickness = 2.5;        // retain stiffness along the long, narrow webs
small_screw_head_height = 2;
small_screw_clearance = 2.8;      // provisional; OEM pilot is shown as diameter2.3
small_screw_head_od = 4.8;
retainer_outer = [70,96];
retainer_inner = [60.8,92.8];
retainer_tab_od = 6.4;
retainer_anchor_xy = [[-35.5,-40],[35.5,-40],[-35.5,40],[35.5,40]];
retainer_anchor_od = 9;
retainer_anchor_head_od = 5.7;   // ISO 7380 M3 button head, without washer
retainer_anchor_head_height = 1.65;
retainer_anchor_pilot = insert_pilot; // same M3 heat-set insert as lower shell
retainer_anchor_bore_depth = insert_bore_depth;

// RJ45 and barrel receptacle faces meet the flat exterior wall. USB-C sits
// 2 mm behind it, level with the floor of an access pocket for the cable boot.
// The three independent openings retain solid plastic between the sockets.
carrier_slide_start_y = 0.5;
carrier_slide_lift = 0.3;
power_profile_clearance = 0.5;
carrier_tail_projection = 3;     // maximum clipped lead/solder depth; inspect build
probe_axis_above_pcb = 2.55;      // 5.10 mm housing/bore center; verify sample seating
probe_body_height = 5.1;
probe_plug_opening = 10.5;
rj45_face_size = [15.75,13.21];  // Amphenol RJHSE-5080 housing, W x H above PCB
rj45_body_depth = 14.99;
barrel_face_size = [9,10.8];     // Tensility 54-00133 full housing; parameterized
barrel_body_depth = 14;
barrel_axis_above_pcb = 6.5;     // bore axis, not the housing center
usb_axis_above_pcb = 6.1;         // 3mm spacer + modulePCB + receptacle: measure
usb_face_size = [8.94,3.2];      // shell width from Eagle; height is sample-gated
usb_pocket_size = [20,10];
usb_pocket_depth = 2;
usb_pocket_z_offset = 0.5;       // stronger web above carrier channel; socket stays fixed
usb_inward_backing = 1;
usb_socket_opening = [10.14,4.7]; // fitted shell, thickness/spacer allowance + seat lift
power_face_size = [rj45_face_size,barrel_face_size,usb_face_size];
power_face_center_z = [rj45_face_size[1]/2,barrel_face_size[1]/2,
                       usb_axis_above_pcb];
power_face_corner_r = [0.2,0.2,0.4];

pd_pcb_size = [20.32,23.495,1.6];
pd_spacer_height = 3;
pd_face_overhang = 1.143;
pd_pcb_front_y = carrier_power_face_y[2]-pd_face_overhang;
// Consume the actual H5/H6 coordinates exported from the carrier CAD. These
// holes sit 0.127 mm left of the module center; do not assume +/-7.62.
pd_mount_xy = carrier_pd_mount_xy;
pd_hardware_diameter = 5;        // maximum head/washer/nut envelope, verified BOM
pd_hardware_below_pcb = 3.3;     // nut, washer and screw tip; inspect actual stack
pd_hardware_head_height = 2;    // total upper screw head + washer; inspect stack
blind_pocket_clearance = 0.2;
usb_relief_z_clearance = 0.8;   // separate Z budget; preserve thin blind-pocket Y skins
carrier_channel_xy_clearance = 0.5;
carrier_channel_z_clearance = 0.5;

// Diagnostic witness inputs ONLY; changing these must not resize the printed case.
check_pcb_thickness = 1.6;
check_pd_thickness = 1.6;
check_pd_spacer_height = 3;
check_board_edge_growth = 0;
check_module_shift_x = 0;

// Derived datums: Z=0 is the bottom exterior, +Z points toward the screen.
carrier_bottom_z = floor_thickness + carrier_standoff;
carrier_top_z = carrier_bottom_z + carrier_board_mm[2];
// Retainer and heads reserve 15.3 mm behind the glass with current parameters.
// Actual WT32 rear components and mated connectors still require measurement.
display_rear_depth = max(wt32_size[2], wt32_rear_mount_depth +
                        retainer_thickness + small_screw_head_height);
// Locate the display FROM the bezel contact face, rather than deriving its
// height independently from the electronics stack. The old independent stack
// left a permanent 0.3mm gap at the retainer hard stops when no strip was fitted.
front_pocket_roof_z = case_height - bezel_rim_thickness;
glass_front_z = front_pocket_roof_z - front_pad_compressed;
power_opening_roof_z = max(
    max([for(i=[0:1]) carrier_top_z+power_face_center_z[i]+
        power_face_size[i][1]/2+power_profile_clearance+carrier_slide_lift]),
    carrier_top_z+usb_axis_above_pcb+usb_pocket_size[1]/2);
// Preserve the existing seam and closure grip after fitting the smaller ports.
// At least 2 mm of plastic must remain above every opening.
seam_z = max(carrier_top_z + carrier_component_height + 2,
             carrier_top_z+18.5,power_opening_roof_z + 2);
retainer_top_z = glass_front_z - wt32_rear_mount_depth;
retainer_bottom_z = retainer_top_z - retainer_thickness;
inside_width = case_width - 2*wall;
inside_length = case_length - 2*wall;
lip_width = inside_width - 2*locating_lip_clearance;
lip_length = inside_length - 2*locating_lip_clearance;

function local_xy(p) = [p[0]-carrier_board_mm[0]/2,
                        p[1]-carrier_board_mm[1]/2];
function carrier_local_xy(p) = [p[0]-carrier_board_mm[0]/2,
                               p[1]-carrier_board_mm[1]/2+carrier_case_offset_y];
function dist2(a,b) = sqrt(pow(a[0]-b[0],2)+pow(a[1]-b[1],2));
pd_pcb_front_local_y = pd_pcb_front_y-46+carrier_case_offset_y;
pd_pcb_wall_clearance = inside_length/2-pd_pcb_front_local_y;
pd_hardware_wall_clearance = min([for(p=pd_mount_xy) inside_length/2-
    (p[1]-46+carrier_case_offset_y+pd_hardware_diameter/2)]);
usb_face_setback = case_length/2-
    (carrier_power_face_y[2]-46+carrier_case_offset_y);
usb_pocket_floor_y = case_length/2-usb_pocket_depth;
usb_backing_inner_y = inside_length/2-usb_inward_backing;
usb_nominal_floor = usb_pocket_floor_y-usb_backing_inner_y;
usb_pcb_relief_skin = usb_pocket_floor_y-
    (pd_pcb_front_local_y+blind_pocket_clearance);
usb_head_relief_skin = min([for(p=pd_mount_xy) usb_pocket_floor_y-
    (p[1]-46+carrier_case_offset_y+pd_hardware_diameter/2+blind_pocket_clearance)]);
usb_pocket_channel_gap = carrier_top_z+usb_axis_above_pcb+usb_pocket_z_offset-usb_pocket_size[1]/2-
    (carrier_top_z+carrier_channel_z_clearance+carrier_slide_lift);

assert(carrier_board_mm == [60,92,1.6], "Review enclosure after board change");
assert(insert_boss_od >= insert_od+2*1.6, "Insert boss wall too thin");
assert(floor_thickness+carrier_standoff-insert_bore_depth >=
       minimum_floor_under_insert, "Blind insert bore thins the bottom floor");
assert(insert_bore_depth >= insert_length+1, "Insufficient insert melt relief");
assert(front_pad_compressed >= 0 && bezel_rim_thickness >= 1,
       "Need nonnegative interface thickness and at least1mm plastic front rim");
assert(window_size[0] > wt32_active[0] && window_size[1] > wt32_active[1],
       "Window masks active display");
assert(retainer_outer[0] < inside_width && retainer_outer[1] < inside_length,
       "Retainer does not fit shell");
assert(retainer_bottom_z-small_screw_head_height -
       (carrier_top_z+carrier_component_height) >= board_gap-eps,
       "Retainer screw head collides with carrier envelope");
assert(!is_undef(carrier_case_offset_y), "Regenerate the carrier interface");
assert(inside_length/2 > 46-carrier_probe_face_y-carrier_slide_start_y,
       "Probe noses cannot lower at the initial installation offset");
assert(max(carrier_power_face_y)-46+carrier_slide_start_y < inside_length/2,
       "Power faces cannot lower at the initial installation offset");
assert(pd_pcb_wall_clearance >= 0.2, "USB module PCB needs clearance from normal wall");
assert(pd_hardware_wall_clearance >= 0.15, "USB mounting hardware touches normal wall");
assert(abs(usb_face_setback-2)<eps, "USB-C face must sit 2 mm behind the exterior");
assert(abs(usb_face_setback-usb_pocket_depth)<eps,
       "USB-C face must be level with the access-pocket floor");
assert(usb_nominal_floor >= 1.5, "USB pocket backing is too thin");
assert(usb_pcb_relief_skin >= 0.94, "Hidden USB PCB relief breaks through the pocket floor");
assert(usb_head_relief_skin >= 0.98, "Hidden USB head relief breaks through the pocket floor");
assert(usb_pocket_channel_gap >= 0.8-eps, "USB pocket/channel web is too thin");
for(face_y=[carrier_power_face_y[0],carrier_power_face_y[1]])
    assert(abs(face_y+carrier_case_offset_y-46-case_length/2)<0.02,
           "Power receptacle face is not flush with the exterior panel");
assert(retainer_bottom_z > seam_z, "Retainer must stay with upper half");
assert(seam_z >= power_opening_roof_z+2-eps,
       "Power opening leaves less than 2 mm wall below the seam");
assert(retainer_top_z > seam_z+1,
       "Retainer insertion relief reaches the final anchor hard stops");
assert(case_height-retainer_stop_z-retainer_anchor_bore_depth >= 2.5,
       "Retainer insert bore leaves too little front material");
for (p=case_closure_xy)
    assert(abs(p[0])-insert_boss_od/2 > carrier_board_mm[0]/2,
           "Closure hardware overlaps either board");
for (p=retainer_anchor_xy, q=case_closure_xy)
    assert(dist2(p,q) > (retainer_anchor_od+insert_boss_od)/2+1,
           "Display anchor intersects closure boss");

echo("DRAFT case W,L,H", [case_width,case_length,case_height]);
echo("FIT_CHECK_INPUTS", [check_pcb_thickness, check_pd_thickness,
     check_pd_spacer_height, check_board_edge_growth, check_module_shift_x]);
echo("Carrier underside / top / max component", [carrier_bottom_z,
     carrier_top_z,carrier_top_z+carrier_component_height]);
echo("Seam / retainer underside / glass front", [seam_z,retainer_bottom_z,glass_front_z]);
echo("Bezel underside / glass gap / outer recess",
     [front_pocket_roof_z,front_pocket_roof_z-glass_front_z,case_height-glass_front_z]);
echo("USB face setback / pocket floor thickness / channel separation",
     [usb_face_setback,usb_nominal_floor,usb_pocket_channel_gap]);
echo("USB local floor skin at hidden PCB / screw-head clearances",
     [usb_pcb_relief_skin,usb_head_relief_skin]);
echo("USB PCB / mounting hardware clearance from normal wall",
     [pd_pcb_wall_clearance,pd_hardware_wall_clearance]);
echo("UNMEASURED: OEM rear mounting plane, screw engagement, glass seating,");
echo("rear components/antenna/cables, all plug overmolds and most connector Z.");

module rounded_rect(w,h,r=2) {
    offset(r=r) square([w-2*r,h-2*r],center=true);
}
module rounded_solid(w,h,z,r=2) {
    linear_extrude(height=z) rounded_rect(w,h,r);
}
module ring(w,h,iw,ih,z,r=2) {
    difference() {
        rounded_solid(w,h,z,r);
        translate([0,0,-eps]) rounded_solid(iw,ih,z+2*eps,max(r-1,0.4));
    }
}
module blind_insert_bore(top_z) {
    translate([0,0,top_z-insert_bore_depth])
        cylinder(d=insert_pilot,h=insert_bore_depth+eps);
}
module retainer_insertion_relief() {
    // The ring and its two anchor pads must pass through the lip and shoulder
    // before reaching their mounting plane. Provide 0.4/0.5 mm edge clearance.
    // Stop below the final anchor bosses; these remain solid hard stops.
    translate([0,0,seam_z-locating_lip_height-eps]) {
        rounded_solid(retainer_outer[0]+0.8,retainer_outer[1]+1,
                      locating_lip_height+1+2*eps,1);
        for(p=retainer_anchor_xy)
            translate([p[0],p[1],0])
                cylinder(d=retainer_anchor_od+1,
                         h=locating_lip_height+1+2*eps);
    }
}
module connector_openings() {
    for (x=carrier_probe_x)
        translate([x-carrier_board_mm[0]/2,-case_length/2,
                   carrier_top_z+probe_axis_above_pcb])
            rotate([90,0,0]) cylinder(d=probe_plug_opening,h=wall*4,center=true);
    for(i=[0:1])
        translate([carrier_power_x[i]-30,case_length/2,
                   carrier_top_z+power_face_center_z[i]+carrier_slide_lift/2])
            rotate([90,0,0])
                linear_extrude(height=wall*4,center=true)
                    rounded_rect(power_face_size[i][0]+2*power_profile_clearance,
                                 power_face_size[i][1]+2*power_profile_clearance+
                                 carrier_slide_lift,power_face_corner_r[i]);
    translate([carrier_power_x[2]-30,case_length/2,
               carrier_top_z+usb_axis_above_pcb]) {
        // The recess receives the cable's plastic body. Only the fitted metal
        // shell opening passes through its floor, level with the socket face.
        translate([0,0,carrier_slide_lift/2]) rotate([90,0,0])
            linear_extrude(height=wall*4,center=true)
                rounded_rect(usb_socket_opening[0],usb_socket_opening[1],0.4);
        translate([0,eps,usb_pocket_z_offset]) rotate([90,0,0])
            linear_extrude(height=usb_pocket_depth+eps)
                rounded_rect(usb_pocket_size[0],usb_pocket_size[1],2);
    }
}
module usb_pocket_backing() {
    // Integral backing gives a 1.5 mm nominal floor. Limit it to the pocket's
    // projection so it remains above the separate carrier-edge channel.
    translate([carrier_power_x[2]-30,inside_length/2+eps,
               carrier_top_z+usb_axis_above_pcb+usb_pocket_z_offset]) rotate([90,0,0])
        linear_extrude(height=usb_inward_backing+eps)
            rounded_rect(usb_pocket_size[0],usb_pocket_size[1],2);
}
module carrier_blind_reliefs() {
    // Internal carrier-edge channel: the PCB stops 1.5 mm behind the exterior;
    // 0.5 mm end clearance leaves 1.0 mm continuous exterior plastic.
    translate([-30-carrier_channel_xy_clearance,inside_length/2-eps,
               carrier_bottom_z-carrier_channel_z_clearance])
        cube([60+2*carrier_channel_xy_clearance,
              46+carrier_case_offset_y+carrier_channel_xy_clearance-inside_length/2+eps,
              carrier_board_mm[2]+2*carrier_channel_z_clearance+carrier_slide_lift]);
    // These clearances are hidden behind the recessed USB floor. Include the
    // 0.3 mm installation lift. Z is enlarged independently of the thin Y skin.
    translate([carrier_power_x[2]-30-pd_pcb_size[0]/2-blind_pocket_clearance,
               usb_backing_inner_y-eps,
               carrier_top_z+pd_spacer_height-usb_relief_z_clearance])
        cube([pd_pcb_size[0]+2*blind_pocket_clearance,
              pd_pcb_front_local_y+blind_pocket_clearance-usb_backing_inner_y+eps,
              pd_pcb_size[2]+2*usb_relief_z_clearance+carrier_slide_lift]);
    // Continuous round spacer/head clearances preserve material in Y.
    // Nuts lie below the backing and need no cuts. Minimum hardware-pocket skin is
    // 0.983 mm; these pockets cannot open onto the visible access-pocket floor.
    for(p=pd_mount_xy)
        translate(concat(carrier_local_xy(p),
                         [carrier_top_z-usb_relief_z_clearance]))
            cylinder(d=pd_hardware_diameter+2*blind_pocket_clearance,
                     h=pd_spacer_height+pd_pcb_size[2]+pd_hardware_head_height+
                       carrier_slide_lift+2*usb_relief_z_clearance);
}
module carrier_support_posts() {
    // Bare-board contact patches stay at the carrier datum, including where a
    // blind wall pocket passes nearby. The carrier slides 0.3 mm above them.
    for(x=[2,56])
        translate([x-30,90.7-46+carrier_case_offset_y,floor_thickness-eps])
            cube([3,1.3,carrier_standoff+eps]);
}

module bottom_shell_board_coordinates() {
    difference() {
        union() {
            difference() {
                rounded_solid(case_width,case_length,seam_z,corner_radius);
                translate([0,0,floor_thickness])
                    rounded_solid(inside_width,inside_length,seam_z,
                                  corner_radius-wall);
            }
            for (p=carrier_mount_xy)
                translate(concat(carrier_local_xy(p),[floor_thickness-eps]))
                    cylinder(d=insert_boss_od,h=carrier_standoff+eps);
            for (p=case_closure_xy)
                translate([p[0],p[1],floor_thickness-eps])
                    cylinder(d=insert_boss_od,h=seam_z-floor_thickness+eps);
            usb_pocket_backing();
        }
        for (p=carrier_mount_xy)
            translate(concat(carrier_local_xy(p),[0])) blind_insert_bore(carrier_bottom_z);
        for (p=case_closure_xy)
            translate([p[0],p[1],0]) blind_insert_bore(seam_z);
        connector_openings();
        carrier_blind_reliefs();
    }
    carrier_support_posts();
}

module top_bezel_base() {
    difference() {
        union() {
            // Top cup: screen pocket leaves a ledge on the inactive glass border.
            difference() {
                translate([0,0,seam_z])
                    rounded_solid(case_width,case_length,case_height-seam_z,corner_radius);
                translate([0,0,seam_z-eps])
                    rounded_solid(inside_width,inside_length,
                                  case_height-front_plate-seam_z+eps,corner_radius-wall);
            }
            // Loose locating lip. No snap catches. Interrupted at closure posts.
            // This shoulder overlaps BOTH the inset lip and cup wall. Without
            // it the 0.3mm fit clearance would leave the lip as a loose ring.
            translate([0,0,seam_z])
                ring(case_width,case_length,
                     lip_width-2*locating_lip_wall,
                     lip_length-2*locating_lip_wall,1,corner_radius);
            difference() {
                translate([0,0,seam_z-locating_lip_height])
                    difference() {
                    rounded_solid(lip_width,lip_length,locating_lip_height+eps,2.2);
                    translate([0,0,-eps])
                        rounded_solid(lip_width-2*locating_lip_wall,
                                      lip_length-2*locating_lip_wall,
                                      locating_lip_height+3*eps,1);
                }
                for(p=case_closure_xy)
                    translate([p[0],p[1],seam_z-locating_lip_height-eps])
                        cylinder(d=insert_boss_od+1,h=locating_lip_height+2*eps);
            }
            // Solid meeting faces transfer case clamp force around the display.
            for(p=case_closure_xy)
                translate([p[0],p[1],seam_z])
                    cylinder(d=insert_boss_od,h=case_height-seam_z);
            // Fixed shortened stops allow1.8mm forward travel. Fit0..0.3mm shims
            // between these stops and retainer to establish glass contact.
            // Tightening must not bridge a support gap or load/bow the glass.
            for(p=retainer_anchor_xy)
                translate([p[0],p[1],retainer_stop_z])
                    cylinder(d=retainer_anchor_od,h=case_height-retainer_stop_z);
        }
        translate([0,0,seam_z-eps])
            rounded_solid(wt32_size[0]+2*module_side_clearance,
                          wt32_size[1]+2*module_side_clearance,
                          front_pocket_roof_z-seam_z+eps,1.5);
        translate([0,0,front_pocket_roof_z-eps])
            rounded_solid(window_size[0],window_size[1],
                          case_height-front_pocket_roof_z+2*eps,1);
        // Small front-edge chamfer keeps the lip out of a finger's approach.
        translate([0,0,case_height-0.5])
            linear_extrude(height=0.5+eps,scale=[1.015,1.01])
                rounded_rect(window_size[0],window_size[1],1);
        for(p=case_closure_xy) {
            translate([p[0],p[1],seam_z-eps])
                cylinder(d=m3_clearance,h=case_height-seam_z+2*eps);
            translate([p[0],p[1],case_height-closure_head_recess])
                cylinder(d=m3_head_clearance,h=closure_head_recess+eps);
        }
        for(p=retainer_anchor_xy)
            translate([p[0],p[1],retainer_stop_z-eps])
                cylinder(d=retainer_anchor_pilot,h=retainer_anchor_bore_depth+eps);
        retainer_insertion_relief();
    }
}

module retainer() {
    difference() {
        union() {
            ring(retainer_outer[0],retainer_outer[1],
                 retainer_inner[0],retainer_inner[1],retainer_thickness,1);
            for(p=wt32_mount_xy) {
                q=local_xy(p);
                hull() {
                    translate([q[0],q[1],0])
                        cylinder(d=retainer_tab_od,h=retainer_thickness);
                    translate([q[0]<0 ? -32 : 32,q[1],0])
                        cylinder(d=1.6,h=retainer_thickness);
                }
            }
            for(p=retainer_anchor_xy)
                translate([p[0],p[1],0])
                    cylinder(d=retainer_anchor_od,h=retainer_thickness);
        }
        // Scallop the ring around independent enclosure closure columns.
        for(p=case_closure_xy)
            translate([p[0],p[1],-eps])
                cylinder(d=insert_boss_od+1,h=retainer_thickness+2*eps);
        for(p=wt32_mount_xy)
            translate(concat(local_xy(p),[-eps]))
                cylinder(d=small_screw_clearance,h=retainer_thickness+2*eps);
        for(p=retainer_anchor_xy)
            translate([p[0],p[1],-eps])
                cylinder(d=m3_clearance,h=retainer_thickness+2*eps);
    }
}

// A convex primitive swept between two positions models each part separately.
// Taking a hull of the complete populated board would incorrectly fill the air
// between its leads and report spurious collisions with the mounting posts.
module swept_carrier_box(pos,size,offset0,offset1,lift0,lift1) {
    hull() {
        translate([pos[0],pos[1]+offset0,pos[2]+lift0]) cube(size);
        translate([pos[0],pos[1]+offset1,pos[2]+lift1]) cube(size);
    }
}
module swept_carrier_cylinder(pos,d,h,offset0,offset1,lift0,lift1) {
    hull() {
        translate([pos[0],pos[1]+offset0,pos[2]+lift0]) cylinder(d=d,h=h,$fn=24);
        translate([pos[0],pos[1]+offset1,pos[2]+lift1]) cylinder(d=d,h=h,$fn=24);
    }
}
module carrier_sweep_board_coordinates(offset0,offset1,lift0,lift1) {
    checked_top = carrier_bottom_z+check_pcb_thickness;
    checked_pd_base = checked_top+check_pd_spacer_height;
    checked_usb_center = checked_pd_base+check_pd_thickness+
                         usb_axis_above_pcb-pd_spacer_height-pd_pcb_size[2];
    // Ignore only the intentional zero-clearance seating contact with posts.
    swept_carrier_box([-30-check_board_edge_growth,-46-check_board_edge_growth,carrier_bottom_z+eps],
        [60+2*check_board_edge_growth,92+2*check_board_edge_growth,check_pcb_thickness-eps],
        offset0,offset1,lift0,lift1);
    assert(!is_undef(carrier_component_boxes) && len(carrier_component_boxes)==31,
           "Export all placed component envelopes before checking case fit");
    for(b=carrier_component_boxes)
        swept_carrier_box([b[0]-30,b[1]-46,checked_top],
            [b[2],b[3],b[4]],offset0,offset1,lift0,lift1);
    if(!is_undef(carrier_relay_box))
        swept_carrier_box([carrier_relay_box[0]-30,carrier_relay_box[1]-46,
                          checked_top],
                         [carrier_relay_box[2],carrier_relay_box[3],carrier_relay_box[4]],
                         offset0,offset1,lift0,lift1);
    for(i=[0:2]) {
        depth = i==0 ? rj45_body_depth : i==1 ? barrel_body_depth : 7.5;
        swept_carrier_box([carrier_power_x[i]-30-power_face_size[i][0]/2+
                          (i==2 ? check_module_shift_x : 0),
            carrier_power_face_y[i]-46-depth,
            (i==2 ? checked_usb_center : checked_top+power_face_center_z[i])-
            power_face_size[i][1]/2],
            [power_face_size[i][0],depth,power_face_size[i][1]],
            offset0,offset1,lift0,lift1);
    }
    for(x=carrier_probe_x) {
        swept_carrier_box([x-30-2.55,-46,checked_top],
                         [5.1,8,5.1],offset0,offset1,lift0,lift1);
        hull() for(v=[[offset0,lift0],[offset1,lift1]])
            translate([x-30,carrier_probe_face_y-46+v[0],checked_top+2.55+v[1]])
                rotate([-90,0,0]) cylinder(d=4,h=3.1);
    }
    swept_carrier_box([carrier_power_x[2]-30-pd_pcb_size[0]/2+check_module_shift_x,
        pd_pcb_front_y-46-pd_pcb_size[1],checked_pd_base],
        [pd_pcb_size[0],pd_pcb_size[1],check_pd_thickness],offset0,offset1,lift0,lift1);
    for(p=pd_mount_xy) {
        swept_carrier_cylinder([p[0]-30,p[1]-46,
            carrier_bottom_z-pd_hardware_below_pcb],pd_hardware_diameter,
            pd_hardware_below_pcb-eps,offset0,offset1,lift0,lift1);
        // Include the actual spacer envelope; it previously intersected the
        // pocket backing unnoticed. Carrier bolts locate the spacer centers.
        swept_carrier_cylinder([p[0]-30,p[1]-46,checked_top],pd_hardware_diameter,
            check_pd_spacer_height,offset0,offset1,lift0,lift1);
        swept_carrier_cylinder([p[0]-30,p[1]-46,
            checked_pd_base+check_pd_thickness],pd_hardware_diameter,
            pd_hardware_head_height,offset0,offset1,lift0,lift1);
    }
    // Sweep the actual printed base, retaining its solder openings and low front floor.
    // A tiny centred box gives the translation segment a valid3D volume.
    minkowski() {
        translate([carrier_power_x[2]-30,pd_pcb_front_y-46-pd_pcb_size[1],checked_top])
            mirror([1,0,0]) scale([1,1,check_pd_spacer_height/3]) ada5807_base();
        hull() for(v=[[offset0,lift0],[offset1,lift1]])
            translate([0,v[0],v[1]]) cube([.0001,.0001,.0001],center=true);
    }
    // Generated pad diameters include solder fillet allowance. Actual lead tails
    // must be clipped and inspected to stay within the declared 3 mm projection.
    for(p=carrier_underside_pads)
        swept_carrier_cylinder([p[0]-30,p[1]-46,
            carrier_bottom_z-carrier_tail_projection],p[2],
            carrier_tail_projection-eps,offset0,offset1,lift0,lift1);
}

// Visual-only witnesses. Do not export these as purchased-part models.
module carrier_witness_board_coordinates() {
    translate([0,carrier_case_offset_y,0]) {
        color([0.10,0.42,0.24]) difference() {
            translate([-30,-46,carrier_bottom_z]) cube(carrier_board_mm);
            for(p=carrier_mount_xy)
                translate(concat(local_xy(p),[carrier_bottom_z-eps]))
                    cylinder(d=3.2,h=carrier_board_mm[2]+2*eps);
        }
        color([0.2,0.22,0.25,0.18])
            for(b=carrier_component_boxes)
                translate([b[0]-30,b[1]-46,carrier_top_z]) cube([b[2],b[3],b[4]]);
        if(!is_undef(carrier_relay_box))
            color([0.19,0.20,0.21])
                translate([carrier_relay_box[0]-30,carrier_relay_box[1]-46,carrier_top_z])
                    cube([carrier_relay_box[2],carrier_relay_box[3],carrier_relay_box[4]]);
        for(x=carrier_probe_x)
            color([0.18,0.18,0.19])
                translate([x-30,carrier_probe_face_y-46+3,
                           carrier_top_z+probe_axis_above_pcb])
                    rotate([90,0,0]) cylinder(d=probe_body_height,h=6,center=true);
        for(i=[0:1]) {
            depth = i==0 ? rj45_body_depth : barrel_body_depth;
            color(i==0 ? [0.32,0.35,0.36] : [0.18,0.18,0.19]) difference() {
                translate([carrier_power_x[i]-30-power_face_size[i][0]/2,
                           carrier_power_face_y[i]-46-depth,carrier_top_z])
                    cube([power_face_size[i][0],depth,power_face_size[i][1]]);
                if(i==1)
                    translate([carrier_power_x[i]-30,carrier_power_face_y[i]-46,
                               carrier_top_z+barrel_axis_above_pcb])
                        rotate([90,0,0]) cylinder(d=6.3,h=3,center=true);
                else
                    translate([carrier_power_x[i]-30,carrier_power_face_y[i]-46,
                               carrier_top_z+power_face_size[i][1]/2])
                        cube([11.8,3,8],center=true);
            }
        }
        color([0.1,0.34,0.45])
            translate([carrier_power_x[2]-30-pd_pcb_size[0]/2,
                       pd_pcb_front_y-46-pd_pcb_size[1],carrier_top_z+pd_spacer_height])
                cube(pd_pcb_size);
        // Visual-only shell and dark mouth make the USB setback clear in the
        // access pocket. Collision checks retain the full conservative box.
        translate([carrier_power_x[2]-30,carrier_power_face_y[2]-46,
                   carrier_top_z+usb_axis_above_pcb]) rotate([90,0,0]) {
            color([0.6,0.62,0.64]) difference() {
                linear_extrude(height=7.5)
                    rounded_rect(usb_face_size[0],usb_face_size[1],1.2);
                translate([0,0,-eps]) linear_extrude(height=2+eps)
                    rounded_rect(7.5,2,0.9);
            }
            color([0.06,0.07,0.08]) translate([0,0,1.9])
                linear_extrude(height=0.05) rounded_rect(7.5,2,0.9);
        }
        color([0.65,0.66,0.67])
            for(p=pd_mount_xy)
                translate([p[0]-30,p[1]-46,carrier_bottom_z-pd_hardware_below_pcb])
                    cylinder(d=pd_hardware_diameter,h=pd_hardware_below_pcb,$fn=24);
        color([.95,.51,.14])
            translate([carrier_power_x[2]-30,pd_pcb_front_y-46-pd_pcb_size[1],carrier_top_z])
                mirror([1,0,0]) ada5807_base();
    }
}

module wt32_witness() {
    color([0.14,0.16,0.20])
        translate([0,0,glass_front_z-1.45]) rounded_solid(60,92,1.45,1.5);
    color([0.12,0.34,0.46])
        translate([0,0,glass_front_z]) rounded_solid(wt32_active[0],wt32_active[1],0.03,1);
    color([0.20,0.21,0.23])
        translate([0,0,glass_front_z-4.8]) ring(60,92,53,82,3.35,1.5);
    color([0.11,0.13,0.14])
        translate([-24,-35,glass_front_z-wt32_rear_mount_depth]) cube([48,70,1.6]);
    for(p=wt32_mount_xy)
        color([0.2,0.21,0.23])
            translate(concat(local_xy(p),[retainer_top_z]))
                difference() {
                    cylinder(d=5.8,h=wt32_rear_mount_depth-4.8);
                    translate([0,0,-eps]) cylinder(d=2.3,h=2.5);
                }
    // Optional interface only when explicitly dimensioned; default is direct contact.
    if (front_pad_compressed > 0)
    color([0.82,0.83,0.80])
        translate([0,0,glass_front_z])
            ring(58.8,90.8,55.2,85.2,front_pad_compressed,1.2);
}
module retainer_screw_witness() {
    // M3x6 button heads at outer anchors must remain <=2 mm high.
    for(p=[for(q=wt32_mount_xy) local_xy(q)])
        color([0.66,0.68,0.7])
            translate([p[0],p[1],retainer_bottom_z-small_screw_head_height])
                cylinder(d=small_screw_head_od,h=small_screw_head_height);
    for(p=retainer_anchor_xy)
        color([0.66,0.68,0.7])
            translate([p[0],p[1],retainer_bottom_z-retainer_anchor_head_height])
                cylinder(d=retainer_anchor_head_od,h=retainer_anchor_head_height);
}
module assembly(explode=0) {
    color([0.22,0.25,0.28]) bottom_shell();
    color([0.30,0.34,0.38]) probe_fascia();
    if(show_electronics) carrier_witness();
    translate([0,0,explode]) {
        color([0.77,0.78,0.74]) translate([0,0,retainer_bottom_z]) retainer();
        if(show_fasteners) retainer_screw_witness();
    }
    if(show_electronics) translate([0,0,explode*2]) wt32_witness();
    color([0.95,0.51,0.14]) translate([0,0,explode*3]) top_bezel();
}
module top_print() {
    translate([0,0,case_height]) rotate([180,0,0]) top_bezel();
}
module insertion_collision() {
    // Sweep the preassembled OEM housing and retainer glass-first into the top.
    // The ring stops at its anchor plane; the glass continues into its pocket.
    // This checks modeled solids only, not unmeasured cables or driver access.
    sweep_start = seam_z-locating_lip_height-retainer_thickness-1;
    intersection() {
        top_bezel();
        union() {
            translate([0,0,sweep_start])
                linear_extrude(height=retainer_top_z-sweep_start-0.01)
                    projection(cut=false) retainer();
            translate([0,0,sweep_start])
                rounded_solid(wt32_size[0],wt32_size[1],
                              glass_front_z-sweep_start,1.5);
        }
    }
}

module carrier_installation_collision() {
    assert(!is_undef(carrier_underside_pads) && len(carrier_underside_pads)>0,
           "Regenerate actual underside pad envelopes before checking installation");
    // 1. Lower at +0.5 mm offset, all power noses clear the inner wall.
    // 2. Slide forward 4 mm at 0.3 mm above the posts and ledges.
    // 3. Lower 0.3 mm onto the posts; install the four carrier screws afterward.
    intersection() {
        bottom_shell();
        union() {
            carrier_sweep(carrier_slide_start_y,carrier_slide_start_y,
                          seam_z+5,carrier_slide_lift);
            carrier_sweep(carrier_slide_start_y,carrier_case_offset_y,
                          carrier_slide_lift,carrier_slide_lift);
            carrier_sweep(carrier_case_offset_y,carrier_case_offset_y,
                          carrier_slide_lift,0);
        }
    }
}
module electronics_closure_collision() {
    assert(!is_undef(carrier_relay_box), "Export the placed relay's body envelope");
    assert(glass_front_z-display_rear_depth-(carrier_bottom_z+check_pcb_thickness)-carrier_relay_box[4]
           >= 2.64-eps, "K1 violates its thickness-toleranced local rear clearance");
    echo("K1 minimum reserved rear clearance",
         glass_front_z-display_rear_depth-carrier_top_z-carrier_relay_box[4]);
    intersection() {
        union() {
            top_bezel();
            translate([0,0,retainer_bottom_z]) retainer();
            retainer_screw_witness();
        }
        union() {
            carrier_sweep(carrier_case_offset_y,carrier_case_offset_y,0,0);
            // Installed carrier screws/insulating washers: Ø7 x3.5 mm reserve.
            for(p=carrier_mount_xy)
                translate(concat(carrier_local_xy(p),[carrier_bottom_z+check_pcb_thickness]))
                    cylinder(d=7,h=3.5);
        }
    }
}

module fit_coupon() {
    // Exact power-end section of the bottom, printed in the same orientation.
    // Check actual plugs, Ø5 spacers and the populated carrier's slide locally.
    // The full carrier hangs beyond the coupon; support it level during a test.
    translate([0,-41,0]) intersection() {
        bottom_shell();
        translate([-case_width,30,-eps]) cube([2*case_width,22+eps,seam_z+2*eps]);
    }
}

module insert_coupon() {
    // Same Ø9 bosses, 5 mm blind pilot depth and 2.5 mm closed floor.
    // Engraved labels identify 4.0 / 4.1 / 4.2 mm bores, left to right.
    difference() {
        union() {
            translate([-18,-8,0]) cube([36,16,2.5]);
            for(x=[-12,0,12]) translate([x,1,2.5-eps]) cylinder(d=9,h=5+eps);
        }
        for(i=[0:2]) {
            translate([-12+i*12,1,2.5]) cylinder(d=4+i*0.1,h=5+eps);
            translate([-12+i*12,-5.3,2.1]) linear_extrude(height=.5)
                text(str(4+i*0.1),size=2.2,halign="center",valign="center");
        }
    }
}

module shell_closure_collision() {
    // Intentional meeting faces have zero volume; positive volume is a clash.
    intersection() {
        bottom_shell();
        union() {
            top_bezel();
            translate([0,0,retainer_bottom_z]) retainer();
        }
    }
}

if(part=="guide-capture-front-check") guide_capture_collision(-51.8);
else if(part=="guide-capture-early-check") guide_capture_collision(-50.8);
else if(part=="guide-capture-midfront-check") guide_capture_collision(-49);
else if(part=="guide-capture-middle-check") guide_capture_collision(-47);
else if(part=="guide-capture-rear-check") guide_capture_collision(-44);
else if(part=="mount-coupon") translate([-35,-37.5,0]) mount_coupon();
else if(part=="mount-screw-check") mount_screw_collision();
else if(part=="mount-tool-check") mount_tool_collision();
else if(part=="joint-coupon-bottom") translate([-26.5,37,0]) joint_coupon_bottom();
else if(part=="joint-coupon-top") translate([-26.5,-37,case_height]) rotate([180,0,0]) joint_coupon_top();
else if(part=="joint-coupon-fascia") translate([-23,13.7,52]) rotate([90,0,0]) joint_coupon_fascia();
else if(part=="fascia") translate([0,0,52]) rotate([90,0,0]) probe_fascia();
else if(part=="usb-base") ada5807_base();
else if(part=="fascia-installed") probe_fascia();
else if(part=="fascia-lift-check") fascia_lift_collision();
else if(part=="fascia-fit-check") fascia_fit_collision();
else if(part=="fascia-insertion-check") fascia_insertion_collision();
else if(part=="lid-closing-check") lid_closing_collision();
else if(part=="top") top_print();
else if(part=="bottom") bottom_shell();
else if(part=="retainer") retainer();
else if(part=="display-shim-0.1") display_shim(.1);
else if(part=="display-shim-0.2") display_shim(.2);
else if(part=="fit-coupon") fit_coupon();
else if(part=="insert-coupon") insert_coupon();
else if(part=="print") {
    translate([-case_width-8,0,0]) top_print();
    bottom_shell();
    translate([case_width+8,0,0]) retainer();
}
else if(part=="exploded") rotate([0,0,90]) assembly(15);
else if(part=="section") difference() {
    assembly();
    translate([0,-case_length, -eps]) cube([case_width,case_length*2,case_height+1]);
}
else if(part=="assembled") rotate([0,0,90]) assembly();
else if(part=="insertion-check") insertion_collision();
else if(part=="carrier-installation-check") carrier_installation_collision();
else if(part=="electronics-closure-check") electronics_closure_collision();
else if(part=="shell-closure-check") shell_closure_collision();
else if(part=="guide-support-front-005-check") guide_support_collision(-49.6,.05);
else if(part=="guide-support-front-010-check") guide_support_collision(-49.6,.1);
else if(part=="guide-support-rear-005-check") guide_support_collision(-43.5,.05);
else if(part=="guide-support-rear-010-check") guide_support_collision(-43.5,.1);
else if(part=="lowered-entry-check") lowered_entry_collision();
else if(part=="shell-closure-with-fascia-check") shell_closure_with_fascia_collision();
else assert(false,"Unknown part view");

// Reflect the case-side X mapping to match a rigid, component-up KiCad placement.
module bottom_shell_base() {
    mirror([1,0,0]) bottom_shell_board_coordinates();
}

// Reflect the case-side X mapping to match a rigid, component-up KiCad placement.
module carrier_witness() {
    mirror([1,0,0]) carrier_witness_board_coordinates();
}

// Reflect the case-side X mapping to match a rigid, component-up KiCad placement.
module carrier_sweep(offset0,offset1,lift0,lift1) {
    mirror([1,0,0]) carrier_sweep_board_coordinates(offset0,offset1,lift0,lift1);
}

// Embedded probe-fascia construction stage in physical PCB coordinates.
module box_bounds(x0,x1,y0,y1,z0,z1) {
    translate([x0,y0,z0]) cube([x1-x0,y1-y0,z1-z0]);
}
module xz_profile(y,cx,cz,w,h,r,t=.001) {
    translate([cx,y,cz]) rotate([-90,0,0])
        linear_extrude(height=t) rounded_rect(w,h,r);
}
// Constant matched XZ guide profiles over the full9mm insertion depth.
// XZ polygons are converted into an X/-Z sketch and extruded along+Y.
module xz_prism(points,y0,y1) {
    translate([0,y0,0]) rotate([-90,0,0])
        linear_extrude(height=y1-y0) polygon([for(p=points) [p[0],-p[1]]]);
}
module guide_male() {
    xz_prism([[32.7,3.8],[36,3.8],[36,5.8],[32.7,9.1]],-52,-43);
}
module guide_cavity() {
    xz_prism([[32.7,3.8],[36.3,3.8],[36.3,41.8+sqrt(2)*.4-36.3],[32.7,41.8+sqrt(2)*.4-32.7]],-52.1,-43);
}
module probe_pocket_blank() {
    union() {
        bottom_shell_base();
        xz_profile(-52,0,11.65,64,20,4,9.5);
    }
}
module probe_pocket_cut() {
    hull() {
        xz_profile(-52.02,0,11.15,60,19,5.5);
        xz_profile(-44.5,0,11.65,50,12,3);
    }
    for(x=[-17,0,17]) {
        translate([x,-44.52,11.65]) rotate([-90,0,0]) cylinder(d=5.6,h=2.04);
        translate([x,-43.1,11.65]) rotate([-90,0,0]) cylinder(d1=5.6,d2=6.4,h=.62);
    }
}
module probe_fascia() {
    difference() {
        union() {
            intersection() {
                probe_pocket_blank();
                box_bounds(-33.1,33.1,-53,-42.5,0,27.4);
            }
            for(s=[-1,1]) scale([s,1,1]) {
                box_bounds(31,33.1,-52,-42.5,2.48,9.5);
                guide_male();
                box_bounds(29,31.3,-49.5,-45.5,18,25);
            }
            // Only the floor extends rearward; the probe plate remains fixed.
            box_bounds(-33.1,33.1,-42.52,-42.2,0,2.5);
            for(x=[-21,21])
                box_bounds(x-9.3,x+9.3,-52,-45.5,20.8,25);
        }
        probe_pocket_cut();
        for(x=[-21,21])
            box_bounds(x-6.3,x+6.3,-50.85,-48.25,20.78,27.42);
    }
}
module bottom_shell_with_guides() {
    difference() {
        union() {
            difference() {
                bottom_shell_base();
                box_bounds(-33.3,33.3,-53,-42,-.02,27.62);
            }
            intersection() {
                rounded_solid(case_width,case_length,8,corner_radius);
                for(s=[-1,1]) scale([s,1,1])
                    box_bounds(33.3,39,-52,-40.5,0,8);
            }
            // Keep raised rail roofs inside the original rounded exterior.
            intersection() {
                rounded_solid(case_width,case_length,10.6,corner_radius);
                for(s=[-1,1]) scale([s,1,1])
                    box_bounds(33.3,39,-52,-43,3.7,10.6); //0.1mm hidden overlap inside old solid
            }
        }
        for(s=[-1,1]) scale([s,1,1]) guide_roomier_cavity();
    }
}
// Exact planar chamfer: 11.2x1.3 mm at Z23 to12x2.1 at Z23.4.
// This is an insertion lead-in, not a root fillet or tested strength feature.
module keeper_key(x) {
    // One continuous polyhedron avoids coincident internal cap triangles at the
    // exact chamfer-to-prism transition while preserving all nominal surfaces.
    polyhedron(points=[
        [x-5.6,-50.2,23],[x+5.6,-50.2,23],
        [x+5.6,-48.9,23],[x-5.6,-48.9,23],
        [x-6,-50.6,23.4],[x+6,-50.6,23.4],
        [x+6,-48.5,23.4],[x-6,-48.5,23.4],
        [x-6,-50.6,28.6],[x+6,-50.6,28.6],
        [x+6,-48.5,28.6],[x-6,-48.5,28.6]
    ],faces=[[0,1,2,3],[11,10,9,8],
             [4,5,1,0],[5,6,2,1],[6,7,3,2],[7,4,0,3],
             [8,9,5,4],[9,10,6,5],[10,11,7,6],[11,8,4,7]]);
}
module top_bezel() {
    union() {
        top_bezel_base();
        for(x=[-21,21]) {
            keeper_key(x);
            box_bounds(x-6,x+6,-51.5,-48.5,27.6,29.6);
        }
    }
}
module fascia_fit_collision() {
    intersection() {
        probe_fascia();
        union() {
            // Exclude only intentional support contact at Z3.8 and Y-43.
            intersection() {
                bottom_shell();
                union() {
                    box_bounds(-100,100,-100,100,-1,3.7999);
                    box_bounds(-100,100,-100,-43.0001,3.8001,60);
                    box_bounds(-100,100,-42.9999,100,3.8001,60);
                }
            }
            carrier_sweep(carrier_case_offset_y,carrier_case_offset_y,0,0);
            top_bezel();
        }
    }
}
// A nonconvex mesh is swept continuously by Minkowski sum with a tiny box.
// The box extends 0.00001 mm in X/Z; fixed supports are trimmed by 0.0001 mm
// only at deliberate contact planes, keeping the complete collision question.
module fascia_swept() {
    minkowski() {
        probe_fascia();
        translate([-.000005,-12,-.000005]) cube([.00001,12,.00001]);
    }
}
module fascia_insertion_collision() {
    intersection() {
        fascia_swept();
        union() {
            intersection() {
                bottom_shell();
                union() {
                    box_bounds(-100,100,-100,100,-1,3.7999);
                    box_bounds(-100,100,-100,-43.0001,3.8001,60);
                    box_bounds(-100,100,-42.9999,100,3.8001,60);
                }
            }
            carrier_sweep(carrier_case_offset_y,carrier_case_offset_y,0,0);
        }
    }
}
module lid_closing_collision() {
    // Height separation proves the retainer and all lid material above seam_z
    // cannot touch fixed solids: the highest fixed body is the bottom at27.6.
    // Conservatively sweep the XY projection of ALL original lid material below
    // that seam plus each new keeper key. The projection preserves lip gaps.
    assert(retainer_bottom_z-small_screw_head_height > seam_z);
    assert(carrier_bottom_z+check_pcb_thickness+16.2 < seam_z);
    intersection() {
        union() {
            translate([0,0,seam_z-locating_lip_height+.0001])
                linear_extrude(height=35+locating_lip_height)
                    projection(cut=false) intersection() {
                        top_bezel_base();
                        box_bounds(-100,100,-100,100,0,seam_z-.0001);
                    }
            for(x=[-21,21])
                box_bounds(x-6,x+6,-50.6,-48.5,23.0001,63.6);
        }
        union() {
            bottom_shell();
            probe_fascia();
            carrier_sweep(carrier_case_offset_y,carrier_case_offset_y,0,0);
        }
    }
}

// Right-side hand-held guide/key coupon. This includes no case screw clamp.
module joint_coupon_bottom() {
    intersection() { bottom_shell(); box_bounds(10,43,-52,-22,-.02,60); }
}
module joint_coupon_top() {
    intersection() { top_bezel(); box_bounds(10,43,-52,-22,-.02,60); }
}
module joint_coupon_fascia() {
    intersection() { probe_fascia(); box_bounds(10,43,-52,-22,-.02,60); }
}

module fascia_lift_collision() {
    // Approach the0.2mm upward stop within0.0001mm numerical margin.
    // At exactly0.2mm, the fascia top intentionally contacts seamZ27.6.
    // Tiny numerical trimming excludes only deliberate Y-43 guide end contact.
    intersection() {
        translate([0,0,.1999]) probe_fascia();
        union() {
            intersection() {
                bottom_shell();
                union() {
                    box_bounds(-100,100,-100,-43.0001,-1,60);
                    box_bounds(-100,100,-42.9999,100,-1,60);
                }
            }
            top_bezel();
            carrier_sweep(carrier_case_offset_y,carrier_case_offset_y,0,0);
        }
    }
}

// r13 interior future-mount inserts, accessible from the outside bottom.
// 72x74mm pattern keeps an8mm heat-setting tool clear of wall/closure columns.
module bottom_shell() {
    difference() {
        union() {
            bottom_shell_with_guides();
            for(x=[-36,36],y=[-37,37])
                translate([x,y,2.5]) cylinder(d=10,h=5);
            for(sx=[-1,1],sy=[-1,1]) scale([sx,sy,1])
                box_bounds(35,40.7,28,37,2.5,7.5);
        }
        for(x=[-36,36],y=[-37,37]) {
            translate([x,y,2.5]) cylinder(d=4.2,h=5.02);
            translate([x,y,-.02]) cylinder(d=3.4,h=2.54);
        }
        // Clear the heat-tool approach above the front guide's functional stop.
        // Runner stop remains intact through its maximum6.1mm height.
        for(s=[-1,1]) scale([s,1,1])
            box_bounds(33.3,39,-43,-40.5,7.5,8.02);
    }
}
module mount_screw_collision() {
    // Shaft/witness only; future bracket and external screwhead are unspecified.
    // The user insert's5.0mm maximum OD interferes with the4.2mm pilot for heat-setting.
    intersection() {
        for(x=[-36,36],y=[-37,37])
            translate([x,y,-.1]) cylinder(d=3.2,h=7.6);
        union() {
            bottom_shell();
            carrier_sweep(carrier_case_offset_y,carrier_case_offset_y,0,0);
        }
    }
}
module mount_tool_collision() {
    // Electronics/top removed. Tool envelope is8mm diameter up toZ35;
    // a larger iron barrel must remain above that declared working envelope.
    intersection() {
        for(x=[-36,36],y=[-37,37])
            translate([x,y,7.5001]) cylinder(d=8,h=35-7.5001);
        bottom_shell();
    }
}
module mount_coupon() {
    intersection() { bottom_shell(); box_bounds(27,43,27,48,-.02,10); }
}

module guide_capture_collision(y) {
    // Positive intersections are REQUIRED at both sides. The actual local
    // fascia rails, moved up0.7mm with the lid absent, must hit the rail roofs.
    // The obsolete open inner guide failed this behavior away from the face.
    intersection() {
        bottom_shell();
        translate([0,0,.7]) intersection() {
            probe_fascia();
            for(s=[-1,1]) scale([s,1,1])
                box_bounds(33.3,36.1,y-.1,y+.1,3.7,10);
        }
    }
}

module shell_closure_with_fascia_collision() {
    intersection() { top_bezel(); union() { bottom_shell(); probe_fascia(); } }
}

module guide_roomier_cavity() {
    // One cavity solid exactly combines the constant roof with the frozen
    // piecewise floor; no coincident core/relief side faces remain.
    stations=[[-52.1,3.5],[-50.6,3.5],[-50,3.8],[-49.2,3.8],
              [-48.6,3.5],[-44.6,3.5],[-44,3.8],[-43,3.8]];
    roof=41.8+sqrt(2)*.4;
    points=[for(p=stations) each [[32.7,p[0],p[1]],[36.3,p[0],p[1]],
                                   [36.3,p[0],roof-36.3],[32.7,p[0],roof-32.7]]];
    faces=concat([[3,2,1,0],[28,29,30,31]],
        [for(i=[0:6],j=[0:3]) [4*i+j,4*i+(j+1)%4,4*(i+1)+(j+1)%4,4*(i+1)+j]]);
    polyhedron(points=points,faces=faces);
}
module guide_support_collision(y,drop) {
    intersection() {
        bottom_shell();
        translate([0,0,-drop]) intersection() {
            probe_fascia();
            for(s=[-1,1]) scale([s,1,1])
                box_bounds(33.3,36.1,y-.2,y+.2,3.7,10);
        }
    }
}
module fascia_segment(dy0,dy1,dz0,dz1) {
    //0.0002mm lift clears intentional bearing contact; kernel half-size5nm.
    minkowski() {
        probe_fascia();
        hull() for(q=[[dy0,dz0],[dy1,dz1]])
            translate([-.000005,q[0]-.000005,q[1]+.000195])
                cube([.00001,.00001,.00001]);
    }
}
module lowered_entry_collision() {
    intersection() {
        union() {
            fascia_segment(-12,-7.6,-.3,-.3);
            fascia_segment(-7.6,-7,-.3,0);
            fascia_segment(-7,0,0,0);
        }
        union() {
            intersection() {
                bottom_shell();
                union() {
                    box_bounds(-100,100,-100,-43.0001,-1,60);
                    box_bounds(-100,100,-42.9999,100,-1,60);
                }
            }
            carrier_sweep(carrier_case_offset_y,carrier_case_offset_y,0,0);
        }
    }
}

// One washer per STL; print four copies of each required thickness.
module display_shim(t) {
    difference() {
        cylinder(d=retainer_anchor_od,h=t);
        translate([0,0,-eps]) cylinder(d=m3_clearance,h=t+2*eps);
    }
}
