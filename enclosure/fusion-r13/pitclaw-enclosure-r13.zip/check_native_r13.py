"""Check actual visible component geometry against the enclosure solids and printed USB base.

Only positive-volume component/case intersections are counted. Internal overlaps
between a visual package's leads/housing, and display copper/mask sheets, are not
treated as physical assembly failures. No source geometry is altered.
"""
import adsk.core as C
import adsk.fusion as F
import json,math
from pathlib import Path

OUT=Path(__file__).resolve().parent


def run(_context):
    app=C.Application.get();d=F.Design.cast(app.activeProduct)
    assert app.activeDocument.name.lower().startswith(('pitclaw enclosure r13', 'pitclaw-enclosure-r13')), 'Open the r13 enclosure archive before running this script.'
    pop=d.rootComponent.occurrences.item(5)
    expected=[-1,0,0,0,0,-1,0,.45,0,0,1,.75,0,0,0,1]
    assert all(abs(a-b)<1e-9 for a,b in zip(pop.transform2.asArray(),expected))
    case_occ=[d.rootComponent.occurrences.item(i) for i in (0,1,2,7,9)]
    cases=[o.bRepBodies.item(0) for o in case_occ]
    parts=[];stock=0
    for o in d.rootComponent.allOccurrences:
        path=o.fullPathName
        if path.startswith('REFERENCE - populated carrier (KiCad geometry):'):
            if not o.isLightBulbOn or o.component.name.startswith('CP_Radial'):continue
            if o.component.name.startswith('pitclaw-carrier_') and not o.component.name.endswith('_PCB'):continue
            for b in o.bRepBodies:
                if b.isSolid:parts.append((path,b))
            if o.component.bRepBodies.count and not o.component.name.startswith('pitclaw-carrier_'):stock+=1
        elif path.startswith('REFERENCE - custom populated carrier parts:'):
            for b in o.bRepBodies:
                if b.isSolid:parts.append((path,b))
        elif path.startswith('REFERENCE - WT32 nominal mounting envelope:'):
            for b in o.bRepBodies:
                if b.isSolid:parts.append((path,b))
    assert stock==20,stock
    manager=F.TemporaryBRepManager.get();clashes=[];tests=0
    def overlap(a,b,dx=0,dy=0,dz=0):
        first=manager.copy(a);second=manager.copy(b)
        if dx or dy or dz:
            m=C.Matrix3D.create();m.translation=C.Vector3D.create(dx/10,dy/10,dz/10)
            assert manager.transform(first,m)
        if not first.boundingBox.intersects(second.boundingBox):return 0
        assert manager.booleanOperation(first,second,F.BooleanTypes.IntersectionBooleanType)
        return first.volume*1000 if first.faces.count and first.isSolid else 0
    for n,a in enumerate(cases):
        for b in cases[n+1:]:
            v=overlap(a,b)
            if v>1e-5:clashes.append({'case':a.name,'part':b.name,'volume_mm3':v})
    for case in cases:
        for path,body in parts:
            if not case.boundingBox.intersects(body.boundingBox):continue
            a=manager.copy(case);b=manager.copy(body)
            assert manager.booleanOperation(a,b,F.BooleanTypes.IntersectionBooleanType),path
            tests+=1
            volume=a.volume*1000 if a.faces.count and a.isSolid else 0
            if volume>1e-5:clashes.append({'case':case.name,'part':path,'body':body.name,'volume_mm3':volume})
    issues=[]
    # Imported assembly timeline entries can lack an API feature association.
    # Inspect the real feature/sketch collections instead of TimelineObject.entity.
    for component in d.allComponents:
        for entity in list(component.features)+list(component.sketches):
            if hasattr(entity,'healthState') and entity.healthState!=F.FeatureHealthStates.HealthyFeatureHealthState:
                issues.append({'name':entity.name,'message':entity.errorOrWarningMessage})
    report={'status':'PASS' if not clashes and not issues else 'REVIEW REQUIRED',
            'stock_models_visible':stock,'custom_components':18,
            'coverage':'37 carrier electrical references plus Adafruit5807 module',
            'body_case_boolean_tests':tests,'positive_volume_clashes':clashes,'timeline_issues':issues,
            'pcb_rigid_transform':pop.transform2.asArray(),
            'scope':'Nominal visual component solids versus case. Excludes display-layer sheets and internal package overlaps; not supplier-complete fit or structural validation.'}
    fascia=cases[3];bottom=cases[0];top=cases[1]
    report['retention_tests']={
        'outward_0_5mm_blocked_by_lid_volume_mm3':overlap(fascia,top,dy=-.5),
        'inward_0_5mm_blocked_by_bottom_stop_volume_mm3':overlap(fascia,bottom,dy=.5),
        'upward_1mm_blocked_by_closed_lid_volume_mm3':overlap(fascia,top,dz=1)}
    assert all(v>1e-5 for v in report['retention_tests'].values()),report['retention_tests']
    report['allowed_fascia_lift_0_1999mm_clash_volume_mm3']=overlap(fascia,top,dz=.1999)
    assert report['allowed_fascia_lift_0_1999mm_clash_volume_mm3']<1e-5
    path=[]
    for dy in [-12,-9,-6,-3,-1,-.5,-.25,0]:
        v=overlap(fascia,bottom,dy=dy)
        for _,body in parts:v+=overlap(fascia,body,dy=dy)
        path.append({'fascia_offset_y_mm':dy,'case_component_clash_volume_mm3':v})
    report['native_fascia_path_spot_checks']=path
    assert max(v['case_component_clash_volume_mm3'] for v in path)<1e-5,path
    # Each guide depth must provide its own upper capture without the lid.
    # The previous front-cover/open-groove design fails the inner stations.
    guide_capture=[]
    for side in (-1,1):
        for y in (-51.8,-50,-48.5,-47,-43.5):
            section=manager.copy(fascia)
            bounds=C.OrientedBoundingBox3D.create(C.Point3D.create(side*3.47,y/10,.685),
                C.Vector3D.create(1,0,0),C.Vector3D.create(0,1,0),.27,.02,.63)
            cutter=manager.createBox(bounds)
            assert manager.booleanOperation(section,cutter,F.BooleanTypes.IntersectionBooleanType)
            assert section.faces.count and section.isSolid and section.volume>0
            nominal=overlap(section,bottom)
            running=overlap(section,bottom,dz=.3)
            blocked=overlap(section,bottom,dz=.7)
            assert nominal<1e-5 and running<1e-5 and blocked>1e-5,(side,y,nominal,running,blocked)
            guide_capture.append({'side':side,'depth_y_mm':y,'nominal_clash_mm3':nominal,
                'up_0_3mm_clash_mm3':running,'up_0_7mm_blocked_volume_mm3':blocked})
    report['full_depth_guide_capture_without_lid']=guide_capture
    support=[]
    for side in (-1,1):
        for y in (-49.6,-43.5):
            section=manager.copy(fascia)
            bounds=C.OrientedBoundingBox3D.create(C.Point3D.create(side*3.47,y/10,.685),
                C.Vector3D.create(1,0,0),C.Vector3D.create(0,1,0),.27,.04,.63)
            assert manager.booleanOperation(section,manager.createBox(bounds),F.BooleanTypes.IntersectionBooleanType)
            for drop in (.05,.10):
                v=overlap(section,bottom,dz=-drop)
                assert abs(v-2.65*.4*drop)<.003,(side,y,drop,v)
                support.append({'side':side,'y_mm':y,'drop_mm':drop,'contact_volume_mm3':v})
    report['two_seating_lands_contact_checks']=support
    inserts=list(d.rootComponent.occurrences.item(8).bRepBodies)
    assert len(inserts)==4
    mount_tests=[]
    for x in (-36,36):
        for y in (-37,37):
            shaft=manager.createCylinderOrCone(C.Point3D.create(x/10,y/10,-.01),.16,
                C.Point3D.create(x/10,y/10,.75),.16)
            tool=manager.createCylinderOrCone(C.Point3D.create(x/10,y/10,.75001),.4,
                C.Point3D.create(x/10,y/10,3.5),.4)
            shaft_clash=overlap(shaft,bottom)
            for _,body in parts:shaft_clash+=overlap(shaft,body)
            tool_clash=overlap(tool,bottom)
            assert shaft_clash<1e-5 and tool_clash<1e-5,(x,y,shaft_clash,tool_clash)
            mount_tests.append({'centre_mm':[x,y],'screw_shaft_diameter_mm':3.2,
                'screw_shaft_z_mm':[-.1,7.5],'screw_clearance_clash_mm3':shaft_clash,
                'working_tool_diameter_mm':8,'working_tool_z_mm':[7.5001,35],
                'tool_vs_empty_bottom_clash_mm3':tool_clash})
    floor=manager.copy(bottom)
    slab=manager.createBox(C.OrientedBoundingBox3D.create(C.Point3D.create(0,0,.125),
        C.Vector3D.create(1,0,0),C.Vector3D.create(0,1,0),20,20,.25))
    assert manager.booleanOperation(floor,slab,F.BooleanTypes.IntersectionBooleanType)
    capture=[]
    for insert in inserts:
        v=sum(overlap(insert,b) for _,b in parts)+sum(overlap(insert,b) for b in cases[1:])
        nominal=overlap(insert,floor)
        displaced=overlap(insert,floor,dz=-1.5)
        assert v<1e-5 and nominal<1e-5 and displaced>1e-5,(v,nominal,displaced)
        capture.append({'insert_vs_electronics_and_other_shells_clash_mm3':v,
            'nominal_insert_floor_clash_mm3':nominal,
            'insert_displaced_outward_1_5mm_blocked_by_floor_mm3':displaced})
    report['mounting_hardware_checks']=mount_tests
    report['insert_secondary_capture_checks']=capture
    minimum_capture=[]
    for x in (-36,36):
        for y in (-37,37):
            body=manager.createCylinderOrCone(C.Point3D.create(x/10,y/10,.35),.2,
                C.Point3D.create(x/10,y/10,.75),.2)
            bore=manager.createCylinderOrCone(C.Point3D.create(x/10,y/10,.349),.125,
                C.Point3D.create(x/10,y/10,.751),.125)
            assert manager.booleanOperation(body,bore,F.BooleanTypes.DifferenceBooleanType)
            nominal=overlap(body,floor);blocked=overlap(body,floor,dz=-1.5)
            assert nominal<1e-5 and blocked>1e-5
            minimum_capture.append({'centre_mm':[x,y],'minimum_insert_od_mm':4.0,
                'nominal_floor_clash_mm3':nominal,'outward_1_5mm_floor_contact_mm3':blocked})
    report['minimum_od_secondary_capture_checks']=minimum_capture
    # A no-collision check alone also passes a recessed/loose display. Measure
    # the actual broad planar glass and ledge faces, then prove upward contact.
    display=d.rootComponent.occurrences.item(4).bRepBodies.item(0)
    def broad_face_z(body, approximate):
        faces=[f for f in body.faces if f.geometry.objectType==C.Plane.classType()
               and abs(f.geometry.normal.z)>.999 and f.area*100>1000
               and abs(f.geometry.origin.z*10-approximate)<.01]
        assert len(faces)==1,(body.name,approximate,len(faces))
        return faces[0].geometry.origin.z*10
    ledge_z=broad_face_z(top,43.7)
    glass_z=broad_face_z(display,43.7)
    gap=ledge_z-glass_z
    assert abs(gap)<1e-6,('Display must contact the bezel underside',gap)
    upward_contact=overlap(display,top,dz=.05)
    assert upward_contact>1e-5,upward_contact
    old_gap=ledge_z-(glass_z-1.8)
    assert old_gap>1.79,'Negative control must detect the original recessed seat'
    report['display_seat']={'bezel_underside_z_mm':ledge_z,'glass_front_z_mm':glass_z,
        'air_gap_mm':gap,'outer_face_recess_mm':44.9-glass_z,
        'upward_0_05mm_contact_volume_mm3':upward_contact,
        'negative_control_old_position_gap_mm':old_gap,
        'effective_module_depth_range_mm':[9.3,9.6],
        'scope':'Fit-derived model from reported1.5..1.8mm gap; not a supplier dimension. Actual print needs shim selection.'}
    # Keep the shell stops fixed and vary the effective module stack through
    # the user's reported range. Shims go at the four case anchors, not glass.
    root=d.rootComponent
    depth_parameter=d.userParameters.itemByName('screen_mount_depth')
    fit_cases=[]
    for depth in (9.3,9.4,9.5,9.6):
        depth_parameter.expression=f'{depth} mm'
        assert d.computeAll()
        current_display=root.occurrences.item(4).bRepBodies.item(0)
        current_retainer=root.occurrences.item(2).bRepBodies.item(0)
        current_top=root.occurrences.item(1).bRepBodies.item(0)
        shim=depth-9.3
        seat=43.7-depth
        assert abs(broad_face_z(current_display,43.7)-broad_face_z(current_top,43.7))<1e-6
        assert abs(current_retainer.boundingBox.maxPoint.z*10-seat)<1e-6
        component_clash=overlap(current_retainer,current_display)
        for moving in (current_display,current_retainer):
            for index in (0,1,7,9):
                component_clash+=overlap(moving,root.occurrences.item(index).bRepBodies.item(0))
            for path,body in parts:
                if not path.startswith('REFERENCE - WT32 nominal mounting envelope:'):
                    component_clash+=overlap(moving,body)
        assert component_clash<1e-5,(depth,component_clash)
        shim_clash=0
        if shim>1e-7:
            for x in (-35.5,35.5):
                for y in (-40,40):
                    washer=manager.createCylinderOrCone(C.Point3D.create(x/10,y/10,seat/10),.45,
                        C.Point3D.create(x/10,y/10,3.44),.45)
                    hole=manager.createCylinderOrCone(C.Point3D.create(x/10,y/10,(seat-.01)/10),.17,
                        C.Point3D.create(x/10,y/10,3.441),.17)
                    assert manager.booleanOperation(washer,hole,F.BooleanTypes.DifferenceBooleanType)
                    shim_clash+=sum(overlap(washer,b) for b in (current_top,current_retainer,current_display))
            assert shim_clash<1e-5,(depth,shim_clash)
        engagement=6-2.5-shim
        assert 3.19<engagement<=4 and 5-engagement>=1.49
        fit_cases.append({'effective_module_depth_mm':depth,'anchor_shim_thickness_mm':round(shim,6),
            'forward_movement_from_original_mm':round(1.8-shim,6),'glass_to_bezel_gap_mm':0,
            'component_clash_mm3':component_clash,'shim_clash_mm3':shim_clash,
            'M3x6_insert_engagement_mm':round(engagement,6),'pilot_bottom_clearance_mm':round(5-engagement,6)})
    depth_parameter.expression='9.3 mm'
    assert d.computeAll()
    report['display_seat']['shimmed_fit_range_checks']=fit_cases
    report['mount_check_scope']='The insert/pilot press-fit and screw/thread overlap are intentional. Tool access assumes the empty bottom before electronics and a straight 8mm working envelope. Floor capture is secondary after insert movement; no pull-out or load rating.'
    assert not clashes and not issues,report
    (OUT/'native-verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
